//package com.usbank.wm.empexpfxapi.fxexpapi;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class FxExpApiApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
