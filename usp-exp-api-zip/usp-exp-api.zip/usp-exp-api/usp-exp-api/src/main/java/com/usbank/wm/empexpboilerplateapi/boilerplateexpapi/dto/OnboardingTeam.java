package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OnboardingTeam {
    private String relationshipManager;
    private String role1;
    private String role2;
    private String role3;
    private String role4;
    private String role5;
}

