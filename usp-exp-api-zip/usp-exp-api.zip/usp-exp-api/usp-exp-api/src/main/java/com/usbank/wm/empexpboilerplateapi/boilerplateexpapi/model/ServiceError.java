package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import org.springframework.validation.annotation.Validated;


import jakarta.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Validated
public class ServiceError {
  @JsonProperty("code")
  private String code = null;

  @JsonProperty("message")
  private String message = null;

  @JsonProperty("help")
  private String help = null;

  @JsonProperty("details")
  @Valid
  private List<Object> details = null;

  public ServiceError code(String code) {
    this.code = code;
    return this;
  }
  /**
   * Long term persistent identifier which can be used to trace error condition back to log
   * information. format: AAA.BBBB.CCCC * AAA = 3-Digit HTTP Status Code * BBBB = 4-Digit Apigee
   * Proxy API ID. Assigned by EASE. * CCCC = 4-Digit Error Reason Code. Assigned by LOB API
   * Development Team Codes returned externally may differ from the codes produced within US Bank by
   * internal facing API.
   *
   * @return code
   */
  @Schema(
      defaultValue =
          "Long term persistent identifier which can be used to trace error condition back to log information.    format: AAA.BBBB.CCCC      * AAA = 3-Digit HTTP Status Code     * BBBB = 4-Digit Apigee Proxy API ID. Assigned by EASE.      * CCCC = 4-Digit Error Reason Code. Assigned by LOB API Development Team     Codes returned externally may differ from the codes produced within US Bank by internal facing API.   ")
  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public ServiceError message(String message) {
    this.message = message;
    return this;
  }
  /**
   * End user displayable information, this is the human readable text that provides a high level
   * categorization of the error that has occurred
   *
   * @return message
   */
  @Schema(
      defaultValue =
          "End user displayable information, this is the human readable text that provides a high level categorization of the error that has occurred")
  public String getMessage() {
    return message;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public ServiceError help(String help) {
    this.help = help;
    return this;
  }
  /**
   * Hyperlink(s) to supporting API documentation and US Bank support contacts
   *
   * @return help
   */
  @Schema(
      defaultValue = "Hyperlink(s) to supporting API documentation and US Bank support contacts")
  public String getHelp() {
    return help;
  }

  public void setHelp(String help) {
    this.help = help;
  }

  public ServiceError details(List<Object> details) {
    this.details = details;
    return this;
  }

  public ServiceError addDetailsItem(Object detailsItem) {
    if (this.details == null) {
      this.details = new ArrayList<>();
    }
    this.details.add(detailsItem);
    return this;
  }
  /**
   * An array of detail objects containing the specific information around why the error occurred.
   * Detail objects must contain attributeName AND reason
   *
   * @return details
   */
  @Schema(
      defaultValue =
          "An array of detail objects containing the specific information around why the error occurred.  Detail objects must contain attributeName AND reason")
  public List<Object> getDetails() {
    return details;
  }

  public void setDetails(List<Object> details) {
    this.details = details;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ServiceError serviceError = (ServiceError) o;
    return Objects.equals(this.code, serviceError.code)
        && Objects.equals(this.message, serviceError.message)
        && Objects.equals(this.help, serviceError.help)
        && Objects.equals(this.details, serviceError.details);
  }

  @Override
  public int hashCode() {
    return Objects.hash(code, message, help, details);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ServiceError {\n");
    sb.append("    code: ").append(toIndentedString(code)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    help: ").append(toIndentedString(help)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("}");
    return sb.toString();
  }
  /**
   * Convert the given object to string with each line indented by 4 spaces (except the first line).
   */
  private String toIndentedString(Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
