package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.*;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@Service
@Slf4j
public class MilestoneService {
    Logger logger = LoggerFactory.getLogger(MilestoneService.class);

    @Autowired
    private RemoteService remoteService;

    @Value("${milestone.service.baseurl}")
    private String milestoneBaseUrl;

    @Value("${milestone.service.milestone}")
    private String updatemilestoneAPI;

    @Value("${milestone.service.get.milestones}")
    private String getmilestonesAPI;

    public ResponseEntity<String> insertAllMilestone(String onboardingId, String businessline) {
        log.info("MilestoneService - insertAllMilestone :: onboardingId : {} , businessline : {}", onboardingId, businessline);
        String errorMessage = "Error occurred while inserting all milestone for " + businessline + " and onboardingId " + onboardingId;

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        if (StringUtils.isNotBlank(onboardingId)) {
            urlParams.add(Constants.ONBOARDING_ID, onboardingId);
        }

        if (StringUtils.isNotBlank(businessline)) {
            urlParams.add(Constants.BUSINESS_LINE, businessline);
        }

        JsonObject jsonObject = new JsonObject();

        return saveAllMileStone(jsonObject, urlParams, errorMessage);
    }

    public ResponseEntity<String> updateMilestoneStatus(String onboardingId, String milestoneName, String status) {
        log.info("MilestoneService - updateMilestoneStatus :: onboardingId : {} , milestoneName : {}, status {}", onboardingId, milestoneName, status);
        String errorMessage = "Error occurred while updating milestone status " + status + " for onboardingId " + onboardingId;

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        if (StringUtils.isNotBlank(onboardingId)) {
            urlParams.add(Constants.ONBOARDING_ID, onboardingId);
        }

        JsonObject jsonObject = new JsonObject();
        jsonObject.addProperty(Constants.NAME, milestoneName);
        jsonObject.addProperty(Constants.STATUS, status);

        if (Constants.STATE_COMPLETED.equals(status)) {
            jsonObject.addProperty("completionDate", DateUtil.getCurrentDateInString());
        }
        return updateMileStone(jsonObject, urlParams, errorMessage);
    }

    private ResponseEntity<String> updateMileStone(JsonObject jsonObject, MultiValueMap<String, String> urlParams, String errorMessage) {
        ResponseEntity<String> response;
        log.info("MilestoneService > updateMileStone :: jsonObject : {} , urlParams {}",
                jsonObject, urlParams);
        try {
            response = remoteService.execute(milestoneBaseUrl + updatemilestoneAPI,
                    HttpMethod.PUT, jsonObject.toString(),
                    urlParams, null, true);
            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                log.error(errorMessage);
            }
            log.info("Update Milestone API response : {} ", response);
        } catch (Exception exception) {
            log.error(errorMessage, exception);
            throw new ServiceException(exception.getMessage());
        }

        return response;
    }

    private ResponseEntity<String> saveAllMileStone(JsonObject jsonObject, MultiValueMap<String, String> urlParams, String errorMessage) {
        ResponseEntity<String> response;
        log.info("MilestoneService > saveAllMileStone :: jsonObject : {} , urlParams {}",
                jsonObject, urlParams);
        try {
            response = remoteService.execute(milestoneBaseUrl + updatemilestoneAPI,
                    HttpMethod.POST, jsonObject.toString(),
                    urlParams, null, true);
            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                log.error(errorMessage);
            }
            log.info("Save All Milestone API response : {} ", response);
        } catch (Exception exception) {
            log.error(errorMessage, exception);
            throw new ServiceException(exception.getMessage());
        }

        return response;
    }

}