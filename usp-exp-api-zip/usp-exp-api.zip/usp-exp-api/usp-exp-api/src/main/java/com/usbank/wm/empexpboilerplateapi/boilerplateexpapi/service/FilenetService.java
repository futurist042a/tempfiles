package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class FilenetService {

  @Value("${filenet.service.base.url}")
  private String baseUrl;

  @Value("${filenet.service.mc.proxyWorkArea}")
  private String mcProxyWorkArea;

  @Value("${filenet.rest.v1.searchDocuments}")
  private String searchDocuments;

  @Autowired
  @Qualifier("platformRestTemplate")
  RestTemplate restTemplate;

  @Autowired
  private RemoteService remoteService;
  
  public ResponseEntity<ByteArrayResource> searchDocuments(String onboardingId,
      String filterCriteria, String onboardingType) {
    ResponseEntity<ByteArrayResource> response = null;

    String initialUrl = baseUrl + searchDocuments;

    Map<String, String> pathVar = new HashMap<>();

    MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();

    urlParams.add(Constants.PROXY_WORK_AREA, mcProxyWorkArea);
    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    headers.add(Constants.HEADER_REQUEST_ID, onboardingId);

    HttpHeaders httpHeaders = new HttpHeaders();
    httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
    httpHeaders.addAll(headers);

    log.info(Constants.USB_UO_LOG+Constants.URL_PARAMS, urlParams.values());
    log.info(Constants.USB_UO_LOG+Constants.URL_HEADERS, headers.values());

    URI url =
        UriComponentsBuilder.fromUriString(initialUrl)
            .queryParams(urlParams)
            .queryParam("filterBy", filterCriteria)
            .buildAndExpand(pathVar)
            .encode()
            .toUri();

    log.info(Constants.USB_UO_LOG,Constants.FINAL_REMOTE_URI , url.toString());

    HttpEntity<String> request = new HttpEntity<>(null, httpHeaders);

    try {

      response = restTemplate.exchange(url, HttpMethod.GET, request, ByteArrayResource.class);

      HttpStatusCode tempStatus = response.getStatusCode();
      
      if (!tempStatus.is2xxSuccessful()) {
        log.info(Constants.USB_UO_LOG+Constants.REMOTE_API_CALL);
        if (response.hasBody()) {
          JsonArray items = JsonParser.parseString(response.getBody().toString()).getAsJsonArray();
          for (JsonElement jsonElement : items) {
            log.error(Constants.ERROR_SPACE,Constants.REMOTE_API_ERROR_START,Constants.ERROR_SPACE);
            log.error(jsonElement.getAsJsonObject().get(Constants.ERROR_CODE).getAsString());
            log.error(jsonElement.getAsJsonObject().get(Constants.MESSAGE).getAsString());
          }
        }
      }

      return response;
    } catch (Exception e) {
      log.error("Error occurred in: getDocument.", e);
      throw new ServiceException(e.getMessage());
    }
  }
}
