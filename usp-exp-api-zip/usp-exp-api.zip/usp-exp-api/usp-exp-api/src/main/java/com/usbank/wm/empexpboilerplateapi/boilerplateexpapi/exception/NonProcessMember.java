package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public class NonProcessMember extends RuntimeException {

    public NonProcessMember(String message) {
        super(message);
    }
}
