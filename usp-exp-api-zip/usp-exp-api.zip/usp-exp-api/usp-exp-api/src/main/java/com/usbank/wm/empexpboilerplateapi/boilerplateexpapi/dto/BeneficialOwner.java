package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BeneficialOwner {
    public Address address;
    public String dateOfBirth;
    public String identificationNumber;
    public String firstName;
    public String middleName;
    public String lastName;
    public String ownershipPercentage;
}
