package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class PdfRequest {
    private String AccountNumber;
    private Integer[] FormIdentifiers;
    private String Encoding;
}
