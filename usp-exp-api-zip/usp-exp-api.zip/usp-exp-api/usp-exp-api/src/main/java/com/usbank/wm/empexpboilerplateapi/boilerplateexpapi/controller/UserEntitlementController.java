package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;



import com.google.gson.JsonObject;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.EntitlementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
public class UserEntitlementController {

    @Autowired
    private EntitlementService entitlementService;

    @GetMapping(value = "/v1/userDetails")
    public ResponseEntity<String> checkForEntitlement(@RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
                                                      @RequestParam(value = "userId", required = true) String userId,
                                                      @RequestParam(value = "onboardingType", required = false) String onboardingType) {
        try {
            log.info("onBoardingType::::::::::::::::::::{}", onboardingType);
            log.info("userId::::::::::::::::::::{}", userId);
            JsonObject userDetailsJson = entitlementService. getListOfUserGroup(userId);
            return new ResponseEntity<>(userDetailsJson.toString(), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred in getting userDetails", e.getMessage());
        }
        return new ResponseEntity<>("", HttpStatus.NO_CONTENT);
    }
}
