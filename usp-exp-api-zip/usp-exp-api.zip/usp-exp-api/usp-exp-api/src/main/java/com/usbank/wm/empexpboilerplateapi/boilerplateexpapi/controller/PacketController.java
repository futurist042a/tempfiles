package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;



import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.EmailService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.PacketGeneratorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@Slf4j
public class PacketController {

	@Autowired
	private PacketGeneratorService packetGeneratorService;

	@Autowired
	EmailService emailService;

	@PostMapping(value = "/v1/sendPacket", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> sendPacket(@RequestBody String requestPayload) {
		String mergedPdfPacket = packetGeneratorService.generatePacket(requestPayload);
		log.info("calling Email Service to send email");
		emailService.sendPacket(mergedPdfPacket, requestPayload);
		return new ResponseEntity<>("Packet Delivered to the Customer", HttpStatus.OK);
	}
}
