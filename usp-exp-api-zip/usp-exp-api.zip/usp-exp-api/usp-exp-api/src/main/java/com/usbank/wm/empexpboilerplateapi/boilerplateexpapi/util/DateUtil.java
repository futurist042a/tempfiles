package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ObjectUtils;

import java.time.*;
import java.time.format.DateTimeFormatter;

public class DateUtil {
    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    private DateUtil() {
    }

    public static final String DATE_ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSX";

    public static final String DATE_FORMAT_YYYY_MM_DD_WITH_HH_MM_A = "yyyy-MM-dd hh:mm a";

    public static final String DATE_FORMAT_YYYY_MM_DD_WITH_DASHES = "yyyy-MM-dd";

    public static final String DATE_FORMAT_M_D_YYYY_WITH_SLASHES = "M/d/yyyy";

    public static final String TIME_FORMAT_HH_MM_A = "hh:mm a";

    public static final String DEFAULT_TIME_ZONE = "America/Chicago";

    public static LocalDateTime stringToLocalDateTime(final String date, final String format) {
        LocalDateTime localDateTime = null;
        if (ObjectUtils.isEmpty(date)) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        try {
            localDateTime = LocalDateTime.parse(date, formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return localDateTime;
    }

    public static LocalDate stringToLocalDate(final String date, final String format) {
        LocalDate localDate = null;
        if (ObjectUtils.isEmpty(date)) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        try {
            localDate = LocalDate.parse(date, formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return localDate;
    }

    public static LocalDateTime isoStringToLocalDateTime(final String date) {
        if (date == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_ISO_FORMAT);
        LocalDateTime localDateTime = null;
        try {
            localDateTime = LocalDateTime.parse(date, formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return localDateTime;
    }

    public static LocalDate isoStringToLocalDate(final String date) {
        if (date == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_ISO_FORMAT);
        LocalDate localDate = null;
        try {
            localDate = LocalDate.parse(date, formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return localDate;
    }

    public static ZonedDateTime localDateTimeToZonedDateTime(final LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return ZonedDateTime.of(localDateTime, ZoneId.of(DEFAULT_TIME_ZONE));
    }

    public static ZonedDateTime getCurrentZonedDateTime() {
        return Instant.now().atZone(ZoneId.of(DEFAULT_TIME_ZONE));
    }

    public static String formatDateToString(final LocalDate date, final String format) {
        if (date == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        try {
            return date.format(formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return null;
    }

    public static String formatZonedDateToString(final ZonedDateTime date, final String format) {
        if (date == null) {
            return null;
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        try {
            return date.format(formatter);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return null;
    }

    /**
     * Converts date string to Instant
     *
     * @param date
     * @return
     */
    public static Instant convertToInstant(String date) {
        if (org.apache.commons.lang3.ObjectUtils.isEmpty(date)) {
            return null;
        }
        StringBuilder inDate = new StringBuilder(date);

        if (inDate.indexOf("T") == -1) {
            inDate.replace(10, 11, "T");
        }

        if (inDate.indexOf(".") == -1) {
            inDate.append("Z");
        }

        if (inDate.length() > 24) {
            inDate.replace(23, inDate.length(), "Z");
        } else {
            inDate.append("Z");
        }

        return ZonedDateTime.parse(inDate.toString())
                .withZoneSameLocal(ZoneId.of(DEFAULT_TIME_ZONE))
                .toInstant();
    }

    /* Converting the LocalDate to LocalDateTime using
     * atStartOfDay() method. This method adds midnight
     * time (start of the day time) with the local date.
     */
    public static LocalDateTime localDateToLocalDateTime(final LocalDate localDate) {
        if (localDate == null) {
            return null;
        }
        return localDate.atStartOfDay();
    }
    /* Converting the LocalDateTime to LocalDate */
    public static LocalDate localDateTimeToLocalDate(final LocalDateTime localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        return localDateTime.toLocalDate();
    }

    /* Converting the string to LocalDateTime */
    public static LocalDateTime stringToLocalDateTime(final String localDateTime) {
        if (localDateTime == null) {
            return null;
        }
        try {
            return LocalDateTime.parse(localDateTime);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return null;
    }

    /* Converting the string to LocalDate */
    public static LocalDate stringToLocalDate(final String localDate) {
        if (localDate == null) {
            return null;
        }
        try {
            return LocalDate.parse(localDate);
        } catch (Exception exp) {
            logger.error("Error parsing the date.", exp);
        }
        return null;
    }

    public static String getCurrentDateInString() {
        ZonedDateTime currentDate = ZonedDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_ISO_FORMAT);
        return currentDate.format(formatter);
    }
}

