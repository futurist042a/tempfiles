package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public class UnAuthorizedException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5007736282083406485L;

	public UnAuthorizedException(String message) {
        super(message);
    }
}
