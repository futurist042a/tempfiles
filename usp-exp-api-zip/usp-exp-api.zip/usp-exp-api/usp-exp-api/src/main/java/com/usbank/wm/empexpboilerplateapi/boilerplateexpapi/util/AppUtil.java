package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.RemoteService;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.ObjectUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Pattern;

public class AppUtil {

    private AppUtil() {
    }

    public static Optional<String> getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && !(authentication instanceof AnonymousAuthenticationToken)) {
            String userName = authentication.getName();
            return Optional.ofNullable(
                    ObjectUtils.isEmpty(userName) ? "unknown" : userName.toLowerCase());
        }

        return Optional.of("unknown");
    }

    public static final Map<String, String> getLogContextMap() {
        return new HashMap<>();
    }

    public static boolean isValidTxnID(String data){
        if(Pattern.compile("^\\d{0,9}$").matcher(data).matches()){
            return true;
        }else if(Pattern.compile("^\\d[0-9-]{0,10}$").matcher(data).matches()){
            if(data.charAt(3)=='-' && data.charAt(6)=='-') {
                return true;
            }else if(data.charAt(2)=='-' && data.length()==10){
                return true;
            }
        }
        return false;
    }
    public static String getOnlyNameFromString(String variableString){
        if(null !=variableString && !variableString.isEmpty() && variableString.contains("/")) {
            String[] strArray;
            strArray = variableString.split("/");
            return strArray[0];
        }else{
            return variableString;
        }
    }
    public static <T> List<T> parseJsonArray(String json, Class<T> classOnWhichArrayIsDefined)
            throws IOException, ClassNotFoundException {
        ObjectMapper mapper = new ObjectMapper();
        Class<T[]> arrayClass = (Class<T[]>) Class.forName("[L" + classOnWhichArrayIsDefined.getName() + ";");
        T[] objects = mapper.readValue(json, arrayClass);
        return Arrays.asList(objects);
    }

    public static String createBasicAuthorizationToken(String userName, String password) {
        return "Basic " + HttpHeaders.encodeBasicAuth(userName, password, StandardCharsets.US_ASCII);
    }

}
