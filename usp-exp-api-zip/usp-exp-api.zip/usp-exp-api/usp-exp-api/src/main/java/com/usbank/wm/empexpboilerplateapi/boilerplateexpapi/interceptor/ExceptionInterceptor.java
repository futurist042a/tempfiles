package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.interceptor;



import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BadRequestException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.UnAuthorizedException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.ServiceError;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.ServiceErrors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ExceptionInterceptor extends ResponseEntityExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ExceptionInterceptor.class);

    @Value("${spring.profiles.active}")
    private String activeProfile;

    @ExceptionHandler(value = {BadRequestException.class, UnAuthorizedException.class})
    protected ResponseEntity<Object> handleClientException(RuntimeException ex, WebRequest request) {
        logger.error("An system error occurred: ", ex);
        if (ex instanceof BadRequestException) {
            return handleExceptionInternal(
                    ex,
                    buildError(HttpStatus.BAD_REQUEST, Constants.ERROR_CODE_BAD_REQUEST, ex.getMessage(), ex),
                    new HttpHeaders(),
                    HttpStatus.BAD_REQUEST,
                    request);
        }

        if (ex instanceof UnAuthorizedException) {
            return handleExceptionInternal(
                    ex,
                    buildError(HttpStatus.UNAUTHORIZED, Constants.ERROR_CODE_UNAUTHORIZED, ex.getMessage(), ex),
                    new HttpHeaders(),
                    HttpStatus.UNAUTHORIZED,
                    request);
        }

        return handleExceptionInternal(
                ex,
                buildError(HttpStatus.NOT_FOUND, Constants.ERROR_CODE_NOT_FOUND, ex.getMessage(), ex),
                new HttpHeaders(),
                HttpStatus.NOT_FOUND,
                request);
    }

    private ServiceErrors buildError(
    	      HttpStatus httpStatus, String serviceErrorCode, String message, Exception exp) {
    	    ServiceErrors serviceErrors = new ServiceErrors();
    	    ServiceError serviceError = new ServiceError();
    	    serviceError.code(httpStatus.value() + "." + serviceErrorCode);
    	    serviceError.setMessage(message);
    	    if (exp != null && exp.getStackTrace() != null && !activeProfile.equalsIgnoreCase("prod")) {
    	      serviceError.addDetailsItem(exp.getMessage());
    	    }

    	    serviceErrors.addErrorsItem(serviceError);
    	    return serviceErrors;
    	  }
}
