
package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "idType",
    "idValue"
})
@Data
public class UserIdentifier implements Serializable
{

    @JsonProperty("idType")
    private String idType;
    @JsonProperty("idValue")
    private String idValue;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    private static final long serialVersionUID = 4044227792425691450L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(UserIdentifier.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("idType");
        sb.append('=');
        sb.append(((this.idType == null)? Constants.NULL_STRING:this.idType));
        sb.append(',');
        sb.append("idValue");
        sb.append('=');
        sb.append(((this.idValue == null)? Constants.NULL_STRING:this.idValue));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)? Constants.NULL_STRING:this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
