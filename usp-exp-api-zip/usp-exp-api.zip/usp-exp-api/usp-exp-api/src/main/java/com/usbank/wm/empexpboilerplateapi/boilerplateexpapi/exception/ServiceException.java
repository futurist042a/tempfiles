package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public class ServiceException extends RuntimeException {

  /**
	 * 
	 */
	private static final long serialVersionUID = -316709504536803263L;

public ServiceException(final String message) {
    super(message);
  }
  
  public ServiceException(final String message, Throwable cause) {
		super(message, cause);
	}
}
