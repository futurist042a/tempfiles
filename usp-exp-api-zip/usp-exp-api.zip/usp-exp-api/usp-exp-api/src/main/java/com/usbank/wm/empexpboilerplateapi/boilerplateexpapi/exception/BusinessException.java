package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public class BusinessException extends RuntimeException implements USBException  {

    private static final long serialVersionUID = 1L;

    private String uiMessage = "";
    private String errorType = "";
    
    
    public BusinessException() {
        super();
    }

    public BusinessException(String message) {
        super(message);
    }

    public BusinessException(String message, String uiMessage, String errorType) {
        super(message);
        this.uiMessage = uiMessage;
        this.errorType = errorType;
    }
    
    public BusinessException(String message, Throwable cause) {
        super(message, cause);
    }

    public BusinessException(String message, String uiMessage, String errorType , Throwable cause) {
        super(message, cause);
        this.uiMessage = uiMessage;
        this.errorType = errorType;
    }
    
    public BusinessException(Throwable cause) {
        super(cause);
    }

    protected BusinessException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    @Override
    public String getUIMessage() {
       return uiMessage;
    }

    @Override
    public String getErrorType() {
        return errorType;
     }
}


