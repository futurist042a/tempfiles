package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String state;
    private String zipCode;
    private String country;

    public String toString() {
        return String.format("{\"addressLine1\":\"%s\",\"addressLine2\":\"%s\",\"city\":\"%s\",\"state\":\"%s\",\"zipCode\":\"%s\",\"country\":\"%s\"}", addressLine1, addressLine2,city,state,zipCode,country);
    }
}
