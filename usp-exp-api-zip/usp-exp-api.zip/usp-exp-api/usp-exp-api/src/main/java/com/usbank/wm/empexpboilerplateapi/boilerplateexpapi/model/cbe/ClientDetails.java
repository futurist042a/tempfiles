package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.cbe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientDetails {
    String legalName;
    String EIN;
    String LEI;
    String LPID;
    Address address;
    ContactDetails contactDetails;
    DBA[] dba;
    AdditionalDetails additionalDetails;
}
