package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class SearchCriteria {
    String key;
    String value;
    String operation;

    public SearchCriteria(String key, String value, String operation) {
        this.key = key;
        this.value = value;
        this.operation = operation;
    }

    @Override
    public String toString() {
        return "SearchCriteria{" +
                "key='" + key + '\'' +
                ", value='" + value + '\'' +
                ", operation='" + operation + '\'' +
                '}';
    }
}
