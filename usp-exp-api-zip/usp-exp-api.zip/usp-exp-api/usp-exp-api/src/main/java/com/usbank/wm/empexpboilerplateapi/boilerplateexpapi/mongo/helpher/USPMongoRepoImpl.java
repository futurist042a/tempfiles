package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.helpher;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;

import com.mongodb.BasicDBObject;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import com.mongodb.client.result.InsertOneResult;
import com.mongodb.client.result.UpdateResult;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.ReplaceOptions;
import org.bson.conversions.Bson;

@Repository
@Slf4j
public class USPMongoRepoImpl implements USPMongoRepository{

    @Value("${spring.data.mongodb.database}")
    private String databaseName;

    @Value("${spring.data.mongodb.uri}")
    private String mongoDBURL;

    public String fetchDocuments(String collectionName, String jsonQuery,
                                     String projectionJson, String sortJson) {
        log.info("jsonQuery : "+jsonQuery+", collectionName : "+collectionName);
        MongoClient mongoClient = MongoClients.create(mongoDBURL);
        MongoDatabase mongoDB = mongoClient.getDatabase(databaseName);
        MongoCollection<Document> mongoCollection = mongoDB.getCollection(collectionName);
        Document doc = Document.parse(jsonQuery);
        BasicDBObject sort = BasicDBObject.parse(sortJson);
        BasicDBObject projection = BasicDBObject.parse(projectionJson);

        // find documents
        List<Document> responseList = mongoCollection.find(doc).projection(projection).sort(sort).into(new ArrayList<>());

        //ArrayList<String> result = MongoDBUtil.getDocumentJSON(responseList);
        String result = MongoDBUtil.getDocumentJSONStr(responseList);
        return result;
    }

    public String insertDocumentStr(String collectionName, String documentJSON){
        MongoClient mongoClient = MongoClients.create(mongoDBURL);
        MongoDatabase mongoDB = mongoClient.getDatabase(databaseName);
        MongoCollection<Document> mongoCollection = mongoDB.getCollection(collectionName);
        Document doc = MongoDBUtil.verifyDocument(documentJSON);
        InsertOneResult ior = mongoCollection.insertOne(doc);
        return String.valueOf(ior.getInsertedId().asObjectId().getValue());
    }

    public long replaceRecord(String collectionName, String filtersJSON, String updatesJSON, boolean upsert)
    {
        log.info("replace record : filterJson - "+filtersJSON);
        UpdateResult updateResult = null;
        long updatedResult = 0;
        try
        {
            MongoClient mongoClient = MongoClients.create(mongoDBURL);
            MongoDatabase mongoDB = mongoClient.getDatabase(databaseName);
            MongoCollection<Document> mongoCollection = mongoDB.getCollection(collectionName);
            Bson filters = Document.parse(filtersJSON);
            Document updates = MongoDBUtil.verifyDocument(updatesJSON);
            ReplaceOptions options = new ReplaceOptions().upsert(upsert);

            updateResult = mongoCollection.replaceOne(filters, updates, options);
            updatedResult = updateResult.getModifiedCount();
//            updatedResult = new Document();
//            updatedResult.put("matchedCount", updateResult.getMatchedCount());
//            updatedResult.put("modifiedCount", updateResult.getModifiedCount());
//            String upsertedId="";
//            if(updateResult.getUpsertedId()!=null && updateResult.getUpsertedId().asObjectId()!=null)
//            {
//                upsertedId=updateResult.getUpsertedId().asObjectId().getValue()+"";
//            }
//            updatedResult.put("upsertedId", upsertedId);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            //log.info("Encountered exception in MongoDBUpdate Class: "+e.toString());
        }
        finally {
            //log.info("Finally block ");
        }
        return updatedResult;
    }

    public void createCollection(String collectionName) {
        log.info("createCollection : "+collectionName);
        try {
            MongoClient mongoClient = MongoClients.create(mongoDBURL);
            MongoDatabase mongoDB = mongoClient.getDatabase(databaseName);
            mongoDB.createCollection(collectionName);
        }
        catch (Exception e){e.printStackTrace();}
        finally {}
    }

    public long updateDocument(String collectionName, String filtersJSON, String updatesJSON, String arrayFiltersJSON, boolean upsert)
    {
        log.info("updateDocument : "+collectionName+" - "+updatesJSON);
        UpdateResult updateResult= null;
        try {
            MongoClient mongoClient = MongoClients.create(mongoDBURL);
            MongoDatabase mongoDB = mongoClient.getDatabase(databaseName);
            MongoCollection<Document> mongoCollection = mongoDB.getCollection(collectionName);
            BasicDBObject filter = BasicDBObject.parse(filtersJSON);
            BasicDBObject updates = BasicDBObject.parse(updatesJSON);
            UpdateOptions options = new UpdateOptions().upsert(upsert);

            if(arrayFiltersJSON!=null && arrayFiltersJSON!="")
            {
                Gson gson = new Gson();
                Document[] af = gson.fromJson(arrayFiltersJSON, Document[].class);
                options.arrayFilters(Arrays.asList(af));
            }
            updateResult = mongoCollection.updateOne(filter, updates, options);
        }
        catch (Exception e){e.printStackTrace();}
        finally {}
        if(updateResult!=null) {
            log.info("updateResult : "+updateResult.getModifiedCount());
            return updateResult.getModifiedCount();
        }else{
            log.info("-1");
            return -1;
        }
    }
}