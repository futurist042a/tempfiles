package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.Gson;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BusinessException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

@Service
public class ConnectService {

    private static final Logger logger = LoggerFactory.getLogger(ConnectService.class);

    @Autowired
    private RemoteService remoteService;

    MultiValueMap<String, String> headers;

    public ResponseEntity<String> fetchRecord(String uri, HttpMethod httpMethod, Object requestObject,
                                              MultiValueMap<String, String> urlParams) {
        logger.info("Entered into fetchRecord : uri : " + uri);
        ResponseEntity<String> response = null;
        String requestJsonBody =
                requestObject != null ? new Gson().toJson(requestObject).toString() : null;
        try {
            response = remoteService.execute(
                    uri, httpMethod, requestJsonBody, urlParams, headers, true);
        } catch (Exception e) {
            logger.error("Error occurred in fetch record", e.getMessage());
            throw new BusinessException(e.getMessage());
        }
        return response;
    }


}
