package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public class BadRequestException extends RuntimeException {

  /**
	 * 
	 */
	private static final long serialVersionUID = 6581903080637252919L;

public BadRequestException(String message) {
    super(message);
  }
}
