package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcessDetails{
    public String instanceId;
    public String workFlowStatus;
    public String startDate;
    public String targetOnboardingCompletionDate;
    public String createdBy;
    public List<MileStoneTracker> mileStoneTracker;
    public List<TaskDetail> taskDetails;
}



