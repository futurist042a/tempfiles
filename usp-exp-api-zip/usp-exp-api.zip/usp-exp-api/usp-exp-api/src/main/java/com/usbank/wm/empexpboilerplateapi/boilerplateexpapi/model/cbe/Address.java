package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.cbe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address {
    String addressLine1;
    String addressLine2;
    String city;
    String state;
    String zipCode;
    String country;
}
