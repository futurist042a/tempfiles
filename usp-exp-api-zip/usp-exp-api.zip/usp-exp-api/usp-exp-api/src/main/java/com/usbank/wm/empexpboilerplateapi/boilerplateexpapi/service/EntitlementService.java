package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Slf4j
public class EntitlementService {

    @Autowired
    @Qualifier(value = "entitlementClient")
    private WebClient webClient;

    @Autowired
    private BoilerplateService boilerplateService;

    public EntitlementService(WebClient webClient) {
        this.webClient = webClient;
    }
    public String getBusinessLine(String authorization, String userId) {
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("userId", userId);

        return this.webClient.get().uri(builder -> builder.path("/v1/user/userDetails").queryParams(urlParams).build())
                .header(Constants.HEADER_AUTHORIZATION, authorization).exchangeToMono(response -> {

                    if (response.statusCode().equals(HttpStatus.OK)) {
                        return response.bodyToMono(String.class);
                    } else if (response.statusCode().is4xxClientError()) {
                        return Mono.just("Error response");
                    } else {
                        return response.createException().flatMap(Mono::error);
                    }
                }).block();
    }

    public String extractBusinessLine(String response, String onboardingType) {
        List<String> memberShipArray = new ArrayList<>();
        JsonObject jsonObject = JsonParser.parseString(response).getAsJsonObject();
        log.info("jsonObject.keySet():::: {} ", jsonObject.keySet());
        if (jsonObject.has("data") && !onboardingType.isEmpty()) {
            JsonObject data = (JsonObject) jsonObject.get("data");
            log.info("memberships {} ", data.has("memberships"));
            if (data.has("memberships")) {
                String membersips = data.get("memberships").toString();
                List<String> temp = Arrays.asList(membersips.replace("[", "").replace("]", "").split(","));
                memberShipArray = temp.stream().filter(str -> str.contains((onboardingType + "_"))).collect(Collectors.toList());
            }
        }
        return memberShipArray.toString();
    }

    public JsonObject getListOfUserGroup(String userId) {

        log.info("getListOfUserGroup");
        JsonObject userPermission = new JsonObject();
        JsonObject userDetailsJson = new JsonObject();

        try {
            List<String> rolesList = boilerplateService.getListOfUserGroup(userId);

            // BusinessLine requiremnt code here

            JsonObject obj = new JsonObject();
            JsonArray memberships = JsonParser.parseString(new ObjectMapper().writeValueAsString(rolesList)).getAsJsonArray();
            obj.add("userRoles", memberships);
            obj.add("userPermission", userPermission);
            userDetailsJson.add("userDetails", obj);

            return userDetailsJson;
        }
        catch (Exception ex) {
                throw new ServiceException(ex.getMessage());
        }

    }




}
