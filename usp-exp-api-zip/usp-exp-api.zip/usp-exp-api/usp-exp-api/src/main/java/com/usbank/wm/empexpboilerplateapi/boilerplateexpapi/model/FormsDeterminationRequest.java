package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class FormsDeterminationRequest {
    private String onboardingType;
    private List<Question> questionList;
}