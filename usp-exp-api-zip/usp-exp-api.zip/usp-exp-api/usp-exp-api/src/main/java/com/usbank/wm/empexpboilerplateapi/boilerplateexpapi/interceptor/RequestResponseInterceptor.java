package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.interceptor;


import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import java.util.UUID;

@Component
public class RequestResponseInterceptor implements HandlerInterceptor {

  private static final Logger logger = LoggerFactory.getLogger(RequestResponseInterceptor.class);

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
		String correlationId = null;

	correlationId = request.getHeader(Constants.HEADER_CORRELATION_ID);

    if (ObjectUtils.isEmpty(correlationId)) {
      correlationId = UUID.randomUUID().toString();
      logger.info("Correlation-ID is missing in headers. Generating a random UUID.");
    }

    // set correlationId and onboardingId in the log context
    MDC.put(Constants.HEADER_CORRELATION_ID, correlationId);

    // set correlationId and onboardingId in a map fpr async threads
  AppUtil.getLogContextMap().put(Constants.HEADER_CORRELATION_ID, correlationId);

    // set correlationId in response headers
    String headerKey = validateHeader(Constants.HEADER_CORRELATION_ID);
    String headerVal = validateHeader(correlationId);
    response.setHeader(headerKey, headerVal);

    if (!request.getRequestURI().equals("/error")) {
      logger.info("===========request begin============");
      logger.info("URI               : " + request.getRequestURI());
      logger.info("Method            : " + request.getMethod());
      logger.info("Correlation-ID    : " + correlationId);
      logger.debug("Query String     : " + request.getQueryString());
      logger.info("============request end=============");
    }

    return true;
  }

  @Override
  public void postHandle(
      HttpServletRequest request,
      HttpServletResponse response,
      Object handler,
      @Nullable ModelAndView modelAndView)
      throws Exception {

    response.setContentType(MediaType.APPLICATION_JSON_VALUE);

    logger.info("======response begin=========");
    logger.info("Status         : " + response.getStatus());
    logger.info("==========response end==========");
  }

  @Override
  public void afterCompletion(
      HttpServletRequest request,
      HttpServletResponse response,
      Object handler,
      @Nullable Exception ex)
      throws Exception {
    // remove from the log context after request is completed
    MDC.remove(Constants.HEADER_CORRELATION_ID);
    MDC.remove(Constants.HEADER_ONBOARDING_ID);
    AppUtil.getLogContextMap().remove(Constants.HEADER_CORRELATION_ID);
    AppUtil.getLogContextMap().remove(Constants.HEADER_ONBOARDING_ID);
  }

  private static String  validateHeader(String header){
    if (null!=header && !header.matches("^[A-Z a-z 0-9-]+$")){
      throw new IllegalArgumentException();
    }
    return header;
  }
}
