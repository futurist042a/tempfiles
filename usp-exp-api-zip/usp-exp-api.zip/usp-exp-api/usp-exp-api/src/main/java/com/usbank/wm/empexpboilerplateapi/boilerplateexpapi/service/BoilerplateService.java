package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.ProcessDetails;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.TaskDetail;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.NonProcessMember;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.EventTasks;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Events;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.SearchCriteria;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.CommonOnBoardingEvent;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
@Slf4j
public class BoilerplateService {
    private WebClient webClient;
    private PacketGeneratorService packetGeneratorService;
    EmailService emailService;
    ConnectService connectService;
    private RemoteService remoteService;
    @Autowired
    private AuditService auditService;

    @Autowired
    private BPMService bpmService;


    private CamundaRemoteService camundaRemoteService;
    public static final String VALUE = "value" ;

    @Value("${event.service.baseurl}")
    private String eventBaseUrl;

    @Value("${event.service.eventDataUrl}")
    private String eventServiceFormDataUrl;

    @Value("${event.service.fetchOnboardingEventsDetails}")
    private String fetchOnboardingEventsDetails;

    @Value("${form.service.baseurl}")
    private String formBaseUrl;

    @Value("${form.service.FormDataUrl}")
    private String formServiceFormDataUrl;

    @Value("${form.service.datapointUrl}")
    private String datapointUrl;

    @Value("${form.service.v1.refsByTypeId}")
    private String refsByTypeId;
    @Value("${business.line.userId}")
    private String userId;

    @Autowired
    @Value("${boilerplate.camunda.service.base.url}")
    private String boilerplateCamundaServiceBaseUrl;
    @Value("${boilerplate.camunda.service.groupsbyuserid.url}")
    private String boilerplateCamundaServiceGroupsByUserIdUrl;

    @Value("${audit.service.base.url}")
    private String auditBaseUrl;

    @Value("${audit.service.AuditDataUrl}")
    private String auditServiceFormDataUrl;

    @Autowired
    @Qualifier("taskClient")
    protected WebClient taskClient;

    @Autowired
    public HttpServletRequest request;
    @Autowired
    public BoilerplateService(WebClient webClient, PacketGeneratorService packetGeneratorService,
                              EmailService emailService, CamundaRemoteService camundaRemoteService, RemoteService remoteService, BPMService bpmService) {
        this.webClient = webClient;
        this.packetGeneratorService = packetGeneratorService;
        this.emailService = emailService;
        this.camundaRemoteService = camundaRemoteService;
        this.remoteService = remoteService;
        this.bpmService = bpmService;
    }

    public String saveForm(String authorization, String businessLine, String formName, String formAction,
                           String formBody, String currentUser,String onboardingId) {

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add(Constants.BUSINESS_LINE, businessLine);
        urlParams.add(Constants.FORM_NAME, formName);
        urlParams.add(Constants.FORM_ACTION, formAction);
        urlParams.add(Constants.CURRENT_USER, currentUser);
        onboardingId = onboardingId != null ? onboardingId : "";
        urlParams.add(Constants.ONBOARDING_ID, onboardingId);
       
        return this.webClient.post().uri(builder -> builder.path("/v1/saveOnboarding").queryParams(urlParams).build())
                .header(Constants.HEADER_AUTHORIZATION, authorization).body(Mono.just(formBody), String.class)
                .retrieve().bodyToMono(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();

    }

    public ResponseEntity<String> saveDataPoint(String authorization, String onboardingId, String formBody) {
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("onboardingId", String.valueOf(onboardingId));
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        headers.addAll(headersMap);
        headers.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
        headers.setContentType(MediaType.APPLICATION_JSON);
        JsonObject jsonObject = JsonParser.parseString(formBody).getAsJsonObject();
        formBody = jsonObject.toString();
        return remoteService.execute(formBaseUrl+datapointUrl, HttpMethod.POST, formBody, urlParams, headers, false);

    }

    public String getCommonOnBoardingEvent(String authorization,  String formBody) {

        return this.webClient.post().uri(builder -> builder.path("/graphql").build())
                .header(Constants.HEADER_AUTHORIZATION, authorization).body(Mono.just(formBody), String.class)
                .retrieve().bodyToMono(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();

    }

    public List<CommonOnBoardingEvent> getOnboardingCommonEvent2(String businessLine) throws IOException, ClassNotFoundException {
        log.info("BoilerplateService : getOnboardingCommonEvent");

        List<CommonOnBoardingEvent> responseCommonOnBoardingEvents = new ArrayList<CommonOnBoardingEvent>();
        List<CommonOnBoardingEvent> commonOnBoardingEventsStack2 = new ArrayList<CommonOnBoardingEvent>();

        responseCommonOnBoardingEvents = getOnboardingCommonEventForStack(businessLine, "1");
        if (responseCommonOnBoardingEvents.isEmpty()){
            commonOnBoardingEventsStack2 = getOnboardingCommonEventForStack(businessLine, "2");
        }

        for (CommonOnBoardingEvent events :commonOnBoardingEventsStack2) {
            responseCommonOnBoardingEvents.add(events);
        }
        return responseCommonOnBoardingEvents;
    }

    public List<CommonOnBoardingEvent> getOnboardingCommonEvent(String businessLine) throws IOException, ClassNotFoundException {
        log.info("BoilerplateService : getOnboardingCommonEvent");

        List<CommonOnBoardingEvent> responseCommonOnBoardingEvents = new ArrayList<CommonOnBoardingEvent>();
        List<CommonOnBoardingEvent> commonOnBoardingEventsStack2 = new ArrayList<CommonOnBoardingEvent>();

        Optional<String> user = AppUtil.getCurrentUser();
//        JsonObject userDetail = bpmService.testCloudGetUserDetails(user.get(), "1");
//        log.info("BoilerplateService : getOnboardingCommonEvent - UserDetails response : "+userDetail);
//
//        JsonObject teamTask = bpmService.testCloudGetTeamTasks("1");
//        log.info("BoilerplateService : getOnboardingCommonEvent - teamTask response : "+teamTask);
//
//        return responseCommonOnBoardingEvents;
        responseCommonOnBoardingEvents = getOnboardingCommonEventForStack(businessLine, "1");
        if (responseCommonOnBoardingEvents.isEmpty()){
            commonOnBoardingEventsStack2 = getOnboardingCommonEventForStack(businessLine, "2");
            return commonOnBoardingEventsStack2;
        }else {
            return responseCommonOnBoardingEvents;
        }
    }

    private List<CommonOnBoardingEvent> getOnboardingCommonEventForStack(String businessLine, String envStack) throws IOException, ClassNotFoundException {
        log.info("BoilerplateService : getOnboardingCommonEventForStack : "+envStack);
        List<CommonOnBoardingEvent> responseCommonOnBoardingEvents = new ArrayList<>();
        String formBody = "[\n" +
                "    {\n" +
                "        \"key\": \"businessLine\",\n" +
                "        \"value\": \""+businessLine+"\",\n" +
                "        \"operation\": \"equal\"\n" +
                "    },\n" +
                "    {\n" +
                "        \"key\": \"eventStage\",\n" +
                "        \"value\": \""+envStack+"\",\n" +
                "        \"operation\": \"equal\"\n" +
                "    }\n" +
                "]";
        String response = this.webClient.post().uri(builder -> builder.path("/v1/common-onboarding-details").build())
                .header(Constants.HEADER_AUTHORIZATION, remoteService.getAuthorization()).body(Mono.just(formBody), String.class)
                .retrieve().bodyToMono(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();


        JsonArray commonOnBoardingEventlist = JsonParser.parseString(Objects.requireNonNull(response)).getAsJsonArray();
        log.info("BoilerplateService : commonOnBoardingEventlist isEmpty() " + commonOnBoardingEventlist.isEmpty() + " for businessLine "+businessLine+" in envStack - "+envStack);

        if(!commonOnBoardingEventlist.isEmpty() ) {
            List<CommonOnBoardingEvent> commonOnBoardingEvents = AppUtil.parseJsonArray(commonOnBoardingEventlist.toString(), CommonOnBoardingEvent.class);
            Optional<String> user = AppUtil.getCurrentUser();
            JsonObject userDetail = bpmService.getUserDetails(user.get(), envStack);
            HashMap<String, String> exposedProcess = bpmService.getExposedProcess(user.get(), envStack);
            Map<String, List<TaskDetail>> processDetailMap = bpmService.getAllProcessDetails(getProcessIds(commonOnBoardingEvents), user.get(), userDetail, exposedProcess, envStack);

            log.info("processDetailMap > "+processDetailMap);
            for (CommonOnBoardingEvent events : commonOnBoardingEvents) {
                if (events.getProcessDetails() != null) {
                    ProcessDetails processdetails = events.getProcessDetails();
                    log.info("getInstanceId() : "+processdetails.getInstanceId());
                    if(processDetailMap.containsKey(processdetails.getInstanceId())) {
                        log.info("Adding the common OnBoarding Event...");
                        processdetails.setTaskDetails(processDetailMap.get(processdetails.getInstanceId()));
                        responseCommonOnBoardingEvents.add(events);
                    }
                }
            }
        }
        log.info("Response : "+responseCommonOnBoardingEvents);
        return responseCommonOnBoardingEvents;
    }

    private List<String> getProcessIds(List<CommonOnBoardingEvent> commonOnBoardingEvents){
        List<String> listOfProcessId = new ArrayList<>();
        for (CommonOnBoardingEvent events : commonOnBoardingEvents) {
            if (events.getProcessDetails() != null) {
                listOfProcessId.add(events.getProcessDetails().getInstanceId());
            }
        }
        return listOfProcessId;
    }

    public void generatePacketAndEmailTrigger(String formBody) {
        // packet generation and email trigger
        String mergedPdfPacket = packetGeneratorService.generatePacket(formBody);
        log.info("calling Email Service to send email");
        emailService.sendPacket(mergedPdfPacket, formBody);
    }
    // Fetch User Roles from camunda API
    public List<String> getListOfUserGroup(String userId) {
        log.info("userId: {}", userId);
        String urlString = boilerplateCamundaServiceBaseUrl + boilerplateCamundaServiceGroupsByUserIdUrl;
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("User-ID",userId);
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> listOfUserGroup = new ArrayList<>();
        try {
            ResponseEntity<String> response = camundaRemoteService.execute(urlString, HttpMethod.GET,
                    null, urlParams, headers, true);
            log.info("response : "+ response.getBody());
            if (response != null) {
                log.info("List of Group response : {}", response.getBody());
                JsonArray responseData = JsonParser.parseString(response.getBody()).getAsJsonArray();

                Gson converter = new Gson();
                Type type = new TypeToken<List<String>>(){}.getType();
                listOfUserGroup =  new Gson().fromJson(responseData, type );

                // listOfUserGroup = objectMapper.readValue(response.getBody(), new TypeReference<List<String>>(){});
            }

            return listOfUserGroup;
        } catch (Exception e) {
            log.error("Error occurred in: calling boilarPlate Camunda BPM API List of Group process: call failed", e);
            return listOfUserGroup;
        }
    }
   /* public List<String> getListOfUserGroup(String userId) {
        log.info("userId: {}", userId);
        String urlString = boilerplateCamundaServiceBaseUrl + boilerplateCamundaServiceGroupsByUserIdUrl;
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("userId", userId);
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(urlString);
        String url = builder.buildAndExpand(pathVar).toUri().toString();
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        ObjectMapper objectMapper = new ObjectMapper();
        List<String> listOfUserGroup = new ArrayList<>();

        try {
            ResponseEntity<String> camundaResponse = camundaRemoteService.execute(url, HttpMethod.GET, null, urlParams, headers, true);
            if(camundaResponse == null) {
                log.info("Empty/blank response from api call " + url);
            }
            log.info("List of Group response : {}", camundaResponse.getBody());
            listOfUserGroup = objectMapper.readValue(camundaResponse.getBody(), ArrayList.class);
            return listOfUserGroup;
        } catch (Exception e) {
            log.error("Error occured in: calling BoilarPlate BPM API List of Group process: call failed", e);
            return listOfUserGroup;
        }
    }*/

    public ResponseEntity<String> getAuditTrail(Long onboardingId) {
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("onboardingId", String.valueOf(onboardingId));
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        headers.addAll(headersMap);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
        return remoteService.execute(auditBaseUrl + auditServiceFormDataUrl, HttpMethod.GET, null, urlParams, headers, false);
    }

    public void addAudit(String onboardingId, Map<String, Object> auditMap) {
        auditService.auditDetails(Long.parseLong(onboardingId), auditMap);
    }

    public String  getCommonOnboardingEventList(String authorization, String onboardingType, String userRole, String pageName, String typeName) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("onboardingType", onboardingType);
        urlParams.add("userRole", userRole);
        urlParams.add("pageName", pageName);
        urlParams.add("typename", typeName);
        //return remoteService.execute(eventBaseUrl + "/v1/metadata", HttpMethod.GET, null, urlParams, headers, true);
        String response = this.webClient.get().uri(builder -> builder.path("/v4/metadata").queryParams(urlParams).build())
                .header(Constants.HEADER_AUTHORIZATION, authorization)
                .retrieve().bodyToMono(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();
        return response;
    }

    public String  getTableMetadata(String authorization, String onboardingType, String userRole, String pageName, String typeName) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("onboardingType", onboardingType);
        urlParams.add("userRole", userRole);
        urlParams.add("pageName", pageName);
        urlParams.add("typename", typeName);
        //return remoteService.execute(eventBaseUrl + "/v1/metadata", HttpMethod.GET, null, urlParams, headers, true);
        String response = this.webClient.get().uri(builder -> builder.path("/v4/metadata").queryParams(urlParams).build())
                .header(Constants.HEADER_AUTHORIZATION, authorization)
                .retrieve().bodyToMono(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();

  // BusinessLine logic here if required
        return response;
    }

    public List<Events> getOnboardingEvents(String onboardingType, String currentUser, String taskType, String userRole ) throws JsonProcessingException {
        String eventSteps = getRefs(Constants.REF_TYPE_ID);
        List<Events> uoListOfEvents;
        uoListOfEvents = getOnboardingEvents(onboardingType, taskType, currentUser, eventSteps,userRole);
        return uoListOfEvents;
    }

    public String getRefs(String typeId) {
        ResponseEntity<String> response;
        try {
            response = getRefsbyTypeId(Integer.parseInt(typeId));
            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                throw new ServiceException("Error getting Refs");
            }
            return response.getBody();
        } catch (Exception e) {
            log.error("Error occurred in: getRefs.", e);
            throw new ServiceException(e.getMessage());
        }
    }
    public ResponseEntity<String> getRefsbyTypeId(Integer typeId) {
        ResponseEntity<String> responseEntity = null;
        Map<String, Integer> pathVar = new HashMap<>();
        pathVar.put("typeId", typeId);
        String uriString = formBaseUrl + refsByTypeId;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        String uri = builder.buildAndExpand(pathVar).toString();
        log.debug("getRefsbyTypeId .... uri=" + uri);
        try {
            responseEntity = remoteService.execute(uri, HttpMethod.GET, null, null, null, true);
        } catch (Exception exp) {
            log.error("Error occurred in: getRefsbyTypeId.", exp);
            throw new ServiceException(exp.getMessage());
        }
        return responseEntity;
    }
    public List<Events> getOnboardingEvents(String onboardingType, String taskType, String currentUser, String eventSteps, String userRole) throws JsonProcessingException {
        //Fetch from UO_Datapoint
        ObjectMapper objectMapper = new ObjectMapper();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add(Constants.BUSINESS_LINE, onboardingType);
        urlParams.add("typeName", "TableMetaData");
        urlParams.add("taskType",  taskType);
        String formBody = formulateBody(onboardingType, taskType, currentUser,userRole);
        JsonArray eventTasks = null;
        JsonParser jsonParser = new JsonParser();
        try {
            ResponseEntity<String> response = remoteService.execute(
                    eventBaseUrl + fetchOnboardingEventsDetails, HttpMethod.POST, formBody, urlParams, headers, true);
            log.info("response from uoonboardingevents**** " + response);
            eventTasks = (JsonArray) jsonParser.parse(response.getBody());
        } catch (Exception e) {
            throw new ServiceException(e.getMessage());
        }
        List<String> listOfOnboardings = fetchOnboardingIdList(eventTasks);
        return mergeEventsTasksData(listOfOnboardings, taskType, eventSteps,  eventTasks.toString(), false);
    }

    private List<Events> mergeEventsTasksData(List<String> listOfOnboardings, String taskType, String eventSteps, String eventTasks, boolean b) {
        List<Events> finalListOfEvents = new ArrayList<>();
        // Write BusinessLine specific code here
        JsonArray dpobject = new JsonArray();
        dpobject = JsonParser.parseString(eventTasks).getAsJsonArray();
        List<Events> eventList = new ArrayList<>();
        for (JsonElement element : dpobject) {
            List<String> clientList = new ArrayList<>();
            Events event = new Events();
            JsonObject objectDetails = JsonParser.parseString(element.toString()).getAsJsonObject();
            event.setOnboardingId(Long.parseLong(!objectDetails.has(Constants.ONBOARDING_ID) || objectDetails.get(Constants.ONBOARDING_ID).isJsonNull() ? ""
                    : objectDetails.get(Constants.ONBOARDING_ID).getAsString()));
            event.setCustomerAccountName(!objectDetails.has(Constants.ACCOUNT_NAME) || objectDetails.get(Constants.ACCOUNT_NAME).isJsonNull() ? ""
                    : objectDetails.get(Constants.ACCOUNT_NAME).getAsString());
            event.setAccountNumber(!objectDetails.has(Constants.ACCOUNT_NUMBER) || objectDetails.get(Constants.ACCOUNT_NUMBER).isJsonNull() ? "TBD"
                    : objectDetails.get(Constants.ACCOUNT_NUMBER).getAsString());
            event.setAccountType(!objectDetails.has(Constants.MAJOR_ACCOUNT_TYPE) || objectDetails.get(Constants.MAJOR_ACCOUNT_TYPE).isJsonNull() ? "TBD"
                    : objectDetails.get(Constants.MAJOR_ACCOUNT_TYPE).getAsString());
            event.setControlID(!objectDetails.has(Constants.LOCATION) || objectDetails.get(Constants.LOCATION).isJsonNull() ? ""
                    : objectDetails.get(Constants.LOCATION).getAsString());
            event.setMinorAccountType(!objectDetails.has(Constants.MINOR_ACCOUNT_TYPE) || objectDetails.get(Constants.MINOR_ACCOUNT_TYPE).isJsonNull() ? ""
                    : objectDetails.get(Constants.MINOR_ACCOUNT_TYPE).getAsString());

            event.setEventStage(!objectDetails.has(Constants.EVENT_STAGE) || objectDetails.get(Constants.EVENT_STAGE).isJsonNull() ? ""
                    : objectDetails.get(Constants.EVENT_STAGE).getAsString());
            event.setAccountStatus(!objectDetails.has(Constants.ACCOUNT_STATUS) || objectDetails.get(Constants.ACCOUNT_STATUS).isJsonNull() ? ""
                    : objectDetails.get(Constants.ACCOUNT_STATUS).getAsString());
            event.setServiceLevel(!objectDetails.has(Constants.SERVICE_LEVEL) || objectDetails.get(Constants.SERVICE_LEVEL).isJsonNull() ? ""
                    : objectDetails.get(Constants.SERVICE_LEVEL).getAsString());
            event.setSubmitterName(!objectDetails.has(Constants.SUBMITTER_NAME) || objectDetails.get(Constants.SUBMITTER_NAME).isJsonNull() ? ""
                    : objectDetails.get(Constants.SUBMITTER_NAME).getAsString());
            event.setTask("taskName");
            event.setOnboardingEventType(!objectDetails.has(Constants.ONBOARDING_EVENTTYPE) || objectDetails.get(Constants.ONBOARDING_EVENTTYPE).isJsonNull() ? ""
                    : objectDetails.get(Constants.ONBOARDING_EVENTTYPE).getAsString());
            event.setReturnComments(!objectDetails.has(Constants.RETURN_COMMENTS) || objectDetails.get(Constants.RETURN_COMMENTS).isJsonNull() ? ""
                    : objectDetails.get(Constants.RETURN_COMMENTS).getAsString());
            eventList.add(event);
        }
        finalListOfEvents.addAll(eventList);
        return finalListOfEvents;
    }

    public List<String> fetchOnboardingIdList(JsonArray myTasksResponseCore) {
        List<String> onboardingIdList = new ArrayList<>();
        myTasksResponseCore.forEach(task -> {
            if (null != task) {
                onboardingIdList.add(Long.toString(task.getAsJsonObject().get("onboardingId").getAsLong()));
            }
        });
        onboardingIdList.removeAll(Collections.singleton("null"));
        return onboardingIdList;
    }
    private String formulateBody(String businessLine, String taskType, String currentUser, String userRole) {
        List<SearchCriteria> filters = new ArrayList<>();
        SearchCriteria criteria = null;
        String json = null;

        if (businessLine != null) {
            criteria = new SearchCriteria("businessLine", businessLine, "equal");
            filters.add(criteria);
        }

    //Write business line specific logic here

        if (taskType != null && taskType.equals(Constants.MY_TASKS)) {
            criteria = new SearchCriteria(userId, currentUser, "equal");
            filters.add(criteria);
        } else if (taskType != null && taskType.equals(Constants.TEAM_TASKS)) {
            criteria = new SearchCriteria(userId, currentUser, "equal");
            filters.add(criteria);
        } else if (taskType != null && taskType.equals(Constants.OTHER_TASKS)) {
            criteria = new SearchCriteria(userId, currentUser, "not_equal");
            filters.add(criteria);
        }
        ObjectMapper mapper = new ObjectMapper();
        try {
            log.info("filters ==> Begin" + filters.size());
            filters.forEach(item -> log.info("ITEM => " + item.toString()));
            json = mapper.writeValueAsString(filters);
        } catch (JsonProcessingException exception) {
            log.error("Error occourred in formulateBody()",exception);
            exception.getMessage();
        }

        return json;
    }
    public List<EventTasks> getEventTasks(String onboardingType, String currentUser, String onboardingId) {
        log.info("in getEventTasks() of OnboardingService..onboardingId= "+onboardingId);
        List<EventTasks> eventTasks = new ArrayList<>();
        //TODO: Write BusinessLine specific code here
        List<EventTasks> mergedEventTasks = new ArrayList<>();
        try {
            populateMergeEventTasks(mergedEventTasks,onboardingId,currentUser);
        }catch (Exception e) {
            log.error("Error occurred in getEventTasks ", e);
            throw new ServiceException(e.getMessage());
        }
        return  mergedEventTasks;
    }
    protected void populateMergeEventTasks(List<EventTasks> mergedEventTasks, String onboardingId,String currentUser) throws IOException, ClassNotFoundException {
        MultiValueMap<String, String> urlParams =new LinkedMultiValueMap<>();
        urlParams.add("onboardingId",onboardingId);
        ResponseEntity<String> response = null;
        try {
            response = taskClient.get().uri(builder -> builder.path("/v1/checklist").queryParams(urlParams).build())
                    .header(Constants.HEADER_AUTHORIZATION,  request.getHeader("Authorization"))
                    .retrieve().toEntity(String.class).onErrorMap(e -> new ServiceException(e.getMessage())).block();
        } catch (Exception e) {
            throw new ServiceException(e.getMessage());
        }
        JsonArray uoChecklist = JsonParser.parseString(Objects.requireNonNull(response.getBody())).getAsJsonArray();
        //TODO: Write BusinessLine specific code here
        List<EventTasks> uoEventTasks = AppUtil.parseJsonArray(uoChecklist.toString(), EventTasks.class);
        mergedEventTasks.addAll(uoEventTasks);
    }

}
