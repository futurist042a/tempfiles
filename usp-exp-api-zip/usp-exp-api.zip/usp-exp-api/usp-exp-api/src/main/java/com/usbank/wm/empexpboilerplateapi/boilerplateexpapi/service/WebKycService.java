package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;



import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Base64;
import java.util.UUID;


@Service
public class WebKycService {

  @Autowired
  private RemoteService remoteService;

  @Value("${webkyc.service.base.url}")
  private String baseUrl;

  @Value("${webkyc.rest.v1.partySearch}")
  private String partySearchUrl;

  @Value("${webkyc.rest.v1.customerProfile}")
  private String customerProfileUrl;

  @Value("${webkyc.getCustomerResponse.clientId}")
  private String clientId;

  @Value("${webkyc.getCustomerResponse.clientSecret}")
  private String clientSecret;

  @Value("${policyYear}")
  private String policyYear;

  @Value("${lastUpdatedDateRange}")
  private Long lastUpdatedDateRange;

  Logger logger = LoggerFactory.getLogger(WebKycService.class);
  public static final String DEFAULT_TIME_ZONE = "America/Chicago";

  public String searchWebKYCParties(String searchValue, String searchType, String onboardingType) {
    ResponseEntity<String> response = null;
    MultiValueMap<String, String> urlHeaders = new LinkedMultiValueMap<>();

    try {
      // create auth credentials
      String authStr = clientId + ":" + clientSecret;
      String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());
      // create headers
      urlHeaders.add("Authorization", "Basic " + base64Creds);

      String url = baseUrl + partySearchUrl;
      String entityNameSearch="";
      String entityTinSearch="";

      if(StringUtils.isNumericSpace(searchValue)){
        entityTinSearch=searchValue.replaceAll("\\s", "");
      }else if(AppUtil.isValidTxnID(searchValue)) {
        entityTinSearch=searchValue;
        entityTinSearch=entityTinSearch.replaceAll("-","");
      }else{
        entityNameSearch = searchValue;
      }

      String lastUpdatedDateTo = Instant.now().atZone(ZoneId.of(DEFAULT_TIME_ZONE))
              .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));
      String lastUpdatedDateFrom = Instant.now().minus(lastUpdatedDateRange.longValue(),ChronoUnit.DAYS)
              .atZone(ZoneId.of(DEFAULT_TIME_ZONE)).format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));

      JSONObject requestBody = null;
      if("boilerplate".equalsIgnoreCase(onboardingType))
      {
        lastUpdatedDateFrom = Instant.now().minus(365,ChronoUnit.DAYS)
                .atZone(ZoneId.of(DEFAULT_TIME_ZONE)).format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT));

        requestBody =
                new JSONObject()
                        .put(Constants.TRANSACTION_IDENTIFIER, UUID.randomUUID())
                        .put(Constants.MESSAGE_SUBMISSION_DATA_TIME, LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS))
                        .put(Constants.MESSAGE_TYPE_CODE, Constants.REQUEST)
                        .put(Constants.END_USER_IDENTIFIER, AppUtil.getCurrentUser().orElse(Constants.UNKNOWN))
                        .put(Constants.CUSTOMER_NAME, entityNameSearch)
                        .put(Constants.TAXID, entityTinSearch)
                        .put(Constants.BUSINESSLINE, "")
                        .put(Constants.LAST_UPDATE_RANGE,
                                new JSONObject()
                                        .put(Constants.FROMDATE,lastUpdatedDateFrom)
                                        .put(Constants.TODATE,lastUpdatedDateTo))
                        .put(Constants.JSON_STATUS,
                                new JSONArray()
                                        .put("IMAGE_PENDING")
                                        .put("ON_HOLD")
                                        .put("BL_AML_REVIEW")
                                        .put("LEGACY")
                                        .put("RETURNED")
                                        .put("EDD_REVIEW")
                                        .put("REVIEW_PENDING")
                                        .put("DRAFT")
                                        .put("RISK_RATING_APPROVAL_PENDING")
                                        .put("INPROCESS")
                                        .put("CORP_AML_REVIEW")
                                        .put("COMPLETE")
                                        .put("KYC_FAILED")
                                        .put("OFAC_FAIL")
                                        .put("ID_PENDING")
                                        .put("DELETED")
                                        .put("SR_REVIEW"))
                        .put(Constants.FETCH_LATEST_RECORD,true);
      }

      logger.info("webkyc party search request body: " + ((requestBody!=null) ? requestBody.toString():null));

      if(requestBody!=null){
        response =
                remoteService.executeWithMTLS(
                        url, HttpMethod.POST, requestBody.toString(), null, urlHeaders);
      }

      if (response == null || !response.getStatusCode().is2xxSuccessful()) {
        throw new ServiceException("Error getting customer response from WebKYC: " + searchValue);
      }

      logger.info("webkyc party search response :: " + response.getBody());
      return response.getBody();

    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
  }

  public String getCustomerResponse(String webkycId) {
    ResponseEntity<String> response = null;
    MultiValueMap<String, String> urlHeaders = new LinkedMultiValueMap<>();

    try {
      // create auth credentials
      String authStr = clientId + ":" + clientSecret;
      String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());

      // create headers
      urlHeaders.add("Authorization", "Basic " + base64Creds);

      String url = baseUrl + customerProfileUrl;
      logger.info("webkyc customerResponse URI: " + url);

      JSONObject requestBody =
              new JSONObject()
                      .put(Constants.TRANSACTION_IDENTIFIER, UUID.randomUUID())
                      .put(Constants.CHANNEL_TYPE, "")
                      .put(Constants.MESSAGE_SUBMISSION_DATA_TIME, LocalDateTime.now().truncatedTo(ChronoUnit.SECONDS))
                      .put(Constants.MESSAGE_TYPE_CODE, Constants.REQUEST)
                      .put(Constants.SESSION_ID, "")
                      .put(Constants.SERVER_IDENTIFIER, "")
                      .put(Constants.END_USER_IDENTIFIER, AppUtil.getCurrentUser().orElse(Constants.UNKNOWN))
                      .put("WebKYCID", webkycId)
                      .put("FetchBeneficialOwners", "true");
      logger.info("webkyc customerResponse request body: " + requestBody.toString());

      response =
              remoteService.executeWithMTLS(
                      url, HttpMethod.POST, requestBody.toString(), null, urlHeaders);

      if (response == null || !response.getStatusCode().is2xxSuccessful()) {
        throw new ServiceException("Error getting customer response for WebKYC ID: " + webkycId);
      }

      logger.info("webkyc customerResponse response: " + response.getBody());
      return response.getBody();

    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
  }
}