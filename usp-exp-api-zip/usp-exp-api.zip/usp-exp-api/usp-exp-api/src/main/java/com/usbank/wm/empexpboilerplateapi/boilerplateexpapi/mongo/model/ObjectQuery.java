package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.model;

import lombok.Data;

@Data
public class ObjectQuery {
    private String System;
    private String Collection;
    private String Query;
    private String Alias;
}
