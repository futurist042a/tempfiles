package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.mongo;

import org.springframework.data.mongodb.core.mapping.Document;
import org.bson.types.ObjectId;
import lombok.Data;

import java.util.List;

@Document(collection = "USP_FORMS")
@Data // Lombok annotation to generate getters, setters, and toString()
public class Form {
    private ObjectId id;
    private String appName;
    private String screen;
    private String section;
    private String uicomponent;
    private String searchKey;
    private List formJson;
}
