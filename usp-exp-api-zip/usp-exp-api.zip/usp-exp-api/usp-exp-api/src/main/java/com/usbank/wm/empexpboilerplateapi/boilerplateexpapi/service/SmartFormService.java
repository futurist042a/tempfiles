package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BusinessException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.OnboardingEvent;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;

import java.util.*;

import java.util.stream.Collectors;


@Service
@Slf4j
public class SmartFormService {

    @Autowired
    private RemoteService remoteService;

    @Value("${form.service.baseurl}")
    private String formBaseUrl;

    @Value("${form.service.GetFormDataUrl}")
    private String formServiceGetFormDataUrl;

    @Value("${form.service.tab.api}")
    private String formTabsTabNameApi;

    @Value("${form.service.getDataPointUrl}")
    private String getDataPointUrl;

    @Value("${form.service.dataPoint.checkListApi}")
    private String dataPointCheckListApi;

    @Value("${form.service.FormDataUrl}")
    private String formServiceFormDataUrl;

    @Value("${event.service.baseurl}")
    private String eventServiceBaseurl;

    @Value("${event.service.fetchOnboardingEventsDetails.list}")
    private String fetchOnbaordingEventDetailsForListUrl;

    public ResponseEntity<Object> getForm(String formName, String tabName, String businessLine, String formType,
                                          boolean isActive) {
        log.info("inside SmartFormService::getForm method");
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();

        urlParams.add(Constants.FORM_NAME, formName);
        urlParams.add(Constants.TAB_NAME, tabName);
        urlParams.add(Constants.IS_ACTIVE, "true");
        urlParams.add(Constants.BUSINESS_LINE, businessLine);
        urlParams.add(Constants.FORM_TYPE, formType);
        MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
        HttpHeaders headers = new HttpHeaders();
        headers.addAll(headersMap);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
        try {
            response = remoteService.execute(formBaseUrl + formServiceGetFormDataUrl, HttpMethod.GET, null, urlParams,
                    headers, false);
        } catch (Exception e) {
            throw new BusinessException(e.getMessage());
        }
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
    }
    public ResponseEntity<String> saveChecklistAndAuditTrail(Long onboardingId, Map<String, Object> requestBody,
                                                             String fundId, String advisorId, String classId, boolean isSubmit, String businessLine, String checklistId) {
        log.info("inside SmartFormService::saveChecklistAndAuditTrail method");
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> headers;
        headers = new LinkedMultiValueMap<>();

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();

        urlParams.add(Constants.CHECKLIST_ID, checklistId);
        urlParams.add(Constants.FUND_ID, fundId);
        urlParams.add(Constants.ADVISOR_ID, advisorId);
        urlParams.add(Constants.CLASS_ID, classId);
        urlParams.add(Constants.BUSINESS_LINES, businessLine);
        try {
            response = remoteService.fetch(onboardingId, formBaseUrl + dataPointCheckListApi, HttpMethod.POST,
                    requestBody, urlParams, headers);
            // Below method is for specific business line
//            updateMilestoneForCRF(Long.toString(onboardingId), checklistId);

            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                log.error("Error occurred in: saveChecklistAndAuditTrail ", formBaseUrl, formTabsTabNameApi + " call failed");
            }
            return new ResponseEntity<>(response != null ? response.getBody() : null, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred in: saveChecklistAndAuditTrail ", e);
            throw new ServiceException(e.getMessage());
        }
    }

    public JsonObject getDetailPageHeaderData(Long onboardingId, String checkListId) {
        log.info("inside SmartFormService::getDetailPageHeaderData method");
        JsonObject values = new JsonObject();

        JsonArray dataPointsJson = getDataPoints(onboardingId, Constants.MARKETER_DETAIL_PAGE_DATAPOINT_ID, checkListId);
        log.info("dataPoints: {}", dataPointsJson);
        for (JsonElement dataPoint : dataPointsJson) {
            String dataPointName = dataPoint.getAsJsonObject().get(Constants.SOURCE_SYSTEM_DP_ID).getAsString();
            if (!dataPoint.getAsJsonObject().get(Constants.OBJ_VALUE).isJsonObject()) {
                String dataPointValue = dataPoint.getAsJsonObject().get(Constants.VALUE).getAsString();
                values.addProperty(dataPointName, dataPointValue);
            } else {
                JsonElement dataPointValue = dataPoint.getAsJsonObject().get(Constants.OBJ_VALUE);
                values.add(dataPointName, dataPointValue);
            }
        }
        return getDetailPageData(values, onboardingId, getOnboardingList(onboardingId.toString()));
    }
    /**
     * Method to get Detail Page Data
     *
     * @param values
     * @param onboardingId
     * @param onboardingList
     * @return
     */
    public JsonObject getDetailPageData(JsonObject values, Long onboardingId, List<OnboardingEvent> onboardingList) {
        log.info("inside SmartFormService::getDetailPageData method");
        JsonObject detailPageHeaderData = new JsonObject();

        detailPageHeaderData.addProperty(Constants.ONBOARDINGID, String.valueOf(onboardingId));
        detailPageHeaderData.add(Constants.CLIENTLEGALNAME, values.get(Constants.CLIENTDETAILS_LEGALNAME));

        String marketerName = (values.has(Constants.MARKETER_NAME) &&
                !values.get(Constants.MARKETER_NAME).isJsonNull() &&
                !values.get(Constants.MARKETER_NAME).getAsString().isEmpty()) ?
                values.get(Constants.MARKETER_NAME).getAsString() : "";
        detailPageHeaderData.addProperty(Constants.MARKETER, AppUtil.getOnlyNameFromString(marketerName));

        String negotiatorName = (values.has(Constants.NEGOTIATOR) &&
                !values.get(Constants.NEGOTIATOR).isJsonNull() &&
                !values.get(Constants.NEGOTIATOR).getAsString().isEmpty()) ?
                values.get(Constants.NEGOTIATOR).getAsString() : "";
        detailPageHeaderData.addProperty(Constants.NEGOTIATOR_GROUP, AppUtil.getOnlyNameFromString(negotiatorName));

        String rmName = (values.has(Constants.RMNAME) &&
                !values.get(Constants.RMNAME).isJsonNull() &&
                !values.get(Constants.RMNAME).getAsString().isEmpty()) ?
                values.get(Constants.RMNAME).getAsString() : "";
        detailPageHeaderData.addProperty(Constants.RM, AppUtil.getOnlyNameFromString(rmName));
        detailPageHeaderData.add(Constants.PRODUCT, values.getAsJsonObject(Constants.PRODUCT_TYPE).get(Constants.VALUE));

        JsonArray eventProgressStatus = new JsonArray();
        eventProgressStatus.add(Constants.DERIVATIVES_CUSTOMER_PROFILE);
        eventProgressStatus.add(Constants.KYC_DOCUMENTATION);
        eventProgressStatus.add(Constants.ISDA);
        eventProgressStatus.add(Constants.CREDIT_LIMIT_APPROVAL);
        eventProgressStatus.add(Constants.DODD_FRANK_PACKET);
        eventProgressStatus.add(Constants.GREEN_LIGHT_MEMO);
        detailPageHeaderData.add(Constants.EVENT_PROGRESS_STAGE, eventProgressStatus);

        if (onboardingList.get(Constants.ZERO).getStatus().equalsIgnoreCase(Constants.UO_DRAFT) ||
                onboardingList.get(Constants.ZERO).getStatus().equalsIgnoreCase(Constants.UO_SUBMIT)) {
            detailPageHeaderData.add(Constants.EVENT_STAGE, eventProgressStatus.get(Constants.ZERO));
        } else if (onboardingList.get(Constants.ZERO).getStatus().equalsIgnoreCase(Constants.UO_APPROVE)) {
            detailPageHeaderData.add(Constants.EVENT_STAGE, eventProgressStatus.get(Constants.ONE));
        }
        return detailPageHeaderData;
    }
    public JsonArray getDataPoints(Long onboardingId, String dataPointIds, String checklistId) {
        log.info("inside SmartFormService::getDataPoints method");
        ResponseEntity<String> response;

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(Constants.HEADER_ONBOARDING_ID, Long.toString(onboardingId));

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add("datapointIds", dataPointIds);
        if (!ObjectUtils.isEmpty(checklistId)) {
            urlParams.add("checklistId", checklistId);
        }
        try {
            response = remoteService.fetch(onboardingId, formBaseUrl + getDataPointUrl, HttpMethod.GET, null, urlParams,
                    null);
            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                log.error("Error occurred in: getDataPoints.", formBaseUrl, getDataPointUrl, " call failed");
            }
            return JsonParser.parseString(response.getBody()).getAsJsonArray();
        } catch (Exception e) {
            log.error("Error occurred in: getting a datapoints.", e);
            throw new ServiceException(e.getMessage());
        }
    }
    public List<OnboardingEvent> getOnboardingList(String onboardingId) {
        log.info("inside SmartFormService::getOnboardingList method");
        List<OnboardingEvent> onboardingEvent = null;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
            MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
            urlParams.add(Constants.ONBOARDING_IDS, onboardingId.toString());
            ResponseEntity<String> response = remoteService.execute(
                    eventServiceBaseurl + fetchOnbaordingEventDetailsForListUrl, HttpMethod.GET, null, urlParams, headers, true);
            if (response == null || !response.getStatusCode().is2xxSuccessful() || response.getBody().isEmpty()) {
                log.error("Error occurred in: getting onboarding table data.", eventServiceBaseurl, fetchOnbaordingEventDetailsForListUrl, " call failed");
            }
            onboardingEvent = objectMapper.readValue(response.getBody(), new TypeReference<List<OnboardingEvent>>() {
            });
        } catch (Exception e) {
            log.error("Error occurred in: getting a onboarding table data.", e.getMessage());
            throw new ServiceException(e.getMessage());
        }

        return onboardingEvent;
    }

    public ResponseEntity<String> saveFormTabData(Long onboardingId, String formName, String tabName,
                                                  Map<String, Object> requestBody, String accountId, String checklistId, String fundId, String advisorId,
                                                  String classId, String businessLine) {
        log.info("inside SmartFormService::saveFormTabData method");
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> headers;
        headers = new LinkedMultiValueMap<>();
        headers.add(Constants.HEADER_ACCOUNT_ID, accountId);
        if (null != onboardingId) {
            headers.add(Constants.HEADER_ONBOARDING_ID, onboardingId + "");
        }
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add(Constants.CHECKLIST_ID, checklistId);
        urlParams.add(Constants.FUND_ID, fundId);
        urlParams.add(Constants.ADVISOR_ID, advisorId);
        urlParams.add(Constants.CLASS_ID, classId);
        urlParams.add(Constants.BUSINESS_LINE, businessLine);

        try {
            response = remoteService.fetch(onboardingId,
                    formBaseUrl + formTabsTabNameApi + formName + "/tabs/" + tabName + "?", HttpMethod.POST,
                    requestBody, urlParams, headers);
            if (response == null || !response.getStatusCode().is2xxSuccessful()) {
                log.error("Error occurred in: saveForm.", formBaseUrl, formTabsTabNameApi + " call failed");
            }
            return new ResponseEntity<>(response != null ? response.getBody() : null, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error occurred in: saving a form.", e);
            throw new ServiceException(e.getMessage());
        }
    }

    public JsonObject getFormTabData(Long onboardingId, String accountId, String formName, String tabName,
                                     String checklistId, String businessLine, String fundId, String advisorId, String classId) {
        log.info("inside SmartFormService::getFormTabData method");
        ResponseEntity<String> response;
        String defaultDataPointsIds;
        List<String> dataPointList = new ArrayList<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add(Constants.HEADER_ACCOUNT_ID, accountId);
        if (null != onboardingId) {
            headers.add(Constants.HEADER_ONBOARDING_ID, onboardingId + "");
        }

        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add(Constants.CHECKLIST_ID, checklistId);
        urlParams.add(Constants.BUSINESS_LINES, businessLine);
        urlParams.add(Constants.FUND_ID, fundId);
        urlParams.add(Constants.ADVISOR_ID, advisorId);
        urlParams.add(Constants.CLASS_ID, classId);
        try {
            response = remoteService.fetch(onboardingId,
                    formBaseUrl + formTabsTabNameApi + formName + "/tabs/" + tabName + "?", HttpMethod.GET, null,
                    urlParams, headers);
            if (response == null) {
                log.error("Error occurred in: getForm.", formBaseUrl + formTabsTabNameApi, " call failed");
            }
            JsonObject data= new JsonObject();
            if (response != null && Objects.nonNull(response.getBody())) {
                 data = JsonParser.parseString(Objects.requireNonNull(response.getBody())).getAsJsonObject()
                        .getAsJsonObject(Constants.OBJ_VALUE).getAsJsonObject("data");
                if (data.getAsJsonObject().get(Constants.PREPOPULATED_DATAPOINTS) != null) {
                    JsonObject prepopulatedDataPoints = (JsonObject) data.getAsJsonObject()
                            .get(Constants.PREPOPULATED_DATAPOINTS);
                    for (Object key : prepopulatedDataPoints.keySet()) {
                        dataPointList.add(key.toString());
                    }
                }
            }
            // Need to write businessline logic
            return data;
        } catch (Exception e) {
            log.error("Error occurred in: getting a form.", e);
            throw new ServiceException(e.getMessage());
        }
    }
    public ResponseEntity<Object> getTabs(String formName, String tabName, String businessLine) {
        log.info("inside SmartFormService::getTabs method");
        ResponseEntity<String> response = null;
        MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
        urlParams.add(Constants.FORM_NAME, formName);
        urlParams.add(Constants.TAB_NAME, tabName);
        urlParams.add(Constants.IS_ACTIVE, "true");
        urlParams.add(Constants.BUSINESS_LINE, businessLine);
        HttpHeaders headers = new HttpHeaders();
        try {
            response = remoteService.execute(formBaseUrl + formServiceFormDataUrl, HttpMethod.GET, null, urlParams,
                    headers, true);
        } catch (Exception e) {
            throw new BusinessException(e.getMessage());
        }
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
    }
}
