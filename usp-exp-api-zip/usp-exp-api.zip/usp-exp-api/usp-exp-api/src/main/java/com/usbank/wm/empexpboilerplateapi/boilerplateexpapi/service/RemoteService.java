package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


import java.net.URI;

@Service
@Slf4j
public class RemoteService {

  private static final Logger logger = LoggerFactory.getLogger(RemoteService.class);

  @Autowired
  HttpServletRequest httpServletRequest;

  @Autowired
  @Qualifier("mtlsRestTemplate")
  RestTemplate mtlsRestTemplate;

  @Value("${oauth.token.endpoint}")
  private String accessTokenUrl;

  @Value("${spring.security.oauth2.client.clientId}")
  private String clientId;

  @Value("${spring.security.oauth2.client.clientSecret}")
  private String clientSecret;

  @Value("${onboardingPlatform.clientId}")
  private String onboardingClientId;

  @Value("${onboardingPlatform.clientSecret}")
  private String onboardingClientSecret;

  RestTemplate restTemplate = new RestTemplate();


  public ResponseEntity<String> execute(final String url, HttpMethod httpMethod, String jsonBody,
                                        MultiValueMap<String, String> urlParams, MultiValueMap<String, String> headers,
                                        boolean includeAuthorization) {
    ResponseEntity<String> response = null;
    HttpHeaders httpHeaders = buildHeader(jsonBody, headers, includeAuthorization);
    logRequestDetails(url, httpMethod, jsonBody, urlParams, httpHeaders);

    URI remoteUri =
        UriComponentsBuilder.fromUriString(url).queryParams(urlParams).build().encode().toUri();

    logger.debug("Final remote uri: " + remoteUri.toString());

    HttpEntity<String> request = new HttpEntity<>(jsonBody != null ? jsonBody : null, httpHeaders);

    try {
      response = restTemplate.exchange(remoteUri, httpMethod, request, String.class);
      HttpStatus tempStatus = (HttpStatus)response.getStatusCode();

      if (!tempStatus.is2xxSuccessful()) {
        logError(response);
      }

    } catch (ResourceAccessException rExp) {
      logger.error("Error occurred in: execute.", rExp);
      throw new ServiceException("Unable to access remote service.");
    } catch (HttpClientErrorException httpExp) {
      if (HttpStatus.NOT_FOUND == httpExp.getStatusCode()) {
        return new ResponseEntity<>(httpExp.getMessage(), HttpStatus.NOT_FOUND);
      }
      logger.error("Exception calling remote service: " + httpExp.getResponseBodyAsString());
      throw new ServiceException(httpExp.getMessage());
    } catch (Exception e) {
    	 logger.error("Error occurred in: execute.", e);
      throw new ServiceException(e.getMessage());
    }
    return response;
  }

private void logError(ResponseEntity<String> response) {
	logger.info("Remote API call: ERROR");
	if (response.hasBody()) {
	  JsonArray items = JsonParser.parseString(response.getBody()).getAsJsonArray();
	  for (JsonElement jsonElement : items) {
	    logger.error("=====================Remote API ERROR START==========================");
	    logger.error(jsonElement.getAsJsonObject().get("errorCode").getAsString());
	    logger.error(jsonElement.getAsJsonObject().get("message").getAsString());
	    logger.error("=====================Remote API ERROR END==========================");
	  }
	}
}

private void logRequestDetails(final String url, HttpMethod httpMethod, String jsonBody,
		MultiValueMap<String, String> urlParams, HttpHeaders httpHeaders) {
	logger.info("Executing remote api call: " + url);
    logger.info("HttpMethod method:{} ", httpMethod != null ? httpMethod : "null");
    logger.info("Url params:{} ", urlParams != null ? urlParams.values().toString() : "null");
    logger.info("Url headers: {}", httpHeaders != null ? httpHeaders.values().toString() : "null");
    logger.debug("Request body:{} ", jsonBody != null ? jsonBody : "null");
}

private HttpHeaders buildHeader(String jsonBody, MultiValueMap<String, String> headers, boolean includeAuthorization) {
	HttpHeaders httpHeaders = new HttpHeaders();
    if (includeAuthorization) {
      httpHeaders.add("Authorization", getAuthorization());
    }
    if (headers != null) {
      httpHeaders.addAll(headers);
    }
    if (!ObjectUtils.isEmpty(jsonBody) && !httpHeaders.containsKey("Content-Type")) {
      httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    }
	return httpHeaders;
}

  public String getAuthorization() {
   // log.info("getAuthorization()");
    try {
      String authorization = httpServletRequest.getHeader(Constants.HEADER_AUTHORIZATION);
      //log.info("getAuthorization() : authorization - "+authorization);
      if (!ObjectUtils.isEmpty(authorization) && !authorization.contains("Basic")) {
        //log.info("getAuthorization() : Returning existing one ");
        return authorization;
      }
    } catch (Exception ex) {
      logger.debug("Error fetching authorization");
      return getNewAccessToken();
    }
    return getNewAccessToken();
  }

  public String getNewAccessToken() {
    //log.info("Getting new access token from ping: ");
    ResponseEntity<String> response = null;
    RestTemplate restTemplateToken = new RestTemplate();
    HttpHeaders httpHeaders = new HttpHeaders();

    httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
    requestBody.add("grant_type", "client_credentials");
    requestBody.add("client_id", clientId);
    requestBody.add("client_secret", clientSecret);
    log.info("client_id : "+clientId+" , clientSecret : "+clientSecret);
    //log.info("New access token url: " + accessTokenUrl);
    try {
      response = restTemplateToken.exchange(accessTokenUrl, HttpMethod.POST,
          new HttpEntity<>(requestBody, httpHeaders), String.class);

      if (!response.getStatusCode().is2xxSuccessful()) {
        log.info("Get New token call: ERROR");
        if (response.hasBody()) {
          JsonArray items = JsonParser.parseString(response.getBody().toString()).getAsJsonArray();
          for (JsonElement jsonElement : items) {
            log
                .error("=====================Get New token ERROR START==========================");
            log.error(jsonElement.getAsJsonObject().get("errorCode").getAsString());
            log.error(jsonElement.getAsJsonObject().get("message").getAsString());
            log.error("=====================Get New token ERROR END==========================");
          }
        }
      }
      //log.info("New access token response: " + response.getBody().toString());
      String tokenType = JsonParser.parseString(response.getBody().toString()).getAsJsonObject()
          .get("token_type").getAsString();
      String accessToken = JsonParser.parseString(response.getBody().toString()).getAsJsonObject()
          .get("access_token").getAsString();
      return tokenType + " " + accessToken;
    } catch (Exception exp) {
      log.error("Error occurred in: getNewAccessToken.", exp);
      throw new ServiceException(exp.getMessage());
    }
  }

  public ResponseEntity<String> fetch(final Long onboardingId, String uri, HttpMethod httpMethod,
      Object requestObject, MultiValueMap<String, String> urlParams,
      MultiValueMap<String, String> additionalHeaders) {
	    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    if (null != onboardingId) {
      headers.add(Constants.HEADER_ONBOARDING_ID, onboardingId + "");
    }
    if (null != additionalHeaders) {
      headers.addAll(additionalHeaders);
    }
    return fetch(uri, httpMethod, requestObject, urlParams ,headers);
  }

  private ResponseEntity<String> fetch(String uri, HttpMethod httpMethod, Object requestObject,
      MultiValueMap<String, String> urlParams , MultiValueMap<String, String> headers) {
    ResponseEntity<String> response;
    headers.add(Constants.HEADER_CORRELATION_ID,
    		 AppUtil.getLogContextMap().get(Constants.HEADER_CORRELATION_ID));

    String requestJsonBody = requestObject != null ? new Gson().toJson(requestObject) : null;
    try {

      response = execute(uri, httpMethod, requestJsonBody, urlParams, headers, true);
    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
    return response;
  }

  public ResponseEntity<String> getRefs(String uri, HttpMethod httpMethod, String requestObject,
      MultiValueMap<String, String> urlParams) {
    ResponseEntity<String> response;
    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		
    try {

      response = execute(uri, httpMethod, requestObject, urlParams, headers, true);
    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
    return response;
  }

  public ResponseEntity<String> fetchDefaultValues(String uri, HttpMethod httpMethod,
      Object requestObject, MultiValueMap<String, String> urlParams) {
    ResponseEntity<String> response;
    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
    try {
      headers.add(Constants.HEADER_CORRELATION_ID,
    		  AppUtil.getLogContextMap().get(Constants.HEADER_CORRELATION_ID));
    } catch (Exception e1) {
    	throw new ServiceException(e1.getMessage(), e1.getCause());
    }

    String requestJsonBody = requestObject != null ? new Gson().toJson(requestObject) : null;
    try {

      response = execute(uri, httpMethod, requestJsonBody, urlParams, headers, true);
    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
    return response;
  }

  public ResponseEntity<String> fetchDataPoint(String uri, HttpMethod httpMethod,
      Object requestObject, MultiValueMap<String, String> urlParams) {

    return fetchDataPoints(uri, httpMethod, requestObject, urlParams);
  }

  private ResponseEntity<String> fetchDataPoints(String uri, HttpMethod httpMethod,
      Object requestObject, MultiValueMap<String, String> urlParams) {
    ResponseEntity<String> response;
    // headers.add(Constants.HEADER_CORRELATION_ID,
    String requestJsonBody = requestObject != null ? new Gson().toJson(requestObject) : null;
    try {

      response = execute(uri, httpMethod, requestJsonBody, urlParams, null, true);
    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
    return response;
  }

  public ResponseEntity<String> executeWithMTLS(
          final String url,
          HttpMethod httpMethod,
          String jsonBody,
          MultiValueMap<String, String> urlParams,
          MultiValueMap<String, String> headers) {
    ResponseEntity<String> response;
    HttpHeaders httpHeaders = new HttpHeaders();

    if (headers != null) {
      httpHeaders.addAll(headers);
    }
    if (!ObjectUtils.isEmpty(jsonBody) && !httpHeaders.containsKey("Content-Type")) {
      httpHeaders.setContentType(MediaType.APPLICATION_JSON);
    }

    logger.info("Executing remote api call: {}", url);
    logger.info("Url params:{} ", urlParams != null ? urlParams.values().toString() : "null");
    logger.info("Url headers: {}", headers != null ? headers.values().toString() : "null");
    logger.debug("Request body:{} ", jsonBody != null ? jsonBody : "null");

    URI remoteUri =
            UriComponentsBuilder.fromUriString(url).queryParams(urlParams).build().encode().toUri();

    logger.debug("Final remote uri: {}", remoteUri);

    HttpEntity<String> request = new HttpEntity<>(jsonBody != null ? jsonBody : null, httpHeaders);

    try {

      response = mtlsRestTemplate.exchange(remoteUri, httpMethod, request, String.class);

      HttpStatus tempStatus = (HttpStatus)response.getStatusCode();

      logRemoteApiError(response, tempStatus);

    } catch (ResourceAccessException rExp) {
      throw new ServiceException("Unable to access remote service.", rExp);
    } catch (HttpClientErrorException httpExp) {
      if (HttpStatus.NOT_FOUND == httpExp.getStatusCode()) {
        return new ResponseEntity<>(httpExp.getMessage(), HttpStatus.NOT_FOUND);
      }
      throw new ServiceException(httpExp.getResponseBodyAsString(), httpExp);
    } catch (Exception e) {
      throw new ServiceException(e.getMessage(), e.getCause());
    }
    return response;
  }

  private void logRemoteApiError(ResponseEntity<String> response, HttpStatus tempStatus) {
    if (!tempStatus.is2xxSuccessful()) {
      logger.info("Remote API call: ERROR");
      if (response.hasBody()) {
        JsonArray items = JsonParser.parseString(response.getBody()).getAsJsonArray();
        for (JsonElement jsonElement : items) {
          logger.error("=====================Remote API ERROR START==========================");
          logger.error(jsonElement.getAsJsonObject().get(Constants.ERROR_CODE).getAsString());
          logger.error(jsonElement.getAsJsonObject().get(Constants.MESSAGE).getAsString());
          logger.error("=====================Remote API ERROR END==========================");
        }
      }
    }
  }
}
