package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.actions;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BusinessException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.WebKycService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.CustomerInfo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.rest.webmvc.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
@Slf4j
public class WebKycAction {

  @Autowired
  private WebKycService webKycService;

  public List<CustomerInfo> searchWebKYCParties(String searchValue, String searchType, String onboardingType) {
    List<CustomerInfo> customerInfoList = new ArrayList<>();

    try {
      String response = webKycService.searchWebKYCParties(searchValue, searchType,onboardingType);

      JsonObject searchResponse = JsonParser.parseString(response).getAsJsonObject().get("SearchCustomerResponse").getAsJsonObject();
      String statusCode = searchResponse.get(Constants.STATUS_WEB_KYC).getAsJsonObject().get(Constants.STATUS_CODE).toString();

      if (!statusCode.equals("0")) {
        throw new ResourceNotFoundException(
                searchResponse.get(Constants.STATUS_DESCRIPTION).getAsString() + " for searchValue: " + searchValue);
      }

      if(searchResponse.get(Constants.CUSTOMERS).isJsonObject())
      {
        JsonObject webKYCParty = searchResponse.get(Constants.CUSTOMERS).getAsJsonObject();
        CustomerInfo customerInfo = getCustomerInfo(webKYCParty,onboardingType);

        if(null!= customerInfo)
        {
          customerInfoList.add(customerInfo);
        }
      }
      else if(searchResponse.get(Constants.CUSTOMERS).isJsonArray())
      {
        JsonArray webKYCPartiesArray = searchResponse.get(Constants.CUSTOMERS).getAsJsonArray();

        webKYCPartiesArray.forEach(customer -> {
          CustomerInfo customerInfo = getCustomerInfo(customer, onboardingType);
          if(null!= customerInfo)
          {
            customerInfoList.add(customerInfo);
          }
        });
      }
      else {
        log.error("Invalid Response from web kyc");
      }
    }
    catch(Exception e)
    {
      log.error("Error occurred in web kyc party search", e.getMessage());
      throw new BusinessException(e.getMessage());
    }

    return customerInfoList;
  }

  private CustomerInfo getCustomerInfo(JsonElement customer, String onboardingType) {
      CustomerInfo customerInfo = new CustomerInfo();
      JsonObject jsonObject = customer.getAsJsonObject();

      if(!jsonObject.isJsonNull()){
        customerInfo.setEntityName(jsonObject.get("CustomerName").getAsString());
        customerInfo.setCustomerType(jsonObject.get("CustomerType").getAsString());
        customerInfo.setSource(Constants.SOURCE_WEB_KYC);

        if("KYCID".equals(jsonObject.get(Constants.TASK_ID_TYPE).getAsString())){
          if(jsonObject.get(Constants.FOREIGN_ID)!=null) {
            customerInfo.setEntitytin(jsonObject.get(Constants.FOREIGN_ID).getAsString());
          }else{
            customerInfo.setEntitytin("");
          }
        }else {
          customerInfo.setEntitytin(jsonObject.get("TaxID").getAsString());
        }

        customerInfo.setTaxIdType(jsonObject.get(Constants.TASK_ID_TYPE).getAsString());
        customerInfo.setLastUpdatedDate(jsonObject.get("LastUpdateDate").getAsString());
        customerInfo.setWebKYCID(jsonObject.get("WebKYCID").getAsString());
      }

      return customerInfo;
  }
}