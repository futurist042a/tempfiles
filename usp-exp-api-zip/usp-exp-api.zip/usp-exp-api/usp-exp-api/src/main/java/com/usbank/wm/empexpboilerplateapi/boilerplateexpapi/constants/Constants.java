package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants;

import org.springframework.stereotype.Component;

@Component
public final class Constants {

	public static final String CURRENT_USER_ID = "userId";
	public static final String CORE_URL = "Onboarding core service url";
	public static final String CALL_FAIL = "call failed";
	public static final String DGP_ONBOARDING_CHECKLIST="CLDPG001";
	public static final String CHECKLIST_TYPEID = "17";
	public static final String INSTANCE_ID = "instanceId";



    private Constants() {
	}

	// Header variables
	public static final String HEADER_CORRELATION_ID = "Correlation-ID";
	public static final String HEADER_ONBOARDING_ID = "Onboarding-ID";
	public static final String HEADER_AUTHORIZATION = "Authorization";
	public static final String HEADER_TRANSACTION_ID = "Transaction-ID";
	public static final String SCREEN_SEARCH = "screenSearch";
	public static final String IS_SAVE = "isSave";
	public static final String CHECKLIST_ID = "checklistId";
	public static final String FUND_ID = "fundId";
	public static final String ADVISOR_ID = "advisorId";
	public static final String CLASS_ID = "classId";
	public static final String BUSINESS_LINES = "businessLine";
	public static final String IS_SUBMIT = "isSubmit";


	// Error constants
	public static final String ERROR_CODE_BAD_REQUEST = "1000";
	public static final String ERROR_CODE_NOT_FOUND = "2000";
	public static final String ERROR_CODE_UNAUTHORIZED = "6000";

	public static final String ERROR_CODE = "errorCode";
	public static final String MESSAGE = "message";

	public static final String USB_UO_LOG = "USB_UO_LOG ::";
	public static final String CUSTOMERS = "Customers";
	public static final String MONEY_CENTER = "moneyCenter";

	public static final String STATUS_WEB_KYC = "Status";
	public static final String STATUS_DESCRIPTION = "StatusDescription";
	public static final String SOURCE_WEB_KYC = "WebKYC";
	public static final String TASK_ID_TYPE = "TaxIDType";
	public static final String FOREIGN_ID = "ForeignID";
	public static final String TRANSACTION_IDENTIFIER = "TransactionIdentifier";
	public static final String MESSAGE_SUBMISSION_DATA_TIME = "MessageSubmissionDateTime";
	public static final String MESSAGE_TYPE_CODE = "MessageTypeCode";
	public static final String REQUEST = "Request";
	public static final String END_USER_IDENTIFIER = "EndUserIdentifier";
	public static final String CUSTOMER_NAME = "CustomerName";
	public static final String TAXID = "TaxID";
	public static final String BUSINESSLINE = "BusinessLine";
	public static final String LAST_UPDATE_RANGE = "LastUpdateRange";
	public static final String FROMDATE = "FromDate";
	public static final String TODATE = "ToDate";
	public static final String JSON_STATUS = "Status";
	public static final String FETCH_LATEST_RECORD = "FetchLatestRecord";
	public static final String DATE_TIME_FORMAT = "yyyy-MM-dd";
	public static final String UNKNOWN = "unknown";
	public static final String CHANNEL_TYPE = "ChannelTypeCode";
	public static final String SESSION_ID = "SessionId";
	public static final String SERVER_IDENTIFIER = "ServerIdentifier";
	public static final String STATUS_CODE = "StatusCode";

	public static final String REMOTE_API_ERROR_START = "Remote API ERROR START";
	public static final String REMOTE_API_ERROR_END = "Remote API ERROR END";
	public static final String ERROR_SPACE = "=====================";
	public static final String NULL_STRING = "<null>";
	public static final String BUSINESS_LINE = "businessLine";
	public static final String FORM_ACTION = "formAction";
	public static final String FORM_NAME = "formName";
	public static final String ONBOARDING_ID = "onboardingId";
	public static final String FORM_BODY = "formBody";
	public static final String CURRENT_USER = "currentUser";
	public static final String ATTACHMENT_FILE_NAME = "boilerplate Application Packet.pdf";
	public static final String ATTACHMENT_TYPE = "application/pdf";

	public static final String TAB_NAME="tabName";
	public static final String IS_ACTIVE = "isActive";
	public static final String FORM_TYPE = "formType";
	public static final String IS_READ_ONLY = "isReadOnly";

	public static final String ROLE_MARKETER = "Marketer";
	public static final String ROLE_WMIS_Operations = "WMIS_Operations";
	public static final String INITIATE_ONBOARDING_PERMISSION = "initiateOnboarding";
	public static final String REASSIGN_TASK_PERMISSION = "reAssignTask";
	public static final String ASSIGN_TASK_PERMISSION = "assignTask";
	public static final String VIEW_ALL_ONBOARDING_EVENTS_PERMISSION = "viewAllOnboardingEvents";
	public static final String USER_ROLE_MICL_CONTRACT_ANALYST="MICL-CONTRACT-ANALYST";

	public static final String SUCCESS = "success";
	public static final String USER_NAME = "performedByUserName";
	public static final String USER_ID = "performedByUserId";
	public static final String DESCRIPTION = "description";
	public static final String USER_FULL_NAME = "userFullName";
	public static final String DETAILS = "details";
	public static final String EVENT_DESCRIPTION = "eventDescription";

	public static final String DOCUMENT_ID = "DocumentId";

	public static final String DOCUMENT_VALUE = "Value";

	public static final String PROXY_WORK_AREA = "proxyWorkArea";
	public static final String REQUEST_ID = "Request-ID";
	public static final String HEADER_REQUEST_ID = "Request-ID";
	public static final String URL_PARAMS = "Url params:{} ";
	public static final String URL_HEADERS = "Url headers: {}";
	public static final String FINAL_REMOTE_URI = "Final remote uri: ";
	public static final String REMOTE_API_CALL = "Remote API call: ERROR";

	public static final String REF_TYPE_ID = "15";
	public static final String MY_TASKS ="My_Tasks";
	public static final String TEAM_TASKS ="team_tasks";
	public static final String OTHER_TASKS ="other_tasks";

	public static final String MARKETER_DETAIL_PAGE_DATAPOINT_ID = "clientDetails-legalName,onboardingTeam-role1,onboardingTeam-role2,onboardingTeam-relationshipManager,productDetails-productType";
	public static final String NEGOTIATOR="onboardingTeam-role2";
	public static final String MARKETER="marketer";
	public static final String OBJ_VALUE = "objValue";
	public static final String SOURCE_SYSTEM_DP_ID = "sourceSystemDpId";

	public static final String VALUE = "value";

	public static final String ONBOARDING_IDS = "onboardingIds";

	public static final String ONBOARDINGID="onBoardingId";
	public static final String RM = "rM";
	public static final String PRODUCT = "product";
	public static final String EVENT_STAGE = "eventStage";
	public static final String EVENT_PROGRESS_STAGE = "eventProgressStatus";
	public static final String UO_DRAFT = "uo_draft";
	public static final String UO_SUBMIT = "uo_submit";
	public static final String UO_APPROVE = "uo_approve";
	public static final int ZERO = 0;
	public static final int ONE = 1;

	public static final String DERIVATIVES_CUSTOMER_PROFILE = "Derivatives customer profile";
	public static final String KYC_DOCUMENTATION = "KYC Documentation";
	public static final String DODD_FRANK_PACKET = "Dodd Frank Packet";
	public static final String ISDA = "ISDA";
	public static final String CREDIT_LIMIT_APPROVAL = "Credit Limit approval";
	public static final String GREEN_LIGHT_MEMO = "Green light memo";

	public static final String PAYLOAD_ERROR = "Payload Error.";



	public static final String CREATED_BY = "createdBy";
	public static final String CREATOR = "creator";
	public static final String DATE_CREATED = "dateCreated";

	public static final String DATE_TIME_FORMAT_DB = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	public static final String CURRENT_DATE_FORMAT = "MMM dd, yyyy";
	public static final String FILE_CONTENT = "fileContent";

	public static final String STATE_DRF_COMPLETED = "Completed";

	public static final int CHUNK_SIZE =1000;
	public static final String CLIENTLEGALNAME="clientLegalName";
	public static final String CLIENTDETAILS_LEGALNAME="clientDetails-legalName";
	public static final String RMNAME="onboardingTeam-relationshipManager";
	public static final String MARKETER_NAME="onboardingTeam-role1";
	public static final String DOC_REVIEWER="docReviewer";
	public static final String TAX_ID="clientDetails-EIN";
	public static final String DRF_WORKFLOW_ID="drfWorkflowId";

	public static final String WORKFLOW_ID="workflowId";
	public static final String DRF_WORKFLOW_IDS="workflowIds";

	public static final String DRF_WORKFLOW_STATUS="workflowStatus";
	public static final String DRF_WORKFLOW_IS_COMPLETED="isWorkflowCompleted";
	public static final String PRODUCT_TYPE="productDetails-productType";
	public static final String URL_OFFSET_AND_LIMIT="?offset=0&limit=1000";
	public static final String NEGOTIATOR_GROUP="negotiator";
	public static final String DOCUMENT_REQUESTOR_GROUP="document-requestor";
	public static final String HEADER_ACCOUNT_ID = "Account-ID";
	public static final String PREPOPULATED_DATAPOINTS="prepopulatedDataPoints";

	public static final String ACCOUNT_NAME = "accountName";
	public static final String ACCOUNT_NUMBER = "AccountNumber";
	public static final String MAJOR_ACCOUNT_TYPE = "majorAccountType";
	public static final String LOCATION = "selectedLocation";
	public static final String MINOR_ACCOUNT_TYPE = "minorAccountType";
	public static final String ACCOUNT_STATUS = "accountStatus";
	public static final String SERVICE_LEVEL ="serviceLevel";
	public static final String SUBMITTER_NAME = "submitterName";
	public static final String ONBOARDING_EVENTTYPE = "onboardingEventType";
	public static final String RETURN_COMMENTS = "returnComments";


	public static final String NAME="name";
	public static final String STATUS = "status";
	public static final String STATE_COMPLETED = "COMPLETED";
}
