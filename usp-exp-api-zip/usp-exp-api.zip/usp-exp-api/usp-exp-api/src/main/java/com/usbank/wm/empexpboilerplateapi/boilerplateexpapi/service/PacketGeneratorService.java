package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BadRequestException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.PdfRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class PacketGeneratorService {

	@Value("${moneyCenter.service.base.url}")
	private String moneyCenterBaseUrl;
	@Value("${moneyCenter.rest.v1.merge}")
	private String mergeDocuments;

	@Autowired
	@Qualifier("platformRestTemplate")
	RestTemplate restTemplate;
	@Autowired
	private RemoteService remoteService;

	public String generatePacket(String requestPayload) {

		ResponseEntity<ByteArrayResource> customerPacket = null;
		ObjectMapper mapper = new ObjectMapper();
		PdfRequest pdfRequest = new PdfRequest();
		String payload = null;

		try {
			JsonObject jsonObject = JsonParser.parseString(requestPayload).getAsJsonObject();
			JsonArray members = jsonObject.get("formIdentifiers").getAsJsonArray();
			pdfRequest.setAccountNumber(Constants.ATTACHMENT_FILE_NAME);
			log.info("members --> " + members);
			Integer[] ids = new Integer[members.size()];
			for (int index = 0; index < members.size(); index++) {
				ids[index] = members.get(index).getAsInt();
			}
			pdfRequest.setFormIdentifiers(ids);
			pdfRequest.setEncoding("binary");
			payload = mapper.writeValueAsString(pdfRequest);
			log.info("payload --> " + payload);
		} catch (IOException ex) {
			log.error("Few input fields related to merge document are missing or given incorrectly :", ex);
			throw new BadRequestException(ex.getMessage());
		}

		Map<String, String> pathVar = new HashMap<>();
		String mcPdfMergeUrl = moneyCenterBaseUrl + mergeDocuments;
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		MultiValueMap<String, String> headersMap = new LinkedMultiValueMap<>();
		HttpHeaders headers = new HttpHeaders();
		headers.addAll(headersMap);
		headers.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
		headers.setContentType(MediaType.APPLICATION_JSON);

		URI uri = UriComponentsBuilder.fromUriString(mcPdfMergeUrl).queryParams(params).buildAndExpand(pathVar).encode()
				.toUri();

		HttpEntity<String> request = new HttpEntity<>(payload, headers);
		Date startTime = new Date();

		try {
			log.info("uri--Details -> " + uri);
			log.info("request --> " + request);
			customerPacket = restTemplate.exchange(uri, HttpMethod.POST, request, ByteArrayResource.class);
			log.info(Constants.USB_UO_LOG + "getDocument : Called PacketGenerator : " + uri.toString() + " in ms : "
					+ (new Date().getTime() - startTime.getTime()));

			HttpStatus tempStatus = (HttpStatus)customerPacket.getStatusCode();
			log.info("content --> " + customerPacket.getBody());
			if (!tempStatus.is2xxSuccessful()) {
				if (customerPacket.hasBody()) {
					JsonArray items = JsonParser.parseString(customerPacket.getBody().toString()).getAsJsonArray();
					for (JsonElement jsonElement : items) {
						log.error(Constants.ERROR_SPACE + Constants.REMOTE_API_ERROR_START + Constants.ERROR_SPACE);
						log.error(jsonElement.getAsJsonObject().get(Constants.ERROR_CODE).getAsString());
						log.error(jsonElement.getAsJsonObject().get(Constants.MESSAGE).getAsString());
						log.error(Constants.ERROR_SPACE + Constants.REMOTE_API_ERROR_END + Constants.ERROR_SPACE);
					}
				}
			}
			String mergedPdfPacket = Base64.getEncoder().encodeToString(customerPacket.getBody().getByteArray());
			return mergedPdfPacket;

		} catch (Exception e) {
			log.info(Constants.USB_UO_LOG + "getMergeDocument : Called boilerplate service : " + uri.toString()
					+ " in ms :: " + (new Date().getTime() - startTime.getTime()));
			log.error("Error occurred in: getMergeDocument.", e);
			throw new ServiceException(e.getMessage());
		}
	}
}
