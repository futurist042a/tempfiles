
package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "toAddress",
    "replyToAddress",
    "subject",
    "body",
    "attachmentInformation"
})
@Data
@Builder
public class EmailInformation implements Serializable
{

    @JsonProperty("toAddress")
    private List<String> toAddress = null;
    @JsonProperty("replyToAddress")
    private String replyToAddress;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("body")
    private String body;
    @JsonProperty("attachmentInformation")
    private List<AttachmentInformation> attachmentInformation;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    private static final long serialVersionUID = 1508428477156969368L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(EmailInformation.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("toAddress");
        sb.append('=');
        sb.append(((this.toAddress == null)? Constants.NULL_STRING:this.toAddress));
        sb.append(',');
        sb.append("replyToAddress");
        sb.append('=');
        sb.append(((this.replyToAddress == null)? Constants.NULL_STRING:this.replyToAddress));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)? Constants.NULL_STRING:this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
