package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;

@Service
@Slf4j
public class CamundaRemoteService {
    private static final Logger logger = LoggerFactory.getLogger(RemoteService.class);

    @Autowired
    HttpServletRequest httpServletRequest;

    @Value("${camunda.oauth.token.endpoint}")
    private String camundaAccessTokenUrl;

    @Value("${camunda.identity.clientId}")
    private String camundaClientId;

    @Value("${camunda.identity.clientSecret}")
    private String camundaClientSecret;

    RestTemplate restTemplate = new RestTemplate();
    public ResponseEntity<String> execute(final String url, HttpMethod httpMethod, String jsonBody,
                                          MultiValueMap<String, String> urlParams, MultiValueMap<String, String> headers,
                                          boolean includeAuthorization) {
        ResponseEntity<String> response = null;
        HttpHeaders httpHeaders = camundaBuildHeader(jsonBody, headers, includeAuthorization);
        logRequestDetails(url, httpMethod, jsonBody, urlParams, httpHeaders);

        URI remoteUri =
                UriComponentsBuilder.fromUriString(url).queryParams(urlParams).build().encode().toUri();

        logger.debug("Final remote uri: " + remoteUri.toString());

        HttpEntity<String> request = new HttpEntity<>(jsonBody != null ? jsonBody : null, httpHeaders);

        try {
            response = restTemplate.exchange(remoteUri, httpMethod, request, String.class);
            HttpStatusCode tempStatus = response.getStatusCode();

            if (!tempStatus.is2xxSuccessful()) {
                logError(response);
            }

        } catch (ResourceAccessException rExp) {
            logger.error("Error occurred in: execute.", rExp);
            throw new ServiceException("Unable to access remote service.");
        } catch (HttpClientErrorException httpExp) {
            if (HttpStatus.NOT_FOUND == httpExp.getStatusCode()) {
                return new ResponseEntity<>(httpExp.getMessage(), HttpStatus.NOT_FOUND);
            }
            logger.error("Exception calling remote service: " + httpExp.getResponseBodyAsString());
            throw new ServiceException(httpExp.getMessage());
        } catch (Exception e) {
            logger.error("Error occurred in: execute.", e);
            throw new ServiceException(e.getMessage());
        }
        return response;
    }
    private HttpHeaders camundaBuildHeader(String jsonBody, MultiValueMap<String, String> headers, boolean includeAuthorization) {
        HttpHeaders httpHeaders = new HttpHeaders();
        if (includeAuthorization) {
            httpHeaders.add("Authorization", getCamundaAuthorization());
        }
        if (headers != null) {
            httpHeaders.addAll(headers);
        }
        if (!ObjectUtils.isEmpty(jsonBody) && !httpHeaders.containsKey("Content-Type")) {
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        }
        return httpHeaders;
    }
    private void logRequestDetails(final String url, HttpMethod httpMethod, String jsonBody,
                                   MultiValueMap<String, String> urlParams, HttpHeaders httpHeaders) {
        logger.info("Executing remote api call: " + url);
        logger.info("HttpMethod method:{} ", httpMethod != null ? httpMethod : "null");
        logger.info("Url params:{} ", urlParams != null ? urlParams.values().toString() : "null");
        logger.info("Url headers: {}", httpHeaders != null ? httpHeaders.values().toString() : "null");
        logger.debug("Request body:{} ", jsonBody != null ? jsonBody : "null");
    }
    private void logError(ResponseEntity<String> response) {
        logger.info("Remote API call: ERROR");
        if (response.hasBody()) {
            JsonArray items = JsonParser.parseString(response.getBody()).getAsJsonArray();
            for (JsonElement jsonElement : items) {
                logger.error("=====================Remote API ERROR START==========================");
                logger.error(jsonElement.getAsJsonObject().get("errorCode").getAsString());
                logger.error(jsonElement.getAsJsonObject().get("message").getAsString());
                logger.error("=====================Remote API ERROR END==========================");
            }
        }
    }
    public String getCamundaAuthorization() {
        return getCamundaNewAccessToken();
    }
    public String getCamundaNewAccessToken() {
        logger.info("Getting new access token from keyCloak: ");
        ResponseEntity<String> response = null;
        RestTemplate restTemplateToken = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();

        httpHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", "client_credentials");
        requestBody.add("client_id", camundaClientId);
        requestBody.add("client_secret", camundaClientSecret);
        logger.info("New access token url: " + camundaAccessTokenUrl);
        try {
            response = restTemplateToken.exchange(camundaAccessTokenUrl, HttpMethod.POST,
                    new HttpEntity<>(requestBody, httpHeaders), String.class);

            if (!response.getStatusCode().is2xxSuccessful()) {
                logger.info("Get New token call: ERROR");
                if (response.hasBody()) {
                    JsonArray items = JsonParser.parseString(response.getBody().toString()).getAsJsonArray();
                    for (JsonElement jsonElement : items) {
                        logger
                                .error("=====================Get New token ERROR START==========================");
                        logger.error(jsonElement.getAsJsonObject().get("errorCode").getAsString());
                        logger.error(jsonElement.getAsJsonObject().get("message").getAsString());
                        logger.error("=====================Get New token ERROR END==========================");
                    }
                }
            }
            logger.info("New access token response: " + response.getBody().toString());
            String tokenType = JsonParser.parseString(response.getBody().toString()).getAsJsonObject()
                    .get("token_type").getAsString();
            String accessToken = JsonParser.parseString(response.getBody().toString()).getAsJsonObject()
                    .get("access_token").getAsString();
            return tokenType + " " + accessToken;
        } catch (Exception exp) {
            logger.error("Error occurred in: getNewAccessToken.", exp);
            throw new ServiceException(exp.getMessage());
        }
    }
}
