package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Events {
    private String customerAccountName;
    private String accountNumber;
    private String accountType;
    private List<String> client;
    private String task;
    private String taskDue;
    private String accountStatus;
    private String controlID;
    private String pwa;
    private String trustOfficer;
    private String assignedTo;

    private long onboardingId;
    private String createdBy;
    private String csmManagerId;
    private String eventStage;
    private List<String> eventSteps;
    private String entitytin;
    private String onboardingName;
    private String entityName;
    private String cttManagerId;
    private String relationshipManagerId;
    private String minorAccountType;
    private String isActive;
    private String taskType;
    private Boolean showAssignButton;
    private String subViewColumn2;
    private String taskId;
    private String onboardingEventType;
    private String checklistId;
    private String assignedToId;
    public String taskCheckListId;
    private String serviceLevel;
    private String submitterName;
    private String returnComments;
}
