package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BusinessException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Map;

@Service
@Slf4j
public class AuditService {

	@Value("${audit.service.base.url}")
	private String auditBaseUrl;

	@Value("${audit.service.AuditDataUrl}")
	private String auditServiceFormDataUrl;

	@Value("${audit.service.PostAuditDataUrl}")
	private String auditServicePostFormDataUrl;

	ConnectService connectService;

	RemoteService remoteService;
	
	@Autowired
	public AuditService(ConnectService connectService, RemoteService remoteService) {
		this.connectService = connectService;
		this.remoteService = remoteService;
	}

	public ResponseEntity<String> createAudit(String onboardingId, String description, String currentUser,
			String userFullName, String details) {
		log.info("Entering into postAudit : onboardingId : " + onboardingId + "  description : " + description
				+ "  currentUser : " + currentUser + "  userFullName : " + userFullName + " details : " + details);
		ResponseEntity<String> response = null;
		MultiValueMap<String, String> urlParams1 = new LinkedMultiValueMap<>();
		urlParams1.add(Constants.ONBOARDING_ID, onboardingId);
		urlParams1.add(Constants.DESCRIPTION, description);
		urlParams1.add(Constants.CURRENT_USER, currentUser);
		urlParams1.add(Constants.USER_FULL_NAME, userFullName);
		urlParams1.add(Constants.DETAILS, details);
		try {
			if (onboardingId != null) {
				response = connectService.fetchRecord(auditBaseUrl + auditServicePostFormDataUrl, HttpMethod.POST, null,
						urlParams1);
				if (null != response) {
					JsonObject data = JsonParser.parseString(response.getBody()).getAsJsonObject();
					return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
				}

			}
		} catch (Exception e) {
			log.error("Error occurred audit data from core service", e.getMessage());
			throw new BusinessException(e.getMessage());
		}
		return new ResponseEntity<>(HttpStatus.NO_CONTENT.name(), HttpStatus.OK);

	}

	@Async
	public ResponseEntity<String> auditDetails(Long onboardingId, Map<String, Object> auditMap) {
		String eventDescription = null;
		String userFullName = null;
		String details = null;
		String userId = null;
		ResponseEntity<String> response = null;
		if (auditMap.containsKey(Constants.DETAILS) && auditMap.get(Constants.DETAILS) != null) {
			details = auditMap.get(Constants.DETAILS).toString();
		}
		if (auditMap.containsKey(Constants.EVENT_DESCRIPTION) && auditMap.get(Constants.EVENT_DESCRIPTION) != null) {
			eventDescription = auditMap.get(Constants.EVENT_DESCRIPTION).toString();
		}
		if (auditMap.containsKey(Constants.USER_NAME) && auditMap.get(Constants.USER_NAME) != null) {
			userFullName = auditMap.get(Constants.USER_NAME).toString();
		}
		if (auditMap.containsKey(Constants.USER_ID) && auditMap.get(Constants.USER_ID) != null) {
			userId = auditMap.get(Constants.USER_ID).toString();
		}

		MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
		urlParams.add(Constants.ONBOARDING_ID, onboardingId.toString());
		urlParams.add(Constants.DESCRIPTION, eventDescription);
		urlParams.add(Constants.USER_FULL_NAME, userFullName);
		urlParams.add(Constants.DETAILS, details);
		urlParams.add(Constants.CURRENT_USER, userId);

		try {
			response = connectService.fetchRecord(auditBaseUrl + auditServicePostFormDataUrl, HttpMethod.POST, null,
					urlParams);
		} catch (Exception e) {
			log.error("Error occurred in updating audit details" + e.getMessage());
		}
		return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
	}
}