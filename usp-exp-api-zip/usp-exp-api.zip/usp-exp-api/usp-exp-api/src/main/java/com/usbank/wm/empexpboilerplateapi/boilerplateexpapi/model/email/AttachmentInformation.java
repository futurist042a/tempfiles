package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "attachmentFileName",
        "attachmentType",
        "attachment"
})
@Data
@Builder
public class AttachmentInformation implements Serializable {

    @JsonProperty("attachmentFileName")
    private String attachmentFileName;
    @JsonProperty("attachmentType")
    private String attachmentType;
    @JsonProperty("attachment")
    private String attachment;

    @Override
    public String toString() {
        return "AttachmentInformation{" +
                "attachmentFileName='" + attachmentFileName + '\'' +
                ", attachmentType='" + attachmentType + '\'' +
                ", attachment='" + attachment + '\'' +
                '}';
    }
}
