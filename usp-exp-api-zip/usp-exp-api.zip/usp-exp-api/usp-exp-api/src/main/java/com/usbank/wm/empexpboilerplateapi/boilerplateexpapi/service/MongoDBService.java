package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.helpher.USPMongoRepository;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.model.ObjectQuery;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.ArrayList;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

@Service
@Slf4j
public class MongoDBService {

    @Autowired
    private USPMongoRepository uspMongoRepository;

    //Object Querys: {"System": "USP", "Collection": "", "Query": {}, Alias: ""}
    public List<JsonObject> executeObjectQuery(String objectQueryJson){
//        JsonObject jsonObject = new Gson().fromJson(objectQuery, JsonObject.class);
//        String jsonStrResponse = getObjectList(jsonObject.get("Collection").getAsString(),jsonObject.get("Query").toString());
        ObjectQuery objectQuery = new Gson().fromJson(objectQueryJson, ObjectQuery.class);
        String jsonStrResponse = getObjectList(objectQuery.getCollection(),objectQuery.getQuery());
//        Type type = new TypeToken<List<JsonObject>>(){}.getType();
//        List<JsonObject> response = new Gson().fromJson(jsonStrResponse, type);
        return getJsonObjectList(jsonStrResponse);
    }

    public String insertObject(String commonObjectJson){
        JsonObject jsonObject = new Gson().fromJson(commonObjectJson, JsonObject.class);
        String collection = jsonObject.get("collection").getAsString();
        String type  = jsonObject.get("type").getAsString();
        String data  = jsonObject.get("data").toString();

        return uspMongoRepository.insertDocumentStr(collection,data);
    }

    public String insertObject(String collection, String data){
        System.out.println("insertObject : collection > "+collection+", data > "+data);
        return uspMongoRepository.insertDocumentStr(collection,data);
    }

    public void createCollection(String name){
        uspMongoRepository.createCollection(name);
    }

    public long updateObject(String commonObjectJson){
        JsonObject jsonObject = new Gson().fromJson(commonObjectJson, JsonObject.class);
        String collection = jsonObject.get("collection").getAsString();
        String type  = jsonObject.get("type").getAsString();
        JsonElement data  = jsonObject.get("data");

        JsonElement id = data.getAsJsonObject().get("_id").isJsonObject() ? data.getAsJsonObject().get("_id").getAsJsonObject().get("$oid") : data.getAsJsonObject().get("_id");
        System.out.println("id : "+id);
        JsonElement  updateData = data.getAsJsonObject().remove("_id");
        System.out.println("updateData : "+data);
        //{_id: ObjectId('672b6ee3f01e7cc857f5517b')}
        return uspMongoRepository.replaceRecord(collection,"{_id: ObjectId('"+id.getAsString()+"')}",data.toString(),false);
    }
    public List<JsonObject> getFormJson(String screenSearch){
        String jsonStrResponse = getObjectList("USP_FORMS","{searchKey: '"+screenSearch+"'}");
        return getJsonObjectList(jsonStrResponse);
    }

    public String getLandingPageJson(){
        String jsonStrResponse = getObjectList("USP_REFS","{$and : [{name: 'LandingPage'},{applicationName: 'template'}]}");
        return jsonStrResponse;
    }

    public String getJSFunctionJson(){
        String jsonStrResponse = getObjectList("USP_REFS","{$and : [{name: 'templateScript'},{applicationName: 'template'}]}");
        return jsonStrResponse;
    }

    public String getStyleJson(){
        String jsonStrResponse = getObjectList("USP_REFS","{$and : [{name: 'templateStyle'},{applicationName: 'template'}]}");
        return jsonStrResponse;
    }

    public String getEventObjectTemplate(String templateName){
        String jsonStrResponse = getObjectList("USP_REFS","{$and : [{name: '"+templateName+"'},{applicationName: 'template'}]}");
        return jsonStrResponse;
    }

    private List<JsonObject> getJsonObjectList(String jsonStr){
        Type type = new TypeToken<List<JsonObject>>(){}.getType();
        List<JsonObject> response = new Gson().fromJson(jsonStr, type);
        return response;
    }

    private String getObjectList(String collection, String selectQuery){
        System.out.println("getObjectList - Collection : "+collection+" ,query: "+selectQuery);
        String objectsInJsonFmt = uspMongoRepository.fetchDocuments(collection,selectQuery,"{}","{}");
        System.out.println("getObjectList - response : "+objectsInJsonFmt);
        return objectsInJsonFmt;
    }

    //ObjectQuery Format: @usp,col=refs,query={},alias=
//    private Map<String, String> getObjectQueryAsMap(String objectQuery){
//        String[] splitQuery = objectQuery.split(",");
//        System.out.println(splitQuery);
//        return Arrays.stream(splitQuery)
//                .map(elem -> elem.split("="))
//                .filter(elem -> elem.length==2)
//                .collect(Collectors.toMap(e -> e[0].toLowerCase(), e -> e[1]));
//    }

    //Object Query: system=USP,col=refs,query={},alias=
    //system: USP: Represent USP System Backend - will be MongoDB Call
    //col  : Collection Name
    //query: Filter condition and needs to be in json format. Similar to how we could query in Compass editor e.g. {typeid=301,searchkey='app.screen'}
    //alias: The alias name will be used as the HashMap key to respond with the object retrieved. The Hashmap will be creared by calling component.
//    public String executeObjectQuery(String objectQuery){
//        Map<String, String> objectQueryMap = getObjectQueryAsMap(objectQuery);
//        String jsonStrResponse = getObjectList(objectQueryMap.get("col"),objectQueryMap.get("query"));
//        return jsonStrResponse;
//    }
}
