package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.resolver;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.actions.DocumentAction;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.actions.WebKycAction;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.CustomerInfo;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Document;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.EventTasks;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Events;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.BoilerplateService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.CommonOnBoardingEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Comparator;

@RestController
@Slf4j
public class OnboardingResolver {

    @Autowired
    WebKycAction webKycAction;
    @Autowired
    private BoilerplateService boilerplateService;

    @Autowired
    DocumentAction documentAction;

    @QueryMapping(name = "webKycParty")
    public List<CustomerInfo> searchWebKYCParties(@Argument(name = "searchValue") String searchValue,
                                                  @Argument(name = "searchType") String searchType,
                                                  @Argument(name = "onboardingType") String onboardingType)
    {
        log.debug(Constants.USB_UO_LOG
                + "searchValue : " + searchValue+ "onboardingType:" +onboardingType);
        try {
            return webKycAction.searchWebKYCParties(searchValue,searchType,onboardingType);
        }
        catch(Exception e)
        {
            log.error("Error occurred in web kyc party search: {} ", e.getMessage());
        }

        return new ArrayList<>();
    }
    @QueryMapping(name = "events")
    public List<Events> getTaskList(@Argument(name = "onboardingType") String onboardingType,
                                    @Argument(name = "userRole") String userRole,
                                    @Argument(name = "taskType") String taskType) throws JsonProcessingException {
        log.info("Inside OnboardingService class getTaskList() method:");
        Optional<String> userId = AppUtil.getCurrentUser();
        if (!userId.isEmpty()) {
            String currentUser = userId.get();
            List<Events> tasksResponseCore = boilerplateService.getOnboardingEvents(onboardingType, currentUser, taskType,userRole);
            return tasksResponseCore;
        }
        return new ArrayList<>();
    }
    @QueryMapping(name = "documentList")
    public List<Document> fetchDocuments(@Argument(name = "onboardingId") String onboardingId,
                                         @Argument(name = "onboardingType") String onboardingType,
                                         @Argument(name = "AccountNumber") String accountNumber)
    {

        log.info("Inside OnboardingResolver class fetchDocuments() method:");

        try {
            return documentAction.searchDocuments(onboardingId, onboardingType, accountNumber);
        }
        catch(Exception e)
        {
            log.error("Error occurred in fetching documents", e.getMessage());
        }
        return new ArrayList<>();

    }
    @QueryMapping(name = "eventtasks")
    public List<EventTasks> getTask(@Argument(name = "onboardingType") String onboardingType,
                                    @Argument(name = "onboardingId") String onboardingId) {
        log.info("Inbound request to eventtasks : "+onboardingType+", id> "+onboardingId);
        String currentUser = null;
        Optional<String> user = AppUtil.getCurrentUser();
        if (user.isPresent()) {
            currentUser = user.get();
            return boilerplateService.getEventTasks(onboardingType, currentUser, onboardingId);
        }
        return new ArrayList<>();
    }

    @QueryMapping(name = "commonOnBoardingEvent")
    public List<CommonOnBoardingEvent> getCommonOnBoardingEventList(@Argument(name = "onboardingType") String onboardingType,
                                                                    @Argument(name = "onboardingId") String onboardingId,
                                                                    @Argument (name="startDate" ) String startDate,
                                                                    @Argument (name="endDate" ) String endDate,
                                                                    @Argument (name="limit" ) String limit,
                                                                    @Argument (name="pageNum" ) String pageNum) {
        log.info("Starting getCommonOnBoardingEventList()");
        Optional<String> user = AppUtil.getCurrentUser();

        List<CommonOnBoardingEvent> response = new ArrayList<>();
        int resultLimit=10;
        int pageNumber=0;
        if (user.isPresent()) {
            try {
                response = boilerplateService.getOnboardingCommonEvent(onboardingType);
            }
            catch(Exception e)
            {
                e.printStackTrace();
                log.error("Error occurred in fetching CommonOnBoardingEvent : {} ", e.getMessage());
                return new ArrayList<>();
            }
        }
        if(null!=response && !response.isEmpty()) {
            DateTimeFormatter dateTimeFormatter=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
            return response.stream().filter(res->null!=res.getProcessDetails()&&!res.getProcessDetails().getTaskDetails().isEmpty()).sorted(Comparator.comparing(commonOnboardingEvent ->
                    commonOnboardingEvent.getProcessDetails().getTaskDetails().
                            stream()
                            .map(taskDetails->taskDetails.getModifiedDate())
                            .map(s-> LocalDateTime.parse(s,dateTimeFormatter))
                            .max(LocalDateTime::compareTo)
                            .orElse(LocalDateTime.MIN),Comparator.reverseOrder()
            )).toList();
        }
        return response;
    }
}