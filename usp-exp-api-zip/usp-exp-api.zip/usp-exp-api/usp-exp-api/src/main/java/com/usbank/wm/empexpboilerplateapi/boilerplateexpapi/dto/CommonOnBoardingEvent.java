package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CommonOnBoardingEvent {
    private ClientDetails clientDetails;
    private AccountDetails accountDetails;
    private OnboardingTeam onboardingTeam;
    private ProcessDetails processDetails;
    private List<BeneficialOwner> beneficialOwner;
    private ProductDetails productDetails;
    private KycDetails kycDetails;
    private IdpDetails IdpDetails;
    private String test;
    private int iTest;
}
