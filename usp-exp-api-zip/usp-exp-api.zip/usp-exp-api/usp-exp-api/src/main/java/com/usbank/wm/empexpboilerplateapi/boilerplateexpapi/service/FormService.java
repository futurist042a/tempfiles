package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BusinessException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.PickList;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;

@Service
@Slf4j
public class FormService {

	@Value("${event.service.baseurl}")
	private String eventBaseUrl;

	@Value("${event.service.eventDataUrl}")
	private String eventServiceFormDataUrl;

	@Value("${form.service.baseurl}")
	private String formBaseUrl;

	@Value("${form.service.v1.dynamicforms}")
	private String formDynamicFormUrl;

	@Value("${form.service.FormDataUrl}")
	private String formServiceFormDataUrl;

	@Value("${audit.service.base.url}")
	private String auditBaseUrl;

	@Value("${audit.service.v1.get.auditTrails}")
	private String getAuditTrailUrl;

	@Autowired
	ConnectService connectService;

	public ResponseEntity<String> getForms(String businessLine, String formName, String tabName, Long onboardingId,
			Boolean isReadOnly) {
		log.info("Entering into getForms : businessLine : " + businessLine + "  formName : " + formName
				+ "  onboardingId : " + onboardingId + "  isReadOnly : " + isReadOnly);
		ResponseEntity<String> response = null;
		MultiValueMap<String, String> urlParams1 = new LinkedMultiValueMap<>();
		urlParams1.add("businessLine", businessLine);
		urlParams1.add("formName", formName);
		urlParams1.add("tabName", tabName);
		try {
			if (onboardingId == null) {
				log.info("1st  if start");
				response = connectService.fetchRecord(formBaseUrl+formServiceFormDataUrl, HttpMethod.GET, null,
						urlParams1);
				JsonObject data = JsonParser.parseString(response.getBody()).getAsJsonObject();
				log.debug("getForms response 1:: ", data);
			} else if (isReadOnly != null && isReadOnly) {
				MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
				urlParams.add("onboardingId", String.valueOf(onboardingId));
				log.info("2nd  if start");
				response = connectService.fetchRecord(eventBaseUrl+eventServiceFormDataUrl, HttpMethod.GET, null,
						urlParams);
				JsonObject data = JsonParser.parseString(response.getBody()).getAsJsonObject();
				data.addProperty(Constants.ONBOARDING_ID, "" + onboardingId);
				log.debug("getForms response 2 isReadOnly{} :: ", data);
				response = new ResponseEntity<>(data.toString(), HttpStatus.OK);
				log.info("2nd  if end");
			} else {
				MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
				urlParams.add("onboardingId", String.valueOf(onboardingId));
				log.info("3rd  if start");
				response = connectService.fetchRecord(eventBaseUrl+eventServiceFormDataUrl, HttpMethod.GET, null,
						urlParams);
				JsonObject data = JsonParser.parseString(response.getBody()).getAsJsonObject();
				data.addProperty(Constants.ONBOARDING_ID, "" + onboardingId);
				log.debug("getForms response 3: " + data);
				log.info("3rd  if end");
				response = new ResponseEntity<>(data.toString(), HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Error occurred form data from core service", e.getMessage());
			throw new BusinessException(e.getMessage());
		}
		return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
	}

	@Autowired
	RemoteService remoteService;
	@Value("${form.service.v1.checklist}")
	private String formCheckListUrl;
	public JsonObject initiateOnboarding(String businessLine, String formName,String currentUser) {
		log.info("initiateOnboarding-UOFormService :: businessLine : {} formName : {}", businessLine, formName);
		ResponseEntity<String> response;
		JsonObject checkList = new JsonObject();
		JsonArray uoChecklistResponseArray = new JsonArray();
		MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
		urlParams.add(Constants.BUSINESS_LINE, businessLine);
		urlParams.add(Constants.FORM_NAME, formName);
		urlParams.add(Constants.CURRENT_USER_ID,currentUser);
		//by default action would be save, it would be submit once bpm instance is created and bpm id is returned
		urlParams.add(Constants.FORM_ACTION, "save");
		String onboardingId = null;
		String requestBody = "{}";
		try {
			response = remoteService.execute(formBaseUrl + formDynamicFormUrl, HttpMethod.POST, requestBody,
					urlParams, null, true);
			if (response == null || !response.getStatusCode().is2xxSuccessful()) {
				String error = "Error occurred while saving form " + formName + " for onboarding id " + onboardingId +
						Constants.CORE_URL + formDynamicFormUrl + Constants.CALL_FAIL;
				log.error(error);
			}
			//extract id again, needed if submit is done directly
			if (null != response) {
				onboardingId = JsonParser.parseString(response.getBody()).getAsJsonObject().get(Constants.ONBOARDING_ID).getAsString();
			}
			String responseBody =null;
			log.debug("save form response : {}", response);
			if(Objects.nonNull(response.getBody())){
				responseBody = response.getBody();
			}
			ResponseEntity<String> checkListResponse = getPopulateCheckListResponse(onboardingId, responseBody, businessLine);
			log.info("getChecklistData completed" + onboardingId);
			if(Objects.nonNull(checkListResponse.getBody())){
				JsonArray uoChecklistArray = JsonParser.parseString(checkListResponse.getBody()).getAsJsonArray();
				for (JsonElement checkListValue : uoChecklistArray) {
					populateUserCheckList(checkListValue, uoChecklistResponseArray);
				}
			}
			checkList.add("checkList", uoChecklistResponseArray);
		} catch (Exception e) {
			String saveFormServiceURL = formBaseUrl + formDynamicFormUrl;
			log.error("Error occurred when returingChecklist in  form " + formName + " for onboarding id " + onboardingId +
					Constants.CORE_URL + saveFormServiceURL + Constants.CALL_FAIL, e);
			throw new BusinessException(e.getMessage());
		}
		return checkList;
	}

	private ResponseEntity<String> getPopulateCheckListResponse(String onboardingId, String responseBody, String businessLine) {
		return populateChecklist(onboardingId, responseBody,
				"",
				Constants.DGP_ONBOARDING_CHECKLIST, businessLine);
	}

	private ResponseEntity<String> populateChecklist(String onboardingId, String responseBody, String instanceId,
													 String checklistId, String businessLine) {
		log.info("populateChecklist :: onboardingId : " + onboardingId +
				" instanceId : " + instanceId +
				" checklistId : " + checklistId);
		ResponseEntity<String> response = null;
		MultiValueMap<String, String> urlParam = new LinkedMultiValueMap<>();
		urlParam.add(Constants.ONBOARDING_ID, onboardingId);
		urlParam.add("typeId", Constants.CHECKLIST_TYPEID);
		urlParam.add("checklistId", checklistId);
		urlParam.add(Constants.BUSINESS_LINE, businessLine);
		urlParam.add(Constants.INSTANCE_ID, instanceId);

		response = remoteService.execute(formBaseUrl + formCheckListUrl, HttpMethod.POST, responseBody,
				urlParam, null, true);
		log.debug("populateChecklist reponse : " + response);
		if (response == null || !response.getStatusCode().is2xxSuccessful()) {
			String error = "Error occurred while saving Checklist for onboarding id " + onboardingId +
					Constants.CORE_URL + formCheckListUrl + Constants.CALL_FAIL;
			log.error(error);
		}
		log.info("populateChecklist completed");
		return response;
	}

	private void populateUserCheckList(JsonElement checkListValue, JsonArray uoChecklistResponseArray) {
		JsonObject checkList = new JsonObject();
		String checkListId = checkListValue.getAsJsonObject().get("id").getAsString();
		String name = checkListValue.getAsJsonObject().get("name").getAsString();
		String onboardingId = checkListValue.getAsJsonObject().get(Constants.ONBOARDING_ID).getAsString();
		checkList.addProperty("checkListId", checkListId);
		checkList.addProperty("name", name);
		checkList.addProperty(Constants.ONBOARDING_ID, onboardingId);
		uoChecklistResponseArray.add(checkList);
	}

	public List<PickList> getCountryList() {
		List<PickList> countryList = new ArrayList<>();
		String refsString = getRefs("19");
		JsonArray refsData = JsonParser.parseString(refsString).getAsJsonArray();
		if (refsData.isJsonNull()) {
			log.info("Refs Metadata is empty from backend for Country");
			return countryList;
		}
		refsData.forEach(refData -> {
			if (!refData.getAsJsonObject().get("name").getAsString().isEmpty()) {
				PickList pickList = new PickList();
				pickList.setId(refData.getAsJsonObject().get("name").getAsString());
				pickList.setValue(refData.getAsJsonObject().get("name").getAsString());
				countryList.add(pickList);
			}
		});

		return countryList;
	}

	public List<PickList> getStateList() {
		List<PickList> stateList = new ArrayList<>();
		String refsString = getRefs("126");
		JsonArray refsData = JsonParser.parseString(refsString).getAsJsonArray();
		if (refsData.isJsonNull()) {
			log.info("Refs Metadata is empty from backend for State");
			return stateList;
		}
		refsData.forEach(refData -> {
			if (!refData.getAsJsonObject().get("name").getAsString().isEmpty()) {
				PickList pickList = new PickList();
				pickList.setId(refData.getAsJsonObject().get("string1").getAsString());
				pickList.setValue(refData.getAsJsonObject().get("name").getAsString());
				stateList.add(pickList);
			}
		});

		return stateList;
	}

	@Cacheable(cacheNames = "uo-refslist", key = "#typeId")
	public String getRefs(String typeId) {
		ResponseEntity<String> response = null;
		try {
			response = getRefsbyTypeId(Integer.parseInt(typeId));
			if (response == null || !response.getStatusCode().is2xxSuccessful()) {
				throw new ServiceException("Error getting Refs");
			}
			return response.getBody();
		} catch (Exception e) {
			log.error("Error occurred in: getRefs.", e);
			throw new ServiceException(e.getMessage());
		}
	}

	@Value("${form.service.v1.refsByTypeId}")
	private String refsByTypeId;
	public ResponseEntity<String> getRefsbyTypeId(Integer typeId) {
		ResponseEntity<String> responseEntity = null;
		Map<String, Integer> pathVar = new HashMap<>();
		pathVar.put("typeId", typeId);
		String uriString = formBaseUrl + refsByTypeId;
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
		String uri = builder.buildAndExpand(pathVar).toString();
		log.debug("getRefsbyTypeId .... uri=" + uri);
		try {
			responseEntity = remoteService.execute(uri, HttpMethod.GET, null, null, null, true);
		} catch (Exception exp) {
			log.error("Error occurred in: getRefsbyTypeId.", exp);
			throw new ServiceException(exp.getMessage());
		}
		return responseEntity;
	}

	@Value("${metadata.service.baseurl}")
	private String metadataServiceBaseUrl;

	@Value("${metadata.service.forms.metadata}")
	private String v1FormMetadata;
	public JsonObject fetchFormMetadata(Long onboardingId, String checklistId, String fundId,
										String advisorId, String classId, String formName) {
		ResponseEntity<String> response = null;
		MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
		urlParams.add(Constants.CHECKLIST_ID, checklistId);
		urlParams.add(Constants.FUND_ID, fundId);
		urlParams.add(Constants.ADVISOR_ID, advisorId);
		urlParams.add(Constants.CLASS_ID, classId);
		try{
			response = remoteService.fetch(onboardingId, metadataServiceBaseUrl + v1FormMetadata + formName + "/metadata?",
					HttpMethod.GET, null, urlParams, null);
			if (response == null || !response.getStatusCode().is2xxSuccessful()) {
				throw new ServiceException("Error getting form Meta Data");
			}
			if (response.getBody() == null) {
				return null;
			}
			return JsonParser.parseString(response.getBody()).getAsJsonObject();
		} catch (Exception e) {
			log.error("Error occurred in: getFormMetadata.", e);
			throw new ServiceException(e.getMessage());
		}
	}

	@Value("${metadata.service.mapping}")
	private String metadataMapping;
	public ResponseEntity<Object> saveMetadata(Long onboardingId, Map<String, Object> details, String checklistId,
											   String fundId, String advisorId, String classId) {

		ResponseEntity<String> response = null;

		MultiValueMap<String, String> urlParams = new LinkedMultiValueMap<>();
		urlParams.add(Constants.CHECKLIST_ID, checklistId);
		urlParams.add(Constants.FUND_ID, fundId);
		urlParams.add(Constants.ADVISOR_ID, advisorId);
		urlParams.add(Constants.CLASS_ID, classId);
		try {
			response = remoteService.fetch(onboardingId, metadataServiceBaseUrl + metadataMapping, HttpMethod.POST,
					details, urlParams, null);
			if (response == null || !response.getStatusCode().is2xxSuccessful()) {
				log.error("Error occurred in: addForm.", metadataServiceBaseUrl, metadataMapping, " call failed");
			}
			return new ResponseEntity<>(response != null ? response.getBody() : null, HttpStatus.OK);
		} catch (Exception e) {
			throw new ServiceException(e.getMessage());
		}

	}
	public ResponseEntity<String> getAuditTrail(String onboardingId, String businessLine) {
		log.info("getAuditTrail :: onboardingId : {}", onboardingId, businessLine);
		ResponseEntity<String> auditTrailResponse = null;
		MultiValueMap<String, String> urlParam = new LinkedMultiValueMap<>();
		urlParam.add(Constants.ONBOARDING_ID, onboardingId);
		urlParam.add(Constants.BUSINESS_LINE, businessLine);
		try {
			auditTrailResponse = connectService.fetchRecord(auditBaseUrl+getAuditTrailUrl, HttpMethod.GET, null,urlParam);
		} catch(Exception e) {
			log.error("Error occurred in saving audit for onboarding id "+ onboardingId +e.getMessage());
		}
		return auditTrailResponse;
	}
}
