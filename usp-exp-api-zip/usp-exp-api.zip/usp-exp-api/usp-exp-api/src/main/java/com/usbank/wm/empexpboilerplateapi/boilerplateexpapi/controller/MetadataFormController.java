package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;

import com.google.gson.JsonObject;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.BoilerplateService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.FormService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Slf4j
public class MetadataFormController implements SecuredController {

    private FormService formService;
    private BoilerplateService boilerplateService;

    @Autowired
    public MetadataFormController(FormService formService, BoilerplateService boilerplateService) {
        this.formService = formService;
        this.boilerplateService = boilerplateService;
    }

    @GetMapping(value = "/v1/forms/{formName}/metadata", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> fetchFormMetadata(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestHeader(value = Constants.HEADER_ONBOARDING_ID) Long onboardingId,
            @RequestParam(value = Constants.CHECKLIST_ID, required = false) String checklistId,
            @RequestParam(value = Constants.FUND_ID, required = false) String fundId,
            @RequestParam(value = Constants.ADVISOR_ID, required = false) String advisorId,
            @RequestParam(value = Constants.CLASS_ID, required = false) String classId,
            @PathVariable(value = "formName") String formName) {

        log.info("Inside MetadataFormController class in getFormMetadata() method -> onboardingId{} :", onboardingId);

        JsonObject formMetadata = formService.fetchFormMetadata(onboardingId, checklistId, fundId, advisorId, classId, formName);
        if (formMetadata == null) {
            return new ResponseEntity<>("{}", HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(formMetadata.toString(), HttpStatus.OK);
    }
    @PostMapping(value = "/v1/forms/{formName}/metadata", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveMetadata(@RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
                                               @RequestBody Map<String, Object> details,
                                               @RequestHeader(value = Constants.HEADER_ONBOARDING_ID) Long onboardingId,
                                               @RequestParam(value = Constants.CHECKLIST_ID, required = false) String checklistId,
                                               @RequestParam(value = Constants.FUND_ID, required = false) String fundId,
                                               @RequestParam(value = Constants.ADVISOR_ID, required = false) String advisorId,
                                               @RequestParam(value = Constants.CLASS_ID, required = false) String classId) {

        ResponseEntity<Object> response = formService.saveMetadata(onboardingId, details, checklistId, fundId,
                advisorId, classId);
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);

    }
    @GetMapping(value = "/v1/metadata", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getTableMetadata(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestParam(value = "onboardingType") String onboardingType,
            @RequestParam(value = "userRole") String userRole,
            @RequestParam(value = "pageName") String pageName,
            @RequestParam(value = "typeName") String typeName) {
        try {
            log.info("getTableMetadata > "+typeName);
            long startTime = System.currentTimeMillis();
            String response = boilerplateService.getTableMetadata(authorization, onboardingType, userRole, pageName, typeName);
            log.info("Response > "+response);
            long endTime = System.currentTimeMillis();
            log.info("Time taken for metadata api call " + (endTime - startTime) + " milliseconds");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            log.info("Exception in getting table metadata for onboardingType" + onboardingType);
        }
        return new ResponseEntity<>("", HttpStatus.NO_CONTENT);

    }

}
