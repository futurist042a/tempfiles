package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import ch.qos.logback.core.net.SyslogOutputStream;
import com.google.gson.*;
import jakarta.websocket.CloseReason;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.*;
import java.util.Base64;

@Service
@Slf4j
public class USPService {
    @Autowired
    MongoDBService mongoDBService;

    @Autowired
    AppBuilderService appBuilderService;

    @Autowired
    private RemoteService remoteService;

    public JsonObject createApplication( Map<String, Object> requestBody){
        log.info("Appbuilder Service: Create Application");
        String requestJsonBody = requestBody != null ? new Gson().toJson(requestBody) : null;
        log.info(requestJsonBody);

        JsonObject responseObj = new JsonObject();

        //Insert the Application details
        String appId = mongoDBService.insertObject("USP_APPLICATION",requestJsonBody);

        JsonObject appData = JsonParser.parseString(requestJsonBody).getAsJsonObject();
        String acronym = appData.get("acronym").getAsString();
        String objTemplate = appData.get("objectTemplate").getAsString();

        //Create Application Collection
        String appCollection = acronym+"_EVENT";
        mongoDBService.createCollection(appCollection);

        responseObj.addProperty("applicationId", appId);
        responseObj.addProperty(acronym+"_EVENT", "created");

        //Query Obj Template and Insert Event Object in collection created
        String eventObjectId = "";
        JsonArray templateObjArray = JsonParser.parseString(mongoDBService.getEventObjectTemplate(objTemplate)).getAsJsonArray();
        if(templateObjArray != null && templateObjArray.get(0) != null &&
                templateObjArray.get(0).getAsJsonObject().get("data") != null &&
                templateObjArray.get(0).getAsJsonObject().get("data").getAsJsonArray() != null){
            JsonArray templateDataItems = templateObjArray.get(0).getAsJsonObject().get("data").getAsJsonArray();
            if(templateDataItems.get(0) != null && templateDataItems.get(0).getAsJsonObject().get("templateObject") != null){
                JsonObject eventTmptObj = templateDataItems.get(0).getAsJsonObject().get("templateObject").getAsJsonObject();

                Set<Map.Entry<String, JsonElement>> entries = eventTmptObj.entrySet();
                for(Map.Entry<String, JsonElement> entry: entries) {
                    log.info("------------------- KEY :: "+entry.getKey());
                    if(entry.getKey().equalsIgnoreCase("eventObj")){//Collection is already created with acronym_EVENT
                        log.info("Inserting the Event Object Data");
                        eventObjectId = mongoDBService.insertObject(appCollection,entry.getValue().toString());
                        responseObj.addProperty("eventObjId", eventObjectId);
                    }else{
                        String otherCollection = acronym+"_"+entry.getKey().toUpperCase();
                        log.info("Inserting the New Collection : "+otherCollection);
                        mongoDBService.createCollection(otherCollection);
                        String otherCollectionId = mongoDBService.insertObject(otherCollection,entry.getValue().toString());
                        responseObj.addProperty(entry.getKey()+"Id", otherCollectionId);
                    }
                }
            }
        }

        //Query Landing Page Template and Insert in FORM Collection
        JsonArray landingPageTmplArray = JsonParser.parseString(mongoDBService.getLandingPageJson()).getAsJsonArray();
        if(landingPageTmplArray != null && landingPageTmplArray.get(0) != null &&
                landingPageTmplArray.get(0).getAsJsonObject().get("data") != null &&
                landingPageTmplArray.get(0).getAsJsonObject().get("data").getAsJsonArray() != null) {
            JsonArray landingPageTmplItems = landingPageTmplArray.get(0).getAsJsonObject().get("data").getAsJsonArray();
            if(landingPageTmplItems.get(0) != null && landingPageTmplItems.get(0).getAsJsonObject().get("formJSON") != null){
                JsonArray landingPageTmptObj = landingPageTmplItems.get(0).getAsJsonObject().get("formJSON").getAsJsonArray();

                JsonArray formObjectArray =JsonParser.parseString(landingPageTmptObj.toString().replace("_Id_", eventObjectId)).getAsJsonArray();

                JsonObject landingPageFormObj = new JsonObject();
                landingPageFormObj.addProperty("appName",appData.get("shortName").getAsString());
                landingPageFormObj.addProperty("screen","Landing Page");
                landingPageFormObj.addProperty("section","");
                landingPageFormObj.addProperty("uicomponent","");
                landingPageFormObj.addProperty("searchKey",appData.get("shortName").getAsString()+".LandingPage");
                landingPageFormObj.add("formJson",formObjectArray);

                String landingPageId = mongoDBService.insertObject("USP_FORMS",landingPageFormObj.toString());
                responseObj.addProperty("landingPageId", landingPageId);
            }
        }

        //Create the JSFunction for the new application
        JsonArray jsFunctionTmplArray = JsonParser.parseString(mongoDBService.getJSFunctionJson()).getAsJsonArray();
        if(jsFunctionTmplArray != null && jsFunctionTmplArray.get(0) != null &&
                jsFunctionTmplArray.get(0).getAsJsonObject().get("data") != null &&
                jsFunctionTmplArray.get(0).getAsJsonObject().get("data").getAsJsonArray() != null) {
            JsonObject jsFunctionTmp = jsFunctionTmplArray.get(0).getAsJsonObject();
            String scriptEncoded =  jsFunctionTmp.get("data").getAsJsonArray().get(0).getAsJsonObject().get("script").getAsString();

            // Decode the jsFunction
            byte[] decodedBytes = Base64.getDecoder().decode(scriptEncoded);
            String decodedString = new String(decodedBytes);
            decodedString = decodedString.replace("_appShortName_", appData.get("shortName").getAsString());

            //Encode the jsFunction
            byte[] byteArray = decodedString.getBytes();
            String encodedString = Base64.getEncoder().encodeToString(byteArray);

            String dataString = "[{'script' : '"+encodedString+"'}]";
            JsonArray dataArray =JsonParser.parseString(dataString).getAsJsonArray();

            jsFunctionTmp.remove("_id");
            jsFunctionTmp.addProperty("name",appData.get("shortName").getAsString()+"Script");
            jsFunctionTmp.addProperty("applicationName",appData.get("shortName").getAsString());
            jsFunctionTmp.add("data",dataArray);
            String jsFunctionId = mongoDBService.insertObject("USP_REFS",jsFunctionTmp.toString());
            responseObj.addProperty("jsFunctionId", jsFunctionId);

            //Update App Builder Web Server
            appBuilderService.updateJSFunction(appData.get("shortName").getAsString(),decodedString);
        }

        //Create the CSS for the new application
        JsonArray cssTmplArray = JsonParser.parseString(mongoDBService.getStyleJson()).getAsJsonArray();
        if(cssTmplArray != null && cssTmplArray.get(0) != null &&
                cssTmplArray.get(0).getAsJsonObject().get("data") != null &&
                cssTmplArray.get(0).getAsJsonObject().get("data").getAsJsonArray() != null) {
            JsonObject cssTmp = cssTmplArray.get(0).getAsJsonObject();
            String scriptEncoded =  cssTmp.get("data").getAsJsonArray().get(0).getAsJsonObject().get("style").getAsString();

            // Decode the CSS
            byte[] decodedBytes = Base64.getDecoder().decode(scriptEncoded);
            String decodedString = new String(decodedBytes);
            decodedString = decodedString.replace("_Application_", appData.get("appName").getAsString());

            //Encode the CSS
            byte[] byteArray = decodedString.getBytes();
            String encodedString = Base64.getEncoder().encodeToString(byteArray);

            String dataString = "[{'style' : '"+encodedString+"'}]";
            JsonArray dataArray =JsonParser.parseString(dataString).getAsJsonArray();

            cssTmp.remove("_id");
            cssTmp.addProperty("name",appData.get("shortName").getAsString()+"Style");
            cssTmp.addProperty("applicationName",appData.get("shortName").getAsString());
            cssTmp.add("data",dataArray);
            String cssId = mongoDBService.insertObject("USP_REFS",cssTmp.toString());
            responseObj.addProperty("styleId", cssId);

            //Update App Builder Web Server
            appBuilderService.updateStyle(appData.get("shortName").getAsString(),decodedString);
        }

        return responseObj;
    }

    /*{
        "objectQueries": [],
        "dataQueries": []
    }*/
    public Map<String,Object> executeFormDataRequest(String transactionId, String screenSearch, Boolean isSave, Map<String, Object> requestBody ){
        log.info("Entering into executeFormDataRequest : transactionId : " + transactionId + "  screenSearch : " + screenSearch
                + "  isSave : " + isSave);
        String requestJsonBody = requestBody != null ? new Gson().toJson(requestBody) : null;
        log.info(requestJsonBody);

        JsonObject data = JsonParser.parseString(requestJsonBody).getAsJsonObject();

        Map<String, Object> response = new HashMap<>();

        //Check if screenSearch is passed, if so retrieve the Form JSON
        if(screenSearch != ""){
            response.put("screenFormJson", mongoDBService.getFormJson(screenSearch));
        }

        JsonElement reqCommonObjects = data.get("commonObjects");
        //Execute the call to Exp API
        if(data.get("serviceCall") != null && data.get("serviceCall").getAsJsonObject().get("endpoint") != null) {
            log.info("Service Call included");
            JsonObject serviceRequestJson = new JsonObject();
            serviceRequestJson.add("dataObjects",reqCommonObjects);
            JsonObject expApiResponse = executeServiceCall(data.get("serviceCall").getAsJsonObject(),serviceRequestJson.toString());
            reqCommonObjects = expApiResponse.get("dataObjects");
        }

        //Check isSave
        if(isSave){
            log.info("isSave is true");
            JsonObject insertResponse = new JsonObject();
            //Check if _id is available to check if its a insert or update
            //if(data.get("commonObjects") != null){
            if(reqCommonObjects != null){
                JsonArray commonObjects = reqCommonObjects.getAsJsonArray();
                for (JsonElement commonObj : commonObjects) {
                    JsonObject commonObjItem = commonObj.getAsJsonObject();
                    JsonElement commonObjData = commonObjItem.get("data");

                    if(commonObjData.getAsJsonObject().get("_id") != null){
                        log.info("Updating the Common Object");
                        long updatedCount = mongoDBService.updateObject(commonObjItem.toString());
                        String updateRes = updatedCount == 1? "Updated" : "Not Updated";
                        insertResponse.addProperty(
                                commonObjItem.get("type").getAsString(),
                                updateRes
                        );
                    }else{
                        log.info("Inserting the Common Object");
                        insertResponse.addProperty(
                                commonObjItem.get("type").getAsString(),
                                mongoDBService.insertObject(commonObjItem.toString())
                        );
                    }
                }
            }
            response.put("commonObjectResponse",insertResponse);
        }

        //Execute the Object Queries
        if(data.get("objectQueries") != null) {
            JsonArray objQueryItems = data.get("objectQueries").getAsJsonArray();
            for (JsonElement queryItemObj : objQueryItems) {
                JsonObject queryItem = queryItemObj.getAsJsonObject();

                response.put(queryItem.get("Alias").getAsString(), mongoDBService.executeObjectQuery(queryItem.toString()));
            }
        }

        return response;
    }

    private JsonObject executeServiceCall(JsonObject serviceObj, String requestBody) {
        log.info("------executeServiceCall : "+serviceObj);
        log.info("------executeServiceCall - requestBody : "+requestBody);
        ResponseEntity<String> rolesDetails;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();

        String endpoint = serviceObj.get("endpoint").getAsString();
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(endpoint);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
            httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);

            //Add Custom headers, if any
            if(serviceObj.get("header") != null) {
                JsonObject customHeaders = serviceObj.get("header").getAsJsonObject();
                Set<Map.Entry<String, JsonElement>> entries = customHeaders.entrySet();
                for(Map.Entry<String, JsonElement> entry: entries) {
                    log.info("------------------- KEY :: " + entry.getKey());
                    httpHeaders.add(entry.getKey(), entry.getValue().toString());
                }
            }

            HttpEntity<String> request = new HttpEntity<>(requestBody,httpHeaders);
            HttpMethod httpMethod = HttpMethod.POST;
            if(serviceObj.get("method") != null){
                String method = serviceObj.get("method").getAsString();
                if(method.equalsIgnoreCase("get")) {httpMethod = HttpMethod.GET;}
                else if(method.equalsIgnoreCase("put")) {httpMethod = HttpMethod.PUT;}
            }

            rolesDetails = restTemplate.exchange(uri, httpMethod, request, String.class);
            String tempBody = rolesDetails.getBody();
            JsonObject response  = JsonParser.parseString(tempBody).getAsJsonObject();
            return response;
        } catch (HttpStatusCodeException hts) {
            log.error("executeServiceCall() exception : {} ", hts.getResponseHeaders());
            throw hts;
        }
    }

}
