package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.helpher;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface USPMongoRepository {
    public String fetchDocuments(String CollectionName, String jsonQuery, String projectionJson, String sortJson);
    public String insertDocumentStr(String collectionName, String documentJSON);
    public long updateDocument(String collectionName, String filtersJSON, String updatesJSON, String arrayFiltersJSON, boolean upsert);
    public long replaceRecord(String collectionName, String filtersJSON, String updatesJSON, boolean upsert);
    public void createCollection(String collectionName);
}