
package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "eventOperationType",
    "transactionIdentifier",
    "eventPublicationDateTimeStamp",
    "eventPublisher",
    "eventPublisherIdentity",
    "eventDateTimeStamp",
    "eventInitiator",
    "eventInitiatorIdentity",
    "eventInitiatorChannel"
})
@Data
@Builder
public class EventMetaData implements Serializable
{

    @JsonProperty("eventOperationType")
    private String eventOperationType;
    @JsonProperty("transactionIdentifier")
    private String transactionIdentifier;
    @JsonProperty("eventPublicationDateTimeStamp")
    private String eventPublicationDateTimeStamp;
    @JsonProperty("eventPublisher")
    private String eventPublisher;
    @JsonProperty("eventPublisherIdentity")
    private String eventPublisherIdentity;
    @JsonProperty("eventDateTimeStamp")
    private String eventDateTimeStamp;
    @JsonProperty("eventInitiator")
    private String eventInitiator;
    @JsonProperty("eventInitiatorIdentity")
    private String eventInitiatorIdentity;
    @JsonProperty("eventInitiatorChannel")
    private String eventInitiatorChannel;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    private static final long serialVersionUID = -6081891590912165167L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(EventMetaData.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("eventOperationType");
        sb.append('=');
        sb.append(((this.eventOperationType == null)? Constants.NULL_STRING:this.eventOperationType));
        sb.append(',');
        sb.append("transactionIdentifier");
        sb.append('=');
        sb.append(((this.transactionIdentifier == null)? Constants.NULL_STRING:this.transactionIdentifier));
        sb.append(',');
        sb.append("eventPublicationDateTimeStamp");
        sb.append('=');
        sb.append(((this.eventPublicationDateTimeStamp == null)? Constants.NULL_STRING:this.eventPublicationDateTimeStamp));
        sb.append(',');
        sb.append("eventPublisher");
        sb.append('=');
        sb.append(((this.eventPublisher == null)? Constants.NULL_STRING:this.eventPublisher));
        sb.append(',');
        sb.append("eventPublisherIdentity");
        sb.append('=');
        sb.append(((this.eventPublisherIdentity == null)? Constants.NULL_STRING:this.eventPublisherIdentity));
        sb.append(',');
        sb.append("eventDateTimeStamp");
        sb.append('=');
        sb.append(((this.eventDateTimeStamp == null)? Constants.NULL_STRING:this.eventDateTimeStamp));
        sb.append(',');
        sb.append("eventInitiator");
        sb.append('=');
        sb.append(((this.eventInitiator == null)? Constants.NULL_STRING:this.eventInitiator));
        sb.append(',');
        sb.append("eventInitiatorIdentity");
        sb.append('=');
        sb.append(((this.eventInitiatorIdentity == null)? Constants.NULL_STRING:this.eventInitiatorIdentity));
        sb.append(',');
        sb.append("eventInitiatorChannel");
        sb.append('=');
        sb.append(((this.eventInitiatorChannel == null)? Constants.NULL_STRING:this.eventInitiatorChannel));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)? Constants.NULL_STRING:this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
