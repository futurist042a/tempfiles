package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class AppBuilderService {
    Logger logger = LoggerFactory.getLogger(AppBuilderService.class);

    @Value("${appbuilder.cdn.baseurl}")
    private String appBuilderBaseURL;

    @Value("${appbuilder.cdn.styleurl}")
    private String styleURL;

    @Value("${appbuilder.cdn.jsfunctionurl}")
    private String jsFuncURL;

    public void updateJSFunction(String appName, String jsFuncData) {
        ResponseEntity<String> response;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("appName", appName);

        String uriString = appBuilderBaseURL + jsFuncURL;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            //httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            String updatedJsFunc = jsFuncData.replaceAll("export ","").replaceAll("import","//import");
            //jsFunction.replace(/export /g, '').replace(/import/g, '//import');
            HttpEntity<String> request = new HttpEntity<>(updatedJsFunc, httpHeaders);

            log.info("updateJSFunction > " + uri);
            response = restTemplate.exchange(uri, HttpMethod.POST, request, String.class);
            logger.info("updateJSFunction() response : {}", response.getBody());

        } catch (HttpStatusCodeException hts) {
            logger.error("updateJSFunction() exception : {} ", hts.getResponseHeaders());
            //throw hts;
        }
    }

    public void updateStyle(String appName, String styleData) {
        ResponseEntity<String> response;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("appName", appName);

        String uriString = appBuilderBaseURL + styleURL;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            HttpEntity<String> request = new HttpEntity<>(styleData, httpHeaders);

            log.info("updateStyle > " + uri);
            response = restTemplate.exchange(uri, HttpMethod.POST, request, String.class);
            logger.info("updateStyle() response : {}", response.getBody());

        } catch (HttpStatusCodeException hts) {
            logger.error("updateStyle() exception : {} ", hts.getResponseHeaders());
            //throw hts;
        }
    }
}