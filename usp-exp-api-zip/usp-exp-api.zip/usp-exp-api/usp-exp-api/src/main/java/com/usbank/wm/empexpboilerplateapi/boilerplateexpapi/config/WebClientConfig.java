package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {
	@Value("${event.service.baseurl}")
	private String formBaseUrl;
	@Value("${task.service.baseurl}")
	private String taskServiceBaseUrl;

	@Bean(name = "webClient")
	WebClient getWebClient() {
		return WebClient.builder().baseUrl(formBaseUrl)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
	}

	@Value("${entitlement.service.baseurl}")
	private String entitlementServiceBaseUrl;

	@Bean(name = "entitlementClient")
	WebClient getEntitlementClient() {
		return WebClient.builder().baseUrl(entitlementServiceBaseUrl)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
	}
	@Bean(name = "taskClient")
	WebClient getTaskClient() {
		return WebClient.builder().baseUrl(taskServiceBaseUrl)
				.codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024))
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
	}
}
