package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Form {
	private String fileLocation;
	private String formId;
	private String formLabel;
	private String formGuid;
	private String offset;
	private String order;
	private String formCode;
	private String formCategoryName;
	private String label;
	private String value;
}
