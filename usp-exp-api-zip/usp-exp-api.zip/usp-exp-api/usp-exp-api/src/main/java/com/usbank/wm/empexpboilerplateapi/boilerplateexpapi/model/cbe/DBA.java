package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.cbe;

public class DBA {
    Address address;
    String dbaName;
}
