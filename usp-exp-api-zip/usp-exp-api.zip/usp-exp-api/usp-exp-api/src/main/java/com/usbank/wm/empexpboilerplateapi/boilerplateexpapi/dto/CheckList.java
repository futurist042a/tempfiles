package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CheckList implements Serializable {

	private static final long serialVersionUID = 1L;
    private String id;
    private Long onboardingId;
    private String name;
    private String dueDate;
    private String assignedTo;
    private String businessLine;
    private String checklistType;
    private String status;
    private String details;
    private String reviewerTeam;
    private Boolean isActive;
    private Long version;
    private String searchKey1;
    private String searchKey2;
    private String searchKey3;
    private String searchKey4;
    private Integer refsId;


}
