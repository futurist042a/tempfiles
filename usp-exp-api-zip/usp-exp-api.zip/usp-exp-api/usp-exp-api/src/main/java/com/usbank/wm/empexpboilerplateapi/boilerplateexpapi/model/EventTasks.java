package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventTasks {

    private String taskId;
    private String task;
    private String displayName;
    private String due;
    private String onboardingId;
    private boolean hyperLink;
    private String taskType;
    private String status;
    private String name;
    private String assignerRoles;
    private String assignedToRoles;
    private String lastupdated;
    private String updatedby;
    private String reAssignTask;
    private String assignedTo;
    private String relationshipManagerId;
    private String refId;
}
