package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Decision;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.DecisionResponse;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Form;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

import java.util.List;

@Service
@Slf4j
public class DocumentService {
	@Autowired
	@Qualifier("boilerplateRestTemplate")
	private RestTemplate restTemplate;
	@Value("${money.center.url}")
	private String money_center_url;
	@Autowired
	private RemoteService remoteService;

	public DecisionResponse fetchDocumentList(Decision decision) throws JsonProcessingException, Exception {
		try {
			log.info("decision: decision{} ", decision);
			ObjectMapper mapper = new ObjectMapper();
			String jsonStr = mapper.writeValueAsString(decision);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> entity = new HttpEntity<>(jsonStr, headers);
			log.info("entity: entity{} ", entity);
			ResponseEntity<String> response = remoteService.execute(money_center_url, HttpMethod.POST, jsonStr, null,
					headers, false);
			log.info("response: response{} ", response);
			DecisionResponse decisionResponse = mapper.readValue(response.getBody(), DecisionResponse.class);
			List<Form> standard = decisionResponse.getFormsDeterminationRes().getStandardForms();
			List<Form> additional = decisionResponse.getFormsDeterminationRes().getAdditionalForms();
			standard.stream().forEach(form -> {form.setLabel(form.getFormLabel());form.setValue(form.getFormId());});
			additional.stream().forEach(form -> {form.setLabel(form.getFormLabel());form.setValue(form.getFormId());});
			return decisionResponse;
		} catch (Exception ex) {
			log.error("{} ", ex);
			throw ex;
		}
	}
}
