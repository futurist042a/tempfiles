package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.actions;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Document;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.DocumentService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.FilenetService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.RemoteService;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
@Slf4j
public class DocumentAction implements IDocumentAction {


    @Value("${document.service.base.url}")
    private String documentBaseUrl;

    @Value("${document.service.pdfmapping}")
    private String documentPdfMapping;

    @Autowired
    FilenetService filenetService;

    @Autowired
    DocumentService documentService;

    MultiValueMap<String, String> headerParams;

    @Autowired
    private RemoteService remoteService;

    public List<Document> searchDocuments(String onboardingId, String onboardingType, String accountNumber) {

        log.info("In searchDocuments , accountNumber :: {}", accountNumber);
        log.info("In searchDocuments , onboardingId :: {}", onboardingId);
        String filterCriteria = "OnboardingId eq '" + onboardingId + "'";
        List<Document> documents = new ArrayList<>();

        //TODO:Write the BL spec code here
        try {
            ResponseEntity<ByteArrayResource> searchDocsResponse = filenetService.searchDocuments(onboardingId,
                    filterCriteria, onboardingType);
            // Fetching docs from filenet metadata, docs uploaded from employee view wont be
            ByteArrayResource resource = searchDocsResponse.getBody();
            if (null == resource) {
                return documents;
            }
            // fetch Document Categories from refs table
            JSONObject resourceJson = new JSONObject(new String(resource.getByteArray(), StandardCharsets.UTF_8));
            JsonArray valueArray = JsonParser.parseString(resourceJson.toString()).getAsJsonObject().get("value")
                    .getAsJsonArray();

            for (JsonElement valueElement : valueArray) {
                JsonObject value = valueElement.getAsJsonObject();
                Document document = new Document();
                document.setContentElementCount(value.get("ContentElementCount").getAsString());
                document.setDocumentArea(value.get("DocumentArea").getAsString());
                document.setDocumentId(value.get(Constants.DOCUMENT_ID).getAsString());
                document.setDocumentClass(value.get("DocumentClass").getAsString());
                populateDocumentMetadata(document, value);
                documents.add(document);
            }
        } catch (Exception e) {
            log.error("Error occurred in: searchDocuments", e);
            throw new ServiceException(e.getMessage());
        }
        return documents;
    }



    public void populateDocumentMetadata(Document document, JsonObject value) {
        JsonArray docMetaDataArray = value.get("MetaData").getAsJsonArray();
        for (JsonElement docMetaDataElement : docMetaDataArray) {
            JsonObject docMetaData = docMetaDataElement.getAsJsonObject();
            String propertyName = docMetaData.get("PropertyName").getAsString();
            if (null != docMetaData.get(Constants.DOCUMENT_VALUE)) {
                switch (propertyName) {
                    case "Status":
                        document.setStatus(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    case "DocumentTitle":
                        document.setFilename(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    case "DocumentType":
                        document.setCategory(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    case "DateCreated":
                        document.setUploadedOn(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    case "CreatedBy":
                        document.setUploadedBy(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    case "Creator":
                        document.setUserId(docMetaData.get(Constants.DOCUMENT_VALUE).getAsString());
                        break;
                    default:
                        break;
                }
            }
        }
    }


}
