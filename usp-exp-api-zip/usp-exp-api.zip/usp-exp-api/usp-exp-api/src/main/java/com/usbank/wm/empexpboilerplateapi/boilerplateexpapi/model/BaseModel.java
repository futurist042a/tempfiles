package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseModel implements Serializable {

  private static final long serialVersionUID = 1L;

  private String createdBy;
  private String createdDate;
  private String modifiedBy;
  private String modifiedDate;

  @Override
  public String toString() {
    return "BaseModel (createdBy=" + createdBy + ", createdDate=" + createdDate + ", modifiedBy="
            + modifiedBy + ", modifiedDate=" + modifiedDate+ ")";
  }
}
