package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BadRequestException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.BoilerplateService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.FormService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.SmartFormService;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@Slf4j
public class AuditTrailController {

    private BoilerplateService boilerplateService;

    @Autowired
    private FormService formService;

    @Autowired
    private SmartFormService smartFormService;
    Logger logger = LoggerFactory.getLogger(AuditTrailController.class);

    @Autowired
    public AuditTrailController(BoilerplateService boilerplateService) {
        this.boilerplateService = boilerplateService;
    }

    @GetMapping(value = "/v1/audit-trail")
    public ResponseEntity<String> getAuditTrail(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestParam(value = Constants.ONBOARDING_ID, required = false) Long onboardingId)
            throws JsonProcessingException {
        ResponseEntity<String> response = null;
        try {
            response = boilerplateService.getAuditTrail(onboardingId);
            return new ResponseEntity<String>(response.getBody().toString(), HttpStatus.OK);
        } catch (Exception e) {
            log.error("Exception getting in getAuditTrail");
        }
        return new ResponseEntity<>(response.getBody().toString(), HttpStatus.NO_CONTENT);
    }

    @PostMapping(value = "/v1/audit")
    public ResponseEntity<String> addAudit(
            @RequestParam(value = Constants.ONBOARDING_ID) String onboardingId,
            @RequestBody Map<String, Object> auditMap) {
        try {
            log.info("addAudit : onBoardingId : ", onboardingId, " auditMap : ", auditMap);
            if (auditMap == null || onboardingId == null) {
                throw new BadRequestException("Request body/onBoardingId cannot be empty");
            }
            boilerplateService.addAudit(onboardingId, auditMap);
            return new ResponseEntity<>(Constants.SUCCESS, HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Error in saving audit", e.getMessage());
        }
        return new ResponseEntity<>("Error in saving audit", HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @GetMapping(value = "/v1/forms/audit-trail", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getAuditTrails(
            @RequestParam(value = Constants.ONBOARDING_ID) String onboardingId,
            @RequestParam(value = Constants.BUSINESS_LINE) String businessLine,
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization) {

        try {
            ResponseEntity<String> response = formService.getAuditTrail(onboardingId, businessLine);
            return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
        } catch (Exception e) {
            logger.info("Exception in getting audit trail");
        }
        return new ResponseEntity<>("", HttpStatus.NO_CONTENT);
    }
}
