package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PickList implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1470998985809530432L;
    private String id;
    private String value;
    @Override
    public String toString() {
        return "PickList [id=" + id + ", value=" + value + ", getId()=" + getId() + ", getValue()="
                + getValue() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass() + ", toString()="
                + super.toString() + "]";
    }
}