
package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "eventName",
    "templateID",
    "eventMetaData",
    "userIdentifier",
    "emailInformation",
    "dynamicInformation"
})
@Data
@Builder
public class EmailRequest implements Serializable
{

    @JsonProperty("eventName")
    private String eventName;
    @JsonProperty("templateID")
    private String templateID;
    @JsonProperty("eventMetaData")
    private EventMetaData eventMetaData;
    @JsonProperty("userIdentifier")
    private UserIdentifier userIdentifier;
    @JsonProperty("emailInformation")
    private EmailInformation emailInformation;
    @JsonProperty("dynamicInformation")
    private List<DynamicInformation> dynamicInformation = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<>();
    private static final long serialVersionUID = 3069273894544370936L;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(EmailRequest.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("eventName");
        sb.append('=');
        sb.append(((this.eventName == null)? Constants.NULL_STRING:this.eventName));
        sb.append(',');
        sb.append("templateID");
        sb.append('=');
        sb.append(((this.templateID == null)? Constants.NULL_STRING:this.templateID));
        sb.append(',');
        sb.append("eventMetaData");
        sb.append('=');
        sb.append(((this.eventMetaData == null)? Constants.NULL_STRING:this.eventMetaData));
        sb.append(',');
        sb.append("userIdentifier");
        sb.append('=');
        sb.append(((this.userIdentifier == null)? Constants.NULL_STRING:this.userIdentifier));
        sb.append(',');
        sb.append("emailInformation");
        sb.append('=');
        sb.append(((this.emailInformation == null)? Constants.NULL_STRING:this.emailInformation));
        sb.append(',');
        sb.append("dynamicInformation");
        sb.append('=');
        sb.append(((this.dynamicInformation == null)? Constants.NULL_STRING:this.dynamicInformation));
        sb.append(',');
        sb.append("additionalProperties");
        sb.append('=');
        sb.append(((this.additionalProperties == null)? Constants.NULL_STRING:this.additionalProperties));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
