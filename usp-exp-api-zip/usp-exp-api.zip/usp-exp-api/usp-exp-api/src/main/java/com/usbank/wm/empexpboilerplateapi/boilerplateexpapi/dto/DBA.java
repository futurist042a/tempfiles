package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DBA {
    private String dbaName;
    private Address address;

    public String toString() {
        return String.format("{\"dbaName\":\"%s\",\"address\":%s}", dbaName, address);
    }
}
