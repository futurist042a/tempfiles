package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Decision;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.DecisionResponse;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.DocumentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DocumentListController {
	@Autowired
	private DocumentService documentService;

	@PostMapping("/v1/ruleset/forms")
	public DecisionResponse fetchDocumentList(@RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
											  @RequestBody Decision decision) throws JsonProcessingException, Exception {

		return documentService.fetchDocumentList(decision);
	}
}
