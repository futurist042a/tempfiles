package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@Slf4j
@Order(2)
@OpenAPIDefinition(info = @Info(title = "My API", version = "v1"))
@SecurityScheme(
        name = "bearerAuth",
        type = SecuritySchemeType.HTTP,
        bearerFormat = "JWT",
        scheme = "bearer"
)

public class WebSecurityConfig {

    Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);

    @Value("${spring.security.oauth2.resource.tokenInfoUri}")
    String introspectionUri;

    @Value("${spring.security.oauth2.client.clientId}")
    String clientId;

    @Value("${spring.security.oauth2.client.clientSecret}")
    String clientSecret;

   /* @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        log.info("WebSecurityConfig >>>>>>>>>>>>>>>>>>");
        http
                .cors()
                .disable()
                .csrf()
                .disable()
                .httpBasic()
                .disable();
        return http.build();
    }*/
/*
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .cors()
                .disable()
                .csrf()
                .disable()
                .httpBasic()
                .disable()
                .authorizeRequests(
                        authorizeRequests ->
                                authorizeRequests
                                        .requestMatchers("/swagger*", "/v2/**")
                                        .permitAll()
                                        .requestMatchers("/csrf/**")
                                        .permitAll()
                                        .requestMatchers("/actuator")
                                        .permitAll()
                                        .requestMatchers("/actuator/**")
                                        .permitAll()
                                        .requestMatchers("/v1/users/**")
                                        .permitAll()
                                        .requestMatchers("/swagger-ui.html")
                                        .permitAll()
                                        .requestMatchers("/swagger-ui.html/**")
                                        .permitAll()
                                        .requestMatchers("/swagger-ui/**")
                                        .permitAll()
                                        .requestMatchers("/v3/api-docs/swagger-config/**")
                                        .permitAll()
                                        .requestMatchers("/v3/api-docs/**")
                                        .permitAll()
                                        .requestMatchers("/swagger-resources/**")
                                        .permitAll()
                                        .anyRequest()
                                        .authenticated())
                .oauth2ResourceServer(
                        oauth2ResourceServer ->
                                oauth2ResourceServer.opaqueToken(
                                        opaqueToken ->
                                                opaqueToken
                                                        .introspectionUri(this.introspectionUri)
                                                        .introspectionClientCredentials(this.clientId, this.clientSecret)));


    }*/
@Bean
public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
    log.info("WebSecurityConfig >>>>>>>>>>>>>>>>>>");
    httpSecurity
            .cors()
            .disable()
            .csrf()
            .disable()
            .httpBasic()
            .disable();
//            .authorizeHttpRequests(
//                    authorizeHttpRequests ->
//                            authorizeHttpRequests
//                                    .requestMatchers("/swagger*", "/v2/**")
//                                    .permitAll()
//                                    .requestMatchers("/csrf/**")
//                                    .permitAll()
//                                    .requestMatchers("/actuator")
//                                    .permitAll()
//                                    .requestMatchers("/actuator/**")
//                                    .permitAll()
//                                    .requestMatchers("/v1/users/**")
//                                    .permitAll()
//                                    .requestMatchers("/swagger-ui.html")
//                                    .permitAll()
//                                    .requestMatchers("/swagger-ui.html/**")
//                                    .permitAll()
//                                    .requestMatchers("/swagger-ui/**")
//                                    .permitAll()
//                                    .requestMatchers("/v3/api-docs/**", "/swagger-ui/**")
//                                    .permitAll()
//                                    .requestMatchers("/v3/api-docs/**")
//                                    .permitAll()
//                                    .requestMatchers("/swagger-resources/**")
//                                    .permitAll()
//                                    .anyRequest()
//                                    .authenticated())
//            .oauth2ResourceServer(
//                    oauth2ResourceServer ->
//                            oauth2ResourceServer.opaqueToken(
//                                    opaqueToken ->
//                                            opaqueToken
//                                                    .introspectionUri(this.introspectionUri)
//                                                    .introspectionClientCredentials(this.clientId, this.clientSecret))
//            );
    return httpSecurity.build();
}
}


