package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.mongo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface FormRepository extends MongoRepository<Form, String> {

    List<Form> findFormBySearchKey(@Param("searchKey") String searchKey);

    @Query("{ 'appName' : ?#{ [0] == null ? null : [0] }, 'screen' : ?#{ [1] == null ? null : [1] }, 'section' : ?#{ [2] == null ? null : [2] }, 'uicomponent' : ?#{ [3] == null ? null : [3] }, 'searchKey' : ?#{ [4] == null ? null : [4] } }")
    List<Form> findFormDynamically(String app, String screen, String section, String uiComponent, String searchKey);
}