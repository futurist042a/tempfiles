package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Question {
    private String questionDesc;
    private String answerValue;
}
