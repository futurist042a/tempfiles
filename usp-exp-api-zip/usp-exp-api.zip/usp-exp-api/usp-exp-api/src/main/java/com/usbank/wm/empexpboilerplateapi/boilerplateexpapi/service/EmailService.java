package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BadRequestException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.email.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.List;

@Service
@Slf4j
public class EmailService {
	@Value("${email.hub.api.url}")
	private String baseUrl;

	@Value("${email.hub.api.username}")
	private String username;

	@Value("${email.hub.api.password}")
	private String password;

	@Autowired
	private RemoteService remoteService;

	@Autowired
	PacketGeneratorService packetGeneratorService;

	public void sendPacket(String mergedPdfPacket, String requestPayload) {

		final EmailRequest emailRequest = buildRequest(mergedPdfPacket, requestPayload);
		final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		final String token = getAuthToken();
		headers.add(Constants.HEADER_AUTHORIZATION, "Basic " + token);

		try {
			String requestJsonBody = new ObjectMapper().writeValueAsString(emailRequest);
			log.info("Email RM Remote JSON:: {}", requestJsonBody);
			ObjectMapper mapper = new ObjectMapper();
			String payload = mapper.writeValueAsString(emailRequest);
			log.info("payload ==> " + payload);
			ResponseEntity<String> response = remoteService.execute(baseUrl, HttpMethod.POST, payload, null, headers,
					false);
			log.info("TransactionID for RM : {}",
					JsonParser.parseString(response.getBody()).getAsJsonObject().get("transactionId"));
		} catch (Exception e) {
			log.error("Error in Email RM: {}", e.getMessage(), e);
		}
	}

	private String getAuthToken() {
		final String basicAuth = username + ":" + password;
		return Base64.getEncoder().encodeToString(basicAuth.getBytes());
	}

	private EmailRequest buildRequest(String mergedPdfPacket, String requestPayload) {
		// Email request initialization
		try {
			List<String> allReceipients = new ArrayList<>();
			JsonObject jsonObject = JsonParser.parseString(requestPayload).getAsJsonObject();
			JsonArray receipientEmailArray = jsonObject.get("receipientEmailList").getAsJsonArray();
			JsonArray ccManagerEmailArray = jsonObject.get("ccManagerList").getAsJsonArray();
			List<String> toClientEmailList = new Gson().fromJson(receipientEmailArray, new TypeToken<List<String>>() {
			}.getType());
			
			allReceipients.addAll(toClientEmailList);
			if (!ccManagerEmailArray.isEmpty()) {
				List<String> ccManagerEmailList = new Gson().fromJson(ccManagerEmailArray,
						new TypeToken<List<String>>() {
						}.getType());
				allReceipients.addAll(ccManagerEmailList);
			}
			String companyName = jsonObject.get("companyName").getAsString();
			String emailTemplateID = jsonObject.get("emailTemplateID").getAsString();
			JsonObject userInfo = jsonObject.get("userInfo").getAsJsonObject();

			// Prepare Dynamic Information
			List<DynamicInformation> dynamicInformation = new ArrayList<>();
			addDynamicInformation(dynamicInformation, "CUSTOMER_NAME", companyName);
			addDynamicInformation(dynamicInformation, "CONTACTINFO", userInfo.get("fullname").getAsString());

			final EventMetaData eventMetaData = EventMetaData.builder().eventOperationType("EMAIL").build();
			UserIdentifier userIdentifier = new UserIdentifier();
			userIdentifier.setIdType("lpid");
			userIdentifier.setIdValue("0f8fad5b-d9cb-469f-a165-70867728950e");

			final EmailInformation emailInformation = EmailInformation.builder().toAddress(allReceipients)
					.attachmentInformation(Collections.singletonList(
							AttachmentInformation.builder().attachmentFileName(Constants.ATTACHMENT_FILE_NAME)
									.attachmentType(Constants.ATTACHMENT_TYPE).attachment(mergedPdfPacket).build()))
					.build();

			return EmailRequest.builder().eventName("boilerplate EMAIL NOTIFICATION ALERTS").templateID(emailTemplateID)
					.eventMetaData(eventMetaData).userIdentifier(userIdentifier).emailInformation(emailInformation)
					.dynamicInformation(dynamicInformation).build();
		}
		catch (BadRequestException ex){
			log.error("Few input fields related to email service are missing or given incorrectly :", ex);
			throw new BadRequestException(ex.getMessage());
		}
	}

	private void addDynamicInformation(List<DynamicInformation> dynamicInformations, String name, String value) {
		DynamicInformation dynamicInformation = new DynamicInformation();
		dynamicInformation.setName(name);
		dynamicInformation.setValue(value);
		dynamicInformations.add(dynamicInformation);
	}
}