package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskDetail {
    public String taskId;
    public String taskName;
    public String instanceId;
    public String status;
    public String assignedTo;
    public String modifiedBy;
    public String modifiedDate;
    public String taskURL;
}
