package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class Document {
    private static final long serialVersionUID = -3726574656828110264L;
    private String documentId;
    private String documentArea;
    private String documentClass;
    private String contentElementCount;
    private String filename;
    private String category;
    private String status;
    private String uploadedOn;
    private String uploadedBy;
    private String docTypeId;
    private String source;
    private String pivotVisible;
    private String docTypeVisibility;
    private String userId;
    private String userRole;
    private String executionDate;
    private String partyName;
    private String docType;


}

