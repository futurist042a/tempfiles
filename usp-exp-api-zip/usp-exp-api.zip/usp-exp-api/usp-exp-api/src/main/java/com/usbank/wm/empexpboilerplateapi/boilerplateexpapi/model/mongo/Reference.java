package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.mongo;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;
import org.bson.types.ObjectId;
import lombok.Data;

import java.util.List;

@Document(collection = "USP_REFS")
@Data // Lombok annotation to generate getters, setters, and toString()
public class Reference {
    private ObjectId id;
    private int typeid;
    private String typename;
    private String name;
    private String searchkey;
    private List data;


}
