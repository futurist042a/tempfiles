package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalDetails {

    private String natureOfBusiness;
    private String countryOfFormation;
    private String countryOfPrimaryBusinessOperations;
    private String estimatedOrProjectedAnnualRevenue;
    private String hasAnyDBA;
    private String legalStructure;
    private String naicsCode;
    private String purposeOfAccount;
    private String offerCheckCashingServices;
}
