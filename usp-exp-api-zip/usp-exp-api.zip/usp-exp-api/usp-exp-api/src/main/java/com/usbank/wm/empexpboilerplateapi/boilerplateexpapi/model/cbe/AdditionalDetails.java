package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.cbe;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdditionalDetails {
    String natureOfBusiness;
    String countryOfFormation;
    String countryOfPrimaryBusinessOperations;
    String estimatedOrProjectedAnnualRevenue;
    String hasAnyDBA;
    String legalStructure;
    String naicsCode;
    String purposeOfAccount;
    String offerCheckCashingServices;
}
