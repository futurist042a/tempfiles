package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.config;

import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.config.RequestConfig;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClientBuilder;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.client5.http.impl.io.BasicHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManager;
import org.apache.hc.client5.http.impl.io.PoolingHttpClientConnectionManagerBuilder;
import org.apache.hc.client5.http.io.HttpClientConnectionManager;
import org.apache.hc.client5.http.socket.ConnectionSocketFactory;
import org.apache.hc.client5.http.socket.PlainConnectionSocketFactory;
import org.apache.hc.client5.http.ssl.NoopHostnameVerifier;
import org.apache.hc.client5.http.ssl.SSLConnectionSocketFactory;
import org.apache.hc.core5.http.HttpHost;
import org.apache.hc.core5.http.config.Registry;
import org.apache.hc.core5.http.config.RegistryBuilder;
import org.apache.hc.core5.util.Timeout;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;

@Slf4j
@Configuration
public class AppConfig {

    @Value("${app.proxy.host}")
    private String proxyHost;

    @Value("${app.proxy.port}")
    private Integer proxyPort;

    @Value("${app.restTemplate.connection.timeout}")
    private Integer connectionTimeout;

    @Value("${app.restTemplate.read.timeout}")
    private Integer readTimeout;

    @Value("${app.restTemplate.socket.timeout}")
    private Integer socketTimeout;

    @Value("${mtls.keystore.pwd}")
    private String mtlsKeyStorePassword;

    @Value("${mtls.keystore.type}")
    private String mtlsKeystoreType;

    @Value("${mtls.keystore.path}")
    private String mtlsKeystorePath;

    @Value("${mtls.truststore.path}")
    private String mtlsTruststorePath;

    @Value("${mtls.truststore.type}")
    private String mtlsTruststoreType;

    @Value("${mtls.truststore.pwd}")
    private String mtlsTrustStorePassword;

    @Autowired
    private Environment environment;

    @Autowired
    private ResourceLoader resourceLoader;

    @Bean (name="boilerplateRestTemplate")
    public RestTemplate restTemplate() {
        return new RestTemplate(buildHttpComponentsClientHttpRequestFactory());
    }


    @Bean(name="platformRestTemplate")
    public RestTemplate bpmRestTemplate() {
        return new RestTemplate();
    }

    private HttpComponentsClientHttpRequestFactory
    buildHttpComponentsClientHttpRequestFactory() {
        PoolingHttpClientConnectionManager cm = new
                PoolingHttpClientConnectionManager();
        cm.setMaxTotal(128);
        cm.setDefaultMaxPerRoute(24);

        HttpHost proxy = new HttpHost(proxyHost, proxyPort);

        RequestConfig requestConfig =
                RequestConfig.custom()
                        .setProxy(proxy)
                        .setConnectTimeout(Timeout.ofDays(connectionTimeout))
                        .setConnectionRequestTimeout(Timeout.ofDays(readTimeout))
                        //.setSocketTimeout(socketTimeout)
                        .build();

        CloseableHttpClient closeableHttpClient = HttpClientBuilder.create()
                .setConnectionManager(cm)
                .setDefaultRequestConfig(requestConfig)
                .build();

        return new HttpComponentsClientHttpRequestFactory(closeableHttpClient);
    }

    @Bean(name = "mtlsRestTemplate")
    public RestTemplate mtlsRestTemplate(RestTemplateBuilder builder) {
        try {
            log.info("Initializing mtlsRestTemplate");
            final SSLContext sslContext = getSSLContext();
            final SSLConnectionSocketFactory sslsf =
                    new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

            final Registry<ConnectionSocketFactory> socketFactoryRegistry =
                    RegistryBuilder.<ConnectionSocketFactory> create()
                            .register("https", sslsf)
                            .register("http", new PlainConnectionSocketFactory())
                            .build();

            final BasicHttpClientConnectionManager connectionManager =
                    new BasicHttpClientConnectionManager(socketFactoryRegistry);
            HttpClientConnectionManager poolingConnManager = PoolingHttpClientConnectionManagerBuilder.create().setSSLSocketFactory(sslsf).build();
            CloseableHttpClient client
                    = HttpClients.custom().setConnectionManager(poolingConnManager)
                    .build();
            return builder
                    .requestFactory(() -> new HttpComponentsClientHttpRequestFactory(client))
                    .build();
        } catch (IOException
                | CertificateException
                | NoSuchAlgorithmException
                | KeyStoreException
                | UnrecoverableKeyException
                | KeyManagementException exception) {
            log.error("SSL Context creation issue", exception);
            throw new ServiceException("SSL Context creation issue", exception);
        }
    }

    private SSLContext getSSLContext()
            throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException,
            UnrecoverableKeyException, KeyManagementException {
        final char[] keystorePassword = this.mtlsKeyStorePassword.toCharArray();
        final KeyStore keyStore = KeyStore.getInstance(mtlsKeystoreType);

        String env = environment.getActiveProfiles()[0];

        if ("local".equals(env)) {
            try (InputStream inputStream =
                         resourceLoader.getResource(mtlsKeystorePath).getInputStream()) {
                keyStore.load(inputStream, keystorePassword);
            }
        } else {
            try (FileInputStream inputStream = new FileInputStream(mtlsKeystorePath)) {
                keyStore.load(inputStream, keystorePassword);
            }
        }

        final char[] truststorePassword = this.mtlsTrustStorePassword.toCharArray();
        final KeyStore truststore = KeyStore.getInstance(mtlsTruststoreType);
        if ("local".equals(env)) {
            try (InputStream inputStream =
                         resourceLoader.getResource(mtlsTruststorePath).getInputStream()) {
                truststore.load(inputStream, truststorePassword);
            }
        } else {
            try (FileInputStream inputStream = new FileInputStream(mtlsTruststorePath)) {
                truststore.load(inputStream, truststorePassword);
            }
        }
        final KeyManagerFactory keyManagerFactory =
                KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        keyManagerFactory.init(keyStore, keystorePassword);

        final TrustManagerFactory trustManagerFactory =
                TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init(truststore);

        final SSLContext sslContext = SSLContext.getInstance("TLSv1.2");

        sslContext.init(
                keyManagerFactory.getKeyManagers(),
                trustManagerFactory.getTrustManagers(),
                new SecureRandom());
        return sslContext;
    }
}
