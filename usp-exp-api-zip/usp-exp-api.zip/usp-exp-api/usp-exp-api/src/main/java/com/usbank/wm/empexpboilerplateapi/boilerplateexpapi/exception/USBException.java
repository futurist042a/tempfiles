package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception;

public interface USBException {
	public String getUIMessage();
	
	 public String getErrorType();

}
