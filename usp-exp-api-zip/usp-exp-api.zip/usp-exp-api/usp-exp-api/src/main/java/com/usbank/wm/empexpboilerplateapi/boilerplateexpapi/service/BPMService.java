package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service;

import com.google.gson.*;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.ProcessDetails;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.TaskDetail;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.NonProcessMember;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import java.lang.reflect.Type;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
@Slf4j
public class BPMService {
    Logger logger = LoggerFactory.getLogger(BPMService.class);

    @Autowired
    private RemoteService remoteService;

//    @Value("${bpm.server.base}")
//    private String bpmBaseUrl;

//    @Value("${bpm.rest.getEventActiveTasks}")
//    private String bpmGetEventActiveTasks;

    @Value("${bpm.rest.taskCompleteUrl}")
    private String taskCompleteUrl;

    @Value("${bpm.rest.exposedProcess}")
    private String exposedProcessUrl;

//    @Value("${bpm.rest.processCurrentState}")
//    private String processCurrentStateUrl;

    @Value("${bpm.rest.bulkInstanceDetails}")
    private String bulkInstanceDetailsUrl;

    @Value("${bpm.rest.basic.auth.username}")
    private String bpmRestAPIUserName;

    @Value("${bpm.rest.basic.auth.password}")
    private String bpmRestAPIPassword;

    @Value("${bpm.rest.getRoles}")
    private String bpmGetRolesUrl;

    @Value("${bpm.server.stack.1}")
    private String bpmBaseURLStack1;

    @Value("${bpm.server.stack.2}")
    private String bpmBaseURLStack2;

    @Value("${bpm.server.auth.stack.1}")
    private String bpmAuthStack1;

    @Value("${bpm.server.auth.stack.2}")
    private String bpmAuthStack2;

    public HashMap<String, String> getExposedProcess(String currentUser, String envStack){
        ResponseEntity<String> exposedProcesses;
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("currentUser", currentUser);
        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
        String uriString = bpmBaseUrl + exposedProcessUrl;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();

        try {
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
            log.info(uri.toString());
            exposedProcesses = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
        } catch (HttpStatusCodeException hts) {
            //hts.printStackTrace();;
            logger.error("Error occurred in: getExposedProcess : {} ", hts.getMessage());
            return new HashMap<String, String>();
        }
        return exposedProcessDetails(exposedProcesses);
    }

    public Map<String, List<TaskDetail>> getAllProcessDetails(List<String> processInstanceIds, String currentUser, JsonObject userDetail,HashMap<String, String> exposedProcess, String envStack){
        Map<String, List<TaskDetail>> allProcessDetails = new HashMap<>();
        ResponseEntity<String> processDetails;
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("instanceIds", String.join(",",processInstanceIds));
        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
        String uriString = bpmBaseUrl + bulkInstanceDetailsUrl;
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();

        try {
            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
            log.info(uri.toString());
            processDetails = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
        } catch (HttpStatusCodeException hts) {
            logger.error("Error occurred in: getAllProcessDetails : {} ", hts.getMessage());
            return new HashMap<>();
        }
        return getProcessDetails(processDetails,currentUser,userDetail,exposedProcess,envStack);
    }

    public JsonObject testCloudGetTeamTasks(String envStack) {
        ResponseEntity<String> rolesDetails;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();

        String bpmBaseUrl = "https://cpd-dev.apps.baw5.ba.nonprod.aws.cloud.bank-dns.com/bas";
        String uriString = bpmBaseUrl + "/rest/bpm/wle/v1/service/5d482a97-0790-48f6-9192-015413c71a03?action=start&createTask=false&parts=all";

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
            log.info("testCloudGetTeamTasks > "+uri.toString());
            rolesDetails = restTemplate.exchange(uri, HttpMethod.POST, request, String.class);
            String tempBody = rolesDetails.getBody();
            JsonObject response  = JsonParser.parseString(tempBody).getAsJsonObject();
            return response;
        } catch (HttpStatusCodeException hts) {
            logger.error("testCloudGetTeamTasks() exception : {} ", hts.getResponseHeaders());
            throw hts;
        }
    }

    public JsonObject testCloudGetUserDetails(String currentUser, String envStack) {
        ResponseEntity<String> rolesDetails;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("currentUser", currentUser);
        String bpmBaseUrl = "https://cpd-dev.apps.baw5.ba.nonprod.aws.cloud.bank-dns.com/bas";
        String uriString = bpmBaseUrl + bpmGetRolesUrl;

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
            log.info("testCloudGetUserDetails > "+uri.toString());
            rolesDetails = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
            String tempBody = rolesDetails.getBody();
            JsonObject response  = JsonParser.parseString(tempBody).getAsJsonObject();
            return response;
        } catch (HttpStatusCodeException hts) {
            logger.error("testCloudGetUserDetails() exception : {} ", hts.getResponseHeaders());
            throw hts;
        }
    }

    public JsonObject getUserDetails(String currentUser, String envStack) {
        ResponseEntity<String> rolesDetails;
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders httpHeaders = new HttpHeaders();
        Map<String, String> pathVar = new HashMap<>();
        pathVar.put("currentUser", currentUser);
        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
        String uriString = bpmBaseUrl + bpmGetRolesUrl;

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
        URI uri = builder.buildAndExpand(pathVar).toUri();
        try {
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
            log.info("getUserDetails > "+uri.toString());
            rolesDetails = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
            String tempBody = rolesDetails.getBody();
            JsonObject response  = JsonParser.parseString(tempBody).getAsJsonObject();
            return response;
        } catch (HttpStatusCodeException hts) {
            logger.error("getUserDetails() exception : {} ", hts.getResponseHeaders());
            throw hts;
        }
    }

    private HashMap<String,String> getProcessTaskTeams(JsonArray processTaskItems){
        HashMap<String,String> teamsMap = new HashMap<String,String>();
        for (JsonElement element : processTaskItems) {
            JsonObject taskItem = element.getAsJsonObject();
            if(taskItem.get("serviceType").getAsString().equalsIgnoreCase("COACHFLOW")) {
                if (!taskItem.get("teamDisplayName").isJsonNull()) {
                    teamsMap.put(taskItem.get("teamDisplayName").getAsString(), "");
                }
                if (!taskItem.get("managerTeamDisplayName").isJsonNull()) {
                    teamsMap.put(taskItem.get("managerTeamDisplayName").getAsString(), "");
                }
            }
        }
        return teamsMap;
    }

    private boolean isUserMembershipInProcessTeams(HashMap<String,String> processTeams, List<String> userMembership){
        for(String teamName: userMembership){
            if(processTeams.containsKey(teamName)){
                return true;
            }
        }
        return false;
    }

    private HashMap<String,String> exposedProcessDetails(ResponseEntity<String> exposedProcessStr) {
        logger.info("exposedProcessDetails(): Start");
        String tempBody = exposedProcessStr.getBody();
        JsonObject dataObj = JsonParser.parseString(tempBody).getAsJsonObject().getAsJsonObject("data");
        HashMap<String,String> exposeProcessMap = new HashMap<String,String>();
        try {
            JsonArray items = dataObj.get("exposedItemsList").getAsJsonArray();

            for (JsonElement element : items) {
                JsonObject taskItem = element.getAsJsonObject();
                exposeProcessMap.put(taskItem.get("itemID").getAsString(),taskItem.get("display").getAsString());
            }
        }catch(Exception ex){
            logger.error("Get exposedProcessDetails Error : {} ",ex.getMessage());
        }
        return exposeProcessMap;
    }

    private Map<String, List<TaskDetail>> getProcessDetails(ResponseEntity<String> bulkInstanceDetails, String currentUser, JsonObject userDetail, HashMap<String,String> exposedProcess, String envStack) throws NonProcessMember {
        logger.info("getProcessDetails(): Start");
        Map<String, List<TaskDetail>> processDetails = new HashMap<>();
        String tempBody = bulkInstanceDetails.getBody();
        JsonObject dataObj = null;

        try {
            dataObj = JsonParser.parseString(tempBody).getAsJsonObject().getAsJsonObject("data");
        } catch (JsonSyntaxException e) {
            return processDetails;
        }

        try {
            JsonArray processItems = dataObj.get("processDetails").getAsJsonArray();
            List<String> membership = getMembershipDetails(userDetail);
            //logger.info("membership Teams > "+membership);

            for (JsonElement processInst: processItems) {
                JsonObject processItem = processInst.getAsJsonObject();
                JsonArray items = processItem.get("tasks").getAsJsonArray();
                try {
                    //Get all the teams of the Process Tasks
                    HashMap<String,String> taskTeams = getProcessTaskTeams(items);
                    //logger.info("Task Teams > "+taskTeams);

                    //Check if the current user role is part of anyone of the task team / manager
                    boolean isUserMemberOfProcessTeam = isUserMembershipInProcessTeams(taskTeams,membership);
                    //System.out.println("member? > " + isUserMemberOfProcessTeam);

                    //Check if this process is exposed to the user based on itemId
                    boolean isUserExposedToProcess = exposedProcess.containsKey(processItem.get("processTemplateID").getAsString());
                    //System.out.println("exposedProcess? > " + isUserExposedToProcess);

                    if(isUserMemberOfProcessTeam || isUserExposedToProcess) {
                        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
                        String taskCompleteURI = bpmBaseUrl + taskCompleteUrl;

                        SimpleDateFormat bpmdatefmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'+00:00'");
                        SimpleDateFormat requiredFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

                        List<TaskDetail> taskDetails = new ArrayList<>();
                        for (JsonElement element : items) {
                            JsonObject taskItem = element.getAsJsonObject();
                            //logger.info("TaskItems > "+taskItem);
                            if (taskItem.get("serviceType").getAsString().equalsIgnoreCase("COACHFLOW")) {
                                if (taskItem.get("status").getAsString().equalsIgnoreCase("Received") || (taskItem.get("status").getAsString().equalsIgnoreCase("Closed") && !taskItem.get("closeByUser").isJsonNull())) {
                                    String taskURL = enableTaskURL(taskItem, currentUser, membership) ? taskCompleteURI + taskItem.get("tkiid").getAsString() : "";
                                    taskDetails.add(TaskDetail.builder()
                                        .taskId(taskItem.get("tkiid").getAsString())
                                        .taskName(taskItem.get("name").getAsString())
                                        .status(taskItem.get("status").getAsString())
                                        .assignedTo(taskItem.get("assignedTo").isJsonNull() ? "" : taskItem.get("assignedTo").getAsString())
                                        .modifiedBy(taskItem.get("closeByUser").isJsonNull() ? "" : taskItem.get("closeByUserFullName").getAsString() +"(" + taskItem.get("closeByUser").getAsString() + ")")
                                        .modifiedDate(requiredFmt.format(bpmdatefmt.parse(taskItem.get("dueTime").getAsString())))
                                        .taskURL(taskURL)
                                        .build());
                                }
                            }
                        }
                        processDetails.put(processItem.get("piid").getAsString(),taskDetails);
                    }else{
                        logger.info("User not part of the process (" + processItem.get("piid").getAsString() + "), so will not be displayed in the portal");
                    }
                }catch(Exception ex){
                    logger.error("Get getProcessDetails for each InstanceId Error : {} ",ex.getMessage());
                }
            }
        }catch(Exception ex){
            logger.error("Get getProcessDetails Error : {} ",ex.getMessage());
        }
        return processDetails;
    }

    private boolean enableTaskURL(JsonObject taskDetail, String currentUser, List<String> membership){
        String assignedToType = taskDetail.get("assignedToType").getAsString();
        String assignedToDisplayName = taskDetail.get("assignedToDisplayName").getAsString();
        String assignedTo = taskDetail.get("assignedTo").getAsString();
        boolean result = false;
        if (taskDetail.get("status").getAsString().equalsIgnoreCase("Received")) {
            if (assignedToType.equalsIgnoreCase("user")) {
                result = currentUser.equalsIgnoreCase(assignedTo);
            } else if (assignedToType.equalsIgnoreCase("group")) {
                //result = membership.contains(assignedToDisplayName) ? true : false;
                result= membership.stream().allMatch(s -> s.equals(assignedToDisplayName));
            }
        }
        return result;
    }

    private List<String> getMembershipDetails(JsonObject userDetail){
        String jsonStringArray = userDetail.getAsJsonObject("data").get("memberships").getAsJsonArray().toString();
        Gson converter = new Gson();
        Type type = new TypeToken<List<String>>(){}.getType();
        return converter.fromJson(jsonStringArray, type );
    }

    private String getAuthorizationBasedOnServer(String envStack){
        String bpmAuthConfig = (envStack == "1")? bpmAuthStack1:bpmAuthStack2;
        //log.info("bpmAuthConfig > "+bpmAuthConfig);
        if(bpmAuthConfig.equalsIgnoreCase("BASICAUTH")) {
            log.info("BASICAUTH");
            return AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword);
            //return AppUtil.createBasicAuthorizationToken("BAWawseksAppIDIT", "XPXXUp%B5Zn7NN6r");
        }else{
            //log.info("PINGFED");
            return remoteService.getAuthorization();
        }
    }

//    public  List<TaskDetail> processCurrentState(ResponseEntity<String> processCurrentStateStr, String currentUser, JsonObject userDetail, HashMap<String,String> exposedProcess, String envStack) throws NonProcessMember {
//        logger.info("processCurrentState(): Start");
//        String tempBody = processCurrentStateStr.getBody();
//        JsonObject data = new JsonObject();
//        JsonObject dataObj = null;
//        List<TaskDetail> taskDetails = new ArrayList<>();
//        try {
//            dataObj = JsonParser.parseString(tempBody).getAsJsonObject().getAsJsonObject("data");
//        } catch (JsonSyntaxException e) {
//            return taskDetails;
//        }
//
//        boolean isUserMemberOfProcess = true;
//
//        //if(dataObj.get("executionState").getAsString() != "Failed"){
//        try {
//            JsonArray items = dataObj.get("tasks").getAsJsonArray();
//            List<String> membership = getMembershipDetails(userDetail);
//            //logger.info("membership Teams > "+membership);
//
//            //Get all the teams of the Process Tasks
//            HashMap<String,String> taskTeams = getProcessTaskTeams(items);
//            //logger.info("Task Teams > "+taskTeams);
//
//            //Check if the current user role is part of anyone of the task team / manager
//            boolean isUserMemberOfProcessTeam = isUserMembershipInProcessTeams(taskTeams,membership);
////                System.out.println("member? > " + isUserMemberOfProcessTeam);
//
//            //Check if this process is exposed to the user based on itemId
//            boolean isUserExposedToProcess = exposedProcess.containsKey(dataObj.get("processTemplateID").getAsString());
////                System.out.println("exposedProcess? > " + isUserExposedToProcess);
//
//            if(isUserMemberOfProcessTeam || isUserExposedToProcess) {
//                String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
//                String taskCompleteURI = bpmBaseUrl + taskCompleteUrl;
//
//                SimpleDateFormat bpmdatefmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'+00:00'");
//                SimpleDateFormat requiredFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//
//                for (JsonElement element : items) {
//                    JsonObject taskItem = element.getAsJsonObject();
//                    //logger.info("TaskItems > "+taskItem);
//                    if (taskItem.get("serviceType").getAsString().equalsIgnoreCase("COACHFLOW")) {
//                        if (taskItem.get("status").getAsString().equalsIgnoreCase("Received") || (taskItem.get("status").getAsString().equalsIgnoreCase("Closed") && !taskItem.get("closeByUser").isJsonNull())) {
//
//                            String taskURL = enableTaskURL(taskItem, currentUser, membership) ? taskCompleteURI + taskItem.get("tkiid").getAsString() : "";
//                            taskDetails.add(
//                                    TaskDetail.builder()
//                                            .taskId(taskItem.get("tkiid").getAsString())
//                                            .taskName(taskItem.get("name").getAsString())
//                                            .status(taskItem.get("status").getAsString())
//                                            .assignedTo(taskItem.get("assignedTo").isJsonNull() ? "" : taskItem.get("assignedTo").getAsString())
//                                            .modifiedBy(taskItem.get("closeByUser").isJsonNull() ? "" : taskItem.get("closeByUserFullName").getAsString() +"(" + taskItem.get("closeByUser").getAsString() + ")")
//                                            .modifiedDate(requiredFmt.format(bpmdatefmt.parse(taskItem.get("dueTime").getAsString())))
//                                            .taskURL(taskURL)
//                                            .build());
//                        }
//                    }
//                }
//            }else{
//                isUserMemberOfProcess = false;
//            }
//        }catch(Exception ex){
//            logger.error("Get processCurrentState Error : {} ",ex.getMessage());
//        }
//        if(!isUserMemberOfProcess) {
//            throw new NonProcessMember("User not a member of the process");
//        }
//        return taskDetails;
//    }

//    public  List<TaskDetail> processTaskDetails(ResponseEntity<String> taskDetailsStr, String currentUser, JsonObject userDetail, String envStack) {
//        logger.info("processTaskDetails(): Start");
//        String tempBody = taskDetailsStr.getBody();
//        JsonObject data = new JsonObject();
//        JsonObject dataObj = JsonParser.parseString(tempBody).getAsJsonObject().getAsJsonObject("data");
//        List<TaskDetail> taskDetails = new ArrayList<>();
//        try {
//            JsonArray items = dataObj.get("tasks").getAsJsonArray();
//            String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
//            String taskCompleteURI = bpmBaseUrl+taskCompleteUrl;
//
//            SimpleDateFormat bpmdatefmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'+00:00'");
//            SimpleDateFormat requiredFmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
//
//            for (JsonElement element : items) {
//                JsonObject taskItem = element.getAsJsonObject();
//                //logger.info("TaskItems > "+taskItem);
//                if (taskItem.get("status").getAsString().equalsIgnoreCase("Received") || (taskItem.get("status").getAsString().equalsIgnoreCase( "Closed") && !taskItem.get("closeByUser").isJsonNull())) {
//                    List<String> membership = getMembershipDetails(userDetail);
//                    String taskURL = enableTaskURL(taskItem, currentUser, membership) ? taskCompleteURI + taskItem.get("tkiid").getAsString() : "";
//                    taskDetails.add(
//                            TaskDetail.builder()
//                                    .taskId(taskItem.get("tkiid").getAsString())
//                                    .taskName(taskItem.get("name").getAsString())
//                                    .status(taskItem.get("status").getAsString())
//                                    .assignedTo(taskItem.get("assignedTo").isJsonNull()? "" : taskItem.get("assignedTo").getAsString())
//                                    .modifiedBy(taskItem.get("closeByUser").isJsonNull()? "" : taskItem.get("closeByUser").getAsString())
//                                    .modifiedDate(requiredFmt.format(bpmdatefmt.parse(taskItem.get("dueTime").getAsString())))
//                                    .taskURL(taskURL)
//                                    .build());
//                }
//            }
//        }catch(Exception ex){
//            logger.error("Get ProcessTaskDetails Error : {} ",ex.getMessage());
//        }
//
//        return taskDetails;
//    }

//    public List<TaskDetail> getInstanceAllTasks(String bpmInstanceId, String currentUser, JsonObject userDetail,HashMap<String, String> exposedProcess, String envStack)  throws NonProcessMember {
//        ResponseEntity<String> taskDetails;
//        RestTemplate restTemplate = new RestTemplate();
//
//        HttpHeaders httpHeaders = new HttpHeaders();
//        Map<String, String> pathVar = new HashMap<>();
//        pathVar.put("instanceId", bpmInstanceId);
//        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
//        String uriString = bpmBaseUrl + processCurrentStateUrl;
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
//        URI uri = builder.buildAndExpand(pathVar).toUri();
//
//        try {
//            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
//            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
//            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
//            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
//            log.info(uri.toString());
//            taskDetails = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
//        } catch (HttpStatusCodeException hts) {
//            //hts.printStackTrace();;
//            logger.error("Error occurred in: getInstanceAllTasks : {} ", hts.getMessage());
//            return new ArrayList<TaskDetail>();
//            //throw hts;
//        }
//
//        return processCurrentState(taskDetails, currentUser, userDetail, exposedProcess,envStack);
//    }

//    public List<TaskDetail> getInstanceActiveTasks(String bpmInstanceId, String currentUser, JsonObject userDetail, String envStack) {
//        ResponseEntity<String> taskDetails;
//        RestTemplate restTemplate = new RestTemplate();
//
//        HttpHeaders httpHeaders = new HttpHeaders();
//        Map<String, String> pathVar = new HashMap<>();
//        pathVar.put("instanceId", bpmInstanceId);
//        String bpmBaseUrl = (envStack == "1")? bpmBaseURLStack1:bpmBaseURLStack2;
//        String uriString = bpmBaseUrl + bpmGetEventActiveTasks;
//        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(uriString);
//        URI uri = builder.buildAndExpand(pathVar).toUri();
//
//        try {
//            //httpHeaders.add(HttpHeaders.AUTHORIZATION, AppUtil.createBasicAuthorizationToken(bpmRestAPIUserName, bpmRestAPIPassword));
//            //httpHeaders.add(HttpHeaders.AUTHORIZATION, remoteService.getAuthorization());
//            httpHeaders.add(HttpHeaders.AUTHORIZATION, getAuthorizationBasedOnServer(envStack));
//            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<String> request = new HttpEntity<>(httpHeaders);
//            log.info(uri.toString());
//            taskDetails = restTemplate.exchange(uri, HttpMethod.GET, request, String.class);
//        } catch (HttpStatusCodeException hts) {
//            //hts.printStackTrace();;
//            logger.error("Error occurred in: getInstanceActiveTasks : {} ", hts.getMessage());
//            return new ArrayList<TaskDetail>();
//            //throw hts;
//        }
//
//        return processTaskDetails(taskDetails, currentUser, userDetail,envStack);
//    }
 }