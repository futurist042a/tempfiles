package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class OnboardingEvent {
    private long id;
    private String onboardingName;
    private String businessLine;
    private String status;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private String isActive;
    @JsonProperty("onboardingTeam-role1")
    private String marketer;
    @JsonProperty("onboardingTeam-role2")
    private String negotiator;
    @JsonProperty("onboardingTeam-relationshipManager")
    private String relationShipManager;
    @JsonProperty("clientDetails-EIN")
    private String taxId;
    private String drfWorkflowId;
    @JsonProperty("clientDetails-legalName")
    private String clientLegalName;
    @JsonProperty("clientDetails-additionalDetails-newClient")
    private String newClient;
    @JsonProperty("productDetails-productType")
    private String product;
}