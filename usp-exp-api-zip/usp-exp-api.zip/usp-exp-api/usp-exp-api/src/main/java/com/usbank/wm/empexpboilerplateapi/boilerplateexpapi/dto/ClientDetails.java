package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClientDetails {
    private String onboardingId;
    private String legalName;
    private String businessLine;
    private String EIN;
    private String LEI;
    private String LPID;
    private Address address;
    private ContactDetails contactDetails;
    private List<DBA> dbaList;
    private AdditionalDetails additionalDetails;

}
