package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.mongo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

public interface ReferenceRepository extends MongoRepository<Reference, String>{

    // @Query(value="{typeid:?0}", fields="{'typeid' : 1, 'searchkey' : 1, 'name':1, 'typename': 1 }")

    @Query(value="{typeid:?0}")
    List<Reference> findAll(int typeid);
}