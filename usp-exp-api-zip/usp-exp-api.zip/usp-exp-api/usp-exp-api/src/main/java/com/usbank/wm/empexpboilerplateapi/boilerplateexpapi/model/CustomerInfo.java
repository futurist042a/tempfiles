package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInfo extends BaseModel {

   private static final long serialVersionUID = 1L;
   private String entityName;
   private String entitytin;
   private String taxIdType;
   private String source;
   private String customerType;
   private String lastUpdatedDate;
    private String webKYCID;

    @Override
    public String toString() {
        return "CustomerInfo (entityName=" + entityName + ", entitytin=" + entitytin + ", taxIdType="
                + taxIdType + ", source=" + source + ", customerType=" + customerType
                + ", lastUpdatedDate=" + lastUpdatedDate + ", webKYCID=" + webKYCID+ ")";
    }
}







