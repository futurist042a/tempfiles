package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util;

import com.google.gson.Gson;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.dto.CommonOnBoardingEvent;
import org.springframework.util.ObjectUtils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JSONUtil {

    private static Map<String, String> datapointMap;

    public static void main(String[] args) throws Exception {
        String commmoneventjson = "{ \"iTest\": 123, \"test\": \"Test Value\", \"clientDetails\": { \"dbaList\": [{\"dbaName\":\"ABC Entity\",\"address\":{\"addressLine1\":\"41 Sunflower Lane\",\"city\":\"Newark\",\"state\":\"NJ\",\"country\":\"US\",\"postalCode\":\"02001\",\"addressLine2\":\"\"}},{\"dbaName\": \"dba2\"}],\"legalName\": \"CCB Four\", \"EIN\": \"EIN Value\", \"LEI\": \"LEI Value\", \"LPID\": \"LPID Value\", \"contactDetails\": { \"businessPhoneNumber\": \"2132156543\", \"email\": \"test@mailtest.com\" } }, \"productDetails\": { \"productName\": \"CCBLW\", \"productType\": \"Onboarding\", \"productFamily\": \"Corporate and Commercial Banking\" } }";
        Gson gson = new Gson();
        CommonOnBoardingEvent commmoneventObj= gson.fromJson(commmoneventjson, CommonOnBoardingEvent.class);
        System.out.println("Object from JSON > "+commmoneventObj);
        convertEventObjecttoDatapointJsonAray(commmoneventObj);
    }

    public static void convertEventObjecttoDatapointJsonAray(CommonOnBoardingEvent eventObject) throws Exception{

        datapointMap  = new HashMap<>();

        // Get the all field objects of CommonOnBoardingEvent class
        Field[] fields = eventObject.getClass().getDeclaredFields();

        for(Field field: fields){
            field.setAccessible(true);
            Object value = field.get(eventObject);
            if(!ObjectUtils.isEmpty(value)) {
                if (!field.getType().isPrimitive() && !isPrimitiveObject(value)) {
                    retrieveObjectFieldNameAndValue(value, field.getName());
                } else {
                    datapointMap.put(field.getName(),value.toString());
                    //System.out.println("Value of Field " + field.getName() + " is " + value + " , type: " + isPrimitiveObject(value));
                }
            }
        }

        System.out.println(datapointMap);
    }

    public static void retrieveObjectFieldNameAndValue(Object object, String fieldPrefix) throws Exception{

        // Get the all field objects of CommonOnBoardingEvent class
        Field[] fields = object.getClass().getDeclaredFields();

        for(Field field: fields){
            field.setAccessible(true);
            Object value = field.get(object);
            if(!ObjectUtils.isEmpty(value)) {
                System.out.println(field.getType());
                if (List.class.isAssignableFrom(field.getType())) {
                    System.out.println("retrieveObjectFieldNameAndValue : Field is a List : "+value);
                    datapointMap.put(fieldPrefix+"-"+field.getName(), "{\"value\":"+value+"}");
                }else if (!field.getType().isPrimitive() && !isPrimitiveObject(value)) {
                    retrieveObjectFieldNameAndValue(value, fieldPrefix+"-"+field.getName());
                } else {
                    datapointMap.put(fieldPrefix+"-"+field.getName(),value.toString());
                    System.out.println("retrieveObjectFieldNameAndValue : Value of Field " + field.getName() + " is " + value + " , type: " + isPrimitiveObject(value));
                }
            }
        }
    }

    private static boolean isPrimitiveObject(Object obj){
        if (obj instanceof String || obj instanceof Integer || obj instanceof Double || obj instanceof Short
                || obj instanceof Boolean || obj instanceof  Float || obj instanceof Character || obj instanceof Byte
        ){
            return true;
        }else{
            return false;
        }
    }

}
