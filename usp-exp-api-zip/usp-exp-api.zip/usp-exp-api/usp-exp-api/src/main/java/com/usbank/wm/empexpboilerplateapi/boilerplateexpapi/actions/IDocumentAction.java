package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.actions;

import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.Document;

import java.util.List;

public interface IDocumentAction {
    List<Document> searchDocuments(String onboardingId, String onboardingType, String accountNumber);
}

