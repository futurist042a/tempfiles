package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;


import com.google.gson.JsonObject;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.model.PickList;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.BoilerplateService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.FormService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.SmartFormService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@Slf4j
public class FormController {

    private BoilerplateService boilerplateService;

    @Autowired
    private FormService formService;

    @Autowired
    private SmartFormService smartFormService;

    Logger logger = LoggerFactory.getLogger(FormController.class);

    @Autowired
    public FormController(BoilerplateService boilerplateService) {
        this.boilerplateService = boilerplateService;
    }

    @GetMapping(value = "/v1/forms/formdata", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getFormData(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestParam(value = Constants.BUSINESS_LINE, required = true) String businessLine,
            @RequestParam(value = Constants.FORM_NAME, required = true) String formName,
            @RequestParam(value = Constants.TAB_NAME, required = true) String tabName,
            @RequestParam(value = Constants.ONBOARDING_ID, required = false) Long onboardingId,
            @RequestParam(value = Constants.IS_READ_ONLY, required = false) Boolean isReadOnly) {
        logger.info("In getForm, businessLine :: " + businessLine + ", formName :: " + formName + ", onboardingId :: " + onboardingId);
        ResponseEntity<String> response = null;
        try {
            response = formService.getForms(businessLine, formName, tabName, onboardingId, isReadOnly);
        } catch (Exception e) {
            logger.info("Exception in getting" + formName + " for businessLine :: " + businessLine + e);
        }

        return response;
    }

    @PostMapping(value = "/v1/forms/{formName}/tabs/{tabName}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveFormTabData(
            @RequestHeader(value = Constants.HEADER_ONBOARDING_ID) Long onboardingId,
            @RequestHeader(value = Constants.HEADER_ACCOUNT_ID, required = false) String accountId,
            @RequestParam(value = Constants.CHECKLIST_ID, required = false) String checklistId,
            @RequestParam(value = Constants.FUND_ID, required = false) String fundId,
            @RequestParam(value = Constants.ADVISOR_ID, required = false) String advisorId,
            @RequestParam(value = Constants.CLASS_ID, required = false) String classId,
            @PathVariable String formName,
            @PathVariable String tabName,
            @RequestParam(value = Constants.BUSINESS_LINE, required = false) String businessLine,
            @RequestBody Map<String, Object> requestBody) {
        log.info("Inside FormController class in saveFormTabData() method():- /v1/forms/{formName}/tabs/{tabName}");
        smartFormService.saveFormTabData(onboardingId, formName, tabName, requestBody, accountId, checklistId, fundId,
                advisorId, classId, businessLine);
        return new ResponseEntity<>(Constants.SUCCESS, HttpStatus.CREATED);

    }

    @GetMapping(value = "/v1/forms/{formName}/tabs/{tabName}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getFormTabData(
            @RequestHeader(value = Constants.HEADER_ONBOARDING_ID) Long onboardingId,
            @RequestHeader(value = Constants.HEADER_ACCOUNT_ID) String accountId,
            @RequestParam(value = Constants.CHECKLIST_ID, required = false) String checklistId,
            @RequestParam(value = Constants.FUND_ID, required = false) String fundId,
            @RequestParam(value = Constants.ADVISOR_ID, required = false) String advisorId,
            @RequestParam(value = Constants.CLASS_ID, required = false) String classId,
            @PathVariable(name = "formName") String formName,
            @PathVariable(name = "tabName") String tabName,
            @RequestParam(value = Constants.BUSINESS_LINE, required = false) String businessLine) {
        log.info("Inside FormController class in getFormTabData() method():- /v1/forms/{formName}/tabs/{tabName}");
        JsonObject smartFormData = smartFormService.getFormTabData(onboardingId, accountId, formName, tabName,
                checklistId, businessLine, fundId, advisorId, classId);
        return new ResponseEntity<>(smartFormData.toString(), HttpStatus.OK);
    }

    @GetMapping(value = "/v1/forms/{formName}/tabs", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getFormData(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestParam(value = Constants.BUSINESS_LINES) String businessLine,
            @PathVariable(value = Constants.FORM_NAME) String formName,
            @RequestParam(value = Constants.TAB_NAME, required = false) String tabName) {
        log.info("Inside FormController class in getFormData() method:- /v1/forms/{formName}/tabs");
        ResponseEntity<Object> response;
        response = smartFormService.getTabs(formName, tabName, businessLine);
        if (response == null) {
            return new ResponseEntity<>("", HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
    }

    @GetMapping(value = "/v2/forms/formdata", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getForm( @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
                                           @RequestParam(value = Constants.FORM_NAME, required = false) String formName,
                                           @RequestParam(value = Constants.TAB_NAME, required = false) String tabName,
                                           @RequestParam(value = Constants.BUSINESS_LINE, required = false) String businessLine,
                                           @RequestParam(value = Constants.FORM_TYPE, required = false) String formType,
                                           @RequestParam(value = Constants.IS_ACTIVE, required = false, defaultValue = "true") Boolean isActive) {
        log.info("In getForm , formName :: " + formName + " ," + "tabName:: " + tabName
                + "businessLine :: " + businessLine + ", formType :: " + formType + ", isActive :: " + isActive);
        ResponseEntity<Object> response;

        response = smartFormService.getForm(formName, tabName, businessLine, formType, isActive);
        if (response == null) {
            return new ResponseEntity<>("", HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(response.getBody(), HttpStatus.OK);
    }

    @GetMapping(value = "/v1/country-list", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getCountryList( @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization) {
        List<PickList> countryList = formService.getCountryList();
        return new ResponseEntity<>(countryList, HttpStatus.OK);

    }

    @GetMapping(value = "/v1/state-list", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> getStateList( @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization) {
        List<PickList> countryList = formService.getStateList();
        return new ResponseEntity<>(countryList, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/datapoint/checklist", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> saveChecklistAndAuditTrail(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
            @RequestHeader(value = Constants.HEADER_ONBOARDING_ID) Long onboardingId,
            @RequestParam(value = Constants.FUND_ID, required = false) String fundId,
            @RequestParam(value = Constants.ADVISOR_ID, required = false) String advisorId,
            @RequestParam(value = Constants.CLASS_ID, required = false) String classId,
            @RequestParam(value = Constants.IS_SUBMIT, required = false) boolean isSubmit,
            @RequestParam(value = Constants.BUSINESS_LINES, required = false) String businessLine,
            @RequestParam(value = Constants.CHECKLIST_ID, required = false) String checklistId,
            @RequestBody Map<String, Object> requestBody) {
        log.info(Constants.USB_UO_LOG + "saveChecklistAndAuditTrail : onboardingId : " + onboardingId);
        log.debug(Constants.USB_UO_LOG + Constants.USB_UO_LOG + "saveChecklistAndAuditTrail : advisorId : " + advisorId
                + ", " + "fundId  : " + fundId + ", " + "classId: : " + classId + ", " + "isSubmit : " + isSubmit);
        smartFormService.saveChecklistAndAuditTrail(onboardingId, requestBody, fundId, advisorId, classId,
                isSubmit,businessLine,checklistId);
        String currentUser = "demo";
        Optional<String> user = AppUtil.getCurrentUser();
        if (user.isPresent()) {
            currentUser = user.get();
        }
        //smartFormService.completeCamundaTask(onboardingId, checklistId, currentUser);
        return new ResponseEntity<>(Constants.SUCCESS, HttpStatus.CREATED);
    }
}
