package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.exception.BadRequestException;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.BoilerplateService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.FormService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.MilestoneService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.SmartFormService;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.util.AppUtil;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@Slf4j
public class OnboardingController {

    private BoilerplateService boilerplateService;

    @Autowired
    private FormService formService;

    @Autowired
    private MilestoneService milestoneService;

    @Autowired
    private SmartFormService smartFormService;
    Logger logger = LoggerFactory.getLogger(OnboardingController.class);

    @Autowired
    public OnboardingController(BoilerplateService boilerplateService) {
        this.boilerplateService = boilerplateService;
    }

    @PostMapping(value = "/v1/process-onboarding", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> saveFormData(
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization, @RequestBody String formBody,
            @RequestParam(value = Constants.BUSINESS_LINE, required = false) String businessLine,
            @RequestParam(value = Constants.FORM_NAME, required = false) String formName,
            @RequestParam(value = Constants.FORM_ACTION, required = false) String formAction,
            @RequestParam(value = Constants.ONBOARDING_ID, required = true) String onboardingId) {
        String response = null;
        String currentUser = null;
        Optional<String> user = AppUtil.getCurrentUser();
        ResponseEntity<String> responseEntity = new ResponseEntity<>("Payload Error.", HttpStatus.BAD_REQUEST);
        if (user.isPresent() && (formAction.equalsIgnoreCase( "save") || validatePayload(formBody))) {
            currentUser = user.get();
            response = boilerplateService.saveForm(authorization, businessLine, formName, formAction, formBody,
                    currentUser, onboardingId);

            JsonObject json = JsonParser.parseString(response).getAsJsonObject();
            String value1 = json.get("onboardingId").getAsString();
            boilerplateService.saveDataPoint(authorization, value1, formBody);
            if ("submit".equalsIgnoreCase(formAction)) {
                boilerplateService.generatePacketAndEmailTrigger(formBody);
            }

            log.info("boilerplate-exp-api -> event-service: response{} : ", response);
            responseEntity = new ResponseEntity<>(response != null ? response : "", HttpStatus.OK);
        }

        return responseEntity;
    }

    public Boolean validatePayload(String payload) {
        Boolean flag = false;
        JsonObject jsonObject = JsonParser.parseString(payload).getAsJsonObject();

        JsonArray receipientEmailArray = jsonObject.get("receipientEmailList").getAsJsonArray();
        JsonArray formIdentifiers = jsonObject.get("formIdentifiers").getAsJsonArray();
        String emailTemplateID = jsonObject.get("emailTemplateID").getAsString();
        if (!receipientEmailArray.isEmpty() &&
                !formIdentifiers.isEmpty() &&
                emailTemplateID != null) {
            flag = true;

        }
        return flag;
    }

    @PostMapping(value = "/v1/initiateOnboarding", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> initiateOnboarding(@RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
                                                     @RequestParam(value = Constants.BUSINESS_LINE) String businessLine,
                                                     @RequestParam(value = Constants.FORM_NAME, required = false) String formName) {
        log.info("Start Onboarding DPG " + "businessLine :: {} formName :: {}", businessLine, formName);
        JsonObject response = null;
        String expmsg;
        try {
            if (!org.springframework.util.StringUtils.hasLength(businessLine)) {
                throw new BadRequestException("businessLine is required.");
            }
            Optional<String> user = AppUtil.getCurrentUser();
            if (user.isPresent()) {
                String currentUser = user.get();
                response = formService.initiateOnboarding(businessLine, formName,currentUser);
            }
            return new ResponseEntity<>(response != null ? response.toString() : "", HttpStatus.OK);
        } catch (Exception e) {
            expmsg = "Exception in Dpgcontroller in initiateOnboarding method : " + ", Business line: " + businessLine + ", FormName: " + formName + ", " + e.getMessage();
            log.error(expmsg);
        }
        return new ResponseEntity<>(expmsg, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/v1/commonOnBoardingEvent", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getCommonOnBoardingEvent(@RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization,
                                                           @RequestBody String formBody) {
        log.info("Start commonOnBoardingEvent");
        String response = null;
        String expmsg;
        try {
            response = boilerplateService.getCommonOnBoardingEvent(authorization,formBody);
            return new ResponseEntity<>(response != null ? response.toString() : "", HttpStatus.OK);
        } catch (Exception e) {
            expmsg = "Exception in Onboarding Controller in getCommonOnBoardingEvent method " + e.getMessage();
            log.error(expmsg);
        }
        return new ResponseEntity<>(expmsg, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @PostMapping(value = "/v1/milestones", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> saveAllMilestone(
            @RequestParam(value = Constants.ONBOARDING_ID, required = true) String onboardingId,
            @RequestParam(value = Constants.BUSINESS_LINE, required = true) String businessLine) {
        log.info("Milestone creation started for onboarding {}", onboardingId);
        ResponseEntity<String> response = milestoneService.insertAllMilestone(onboardingId, businessLine);
        log.info("Milestone creation ended for onboarding {}", onboardingId);
        return response;
    }

    @PutMapping(value = "/v1/milestone", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> updateMilestone(
            @RequestParam(value = Constants.INSTANCE_ID, required = false) String instanceId,
            @RequestParam(value = Constants.ONBOARDING_ID, required = false) String onboardingId,
            @RequestParam(value = Constants.STATUS, required = false) String status,
            @RequestHeader(value = Constants.HEADER_AUTHORIZATION) String authorization) {
        log.info("Milestone update started for onboarding");
        ResponseEntity<String> response = milestoneService.updateMilestoneStatus(instanceId, onboardingId, status);
        log.info("Milestone update ended for onboarding");
        return response;
    }


}
