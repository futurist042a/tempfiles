package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication


public class BoilerplateExpApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(BoilerplateExpApiApplication.class, args);
    }

}
