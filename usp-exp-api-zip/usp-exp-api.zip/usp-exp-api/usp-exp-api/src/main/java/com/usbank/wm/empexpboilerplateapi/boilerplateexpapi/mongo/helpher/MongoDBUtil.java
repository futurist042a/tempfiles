package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.mongo.helpher;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
public class MongoDBUtil {
    public static ArrayList<String> getDocumentJSON(List<Document> documents) {
        ArrayList<String> result = new ArrayList<String>();
        String json = "";
        for (Document response : documents) {
            json = new Gson().toJson(getDocumentJSON(response));
            result.add(updateBAWAttributeSyntax(json));
        }
        return result;
    }

    public static JsonObject getDocumentJSON(Document document){
        JsonObject obj = new JsonObject();
        if(document != null) {
            for(String key: document.keySet()) {
                Object val = document.get(key);
                if(val != null) {
                    if(val instanceof ArrayList) {
                        ArrayList<?> arrayList = (ArrayList<?>) val;
                        if (!arrayList.isEmpty() && arrayList.get(0) instanceof String) {
//                            System.out.println("Object is an ArrayList of Strings");
                            JsonArray jsonArray = new Gson().toJsonTree(arrayList).getAsJsonArray();
                            obj.add(key,jsonArray);
                        } else {
//                            System.out.println("Object is an ArrayList, but not of Strings");
                            List<Document> documents = (List<Document>)val;
                            JsonArray jobj = new JsonArray();
                            ArrayList<String> documentsJSON = new ArrayList<String>();
                            for (Document doc : documents) {
                                jobj.add(getDocumentJSON(doc));
                            }
                            obj.add(key, jobj);
                        }
                    }else if(val instanceof ObjectId) {
                        ObjectId objectId = document.getObjectId(key);
                        String _id = objectId.toString();
                        obj.addProperty(key, _id);
                    }else if(val instanceof Document) {
                        JsonObject anyObj = getDocumentJSON((Document)val);
                        //System.out.println(key + ": "+anyObj);
                        obj.add(key, anyObj);
                    }else if(val instanceof Date) {
                        Date dateVal = document.getDate(key);
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX");
                        obj.addProperty(key, sdf.format(dateVal));
                    }else {
                        String tempVal = val + "";
                        if (tempVal.length() > 0 && tempVal.charAt(0) == '[' && tempVal.charAt(tempVal.length() - 1) == ']') {
                            obj.addProperty(key, tempVal);
                        }else if(val instanceof Number){
                            obj.addProperty(key, (Number)val);
                        }else if(val instanceof Boolean){
                            obj.addProperty(key, (Boolean)val);
                        }else {
                            //if(!tempVal.isEmpty()) {
                                obj.addProperty(key, tempVal);
                            //}
                        }
                    }
                }else {
                    //System.out.println(key +" : is null");
                }
            }
        }
        //System.out.println("Returning JSONObject ...");
        return obj;
    }
    public static Document verifyDocument(String documentJSON) {
        Document doc = Document.parse(documentJSON);
        JsonObject validateJSON = getDocumentJSON(doc);
        Document responseDoc = Document.parse(validateJSON.toString());
        return responseDoc;
    }
    public static int getDocumentSize(String documentJSON) {
        int bytes = documentJSON.getBytes().length;
        int docSizeInKB = bytes / 1024;
        return docSizeInKB;
    }
    public static String getDocumentJSONStr(List<Document> documents) {
        String jsonResponse = "[";
        String json = "";
        int count = 0;
        for (Document response : documents) {
            //System.out.println(count);
            json = new Gson().toJson(getDocumentJSON(response));
            json = updateBAWAttributeSyntax(json);
            if(count == 0 ) {
                jsonResponse = jsonResponse + json;
            }else {
                jsonResponse = jsonResponse + "," +json;
            }
            count++;
        }
        jsonResponse = jsonResponse + "]";
        //System.out.println("Returning Array List of JSON ...");
        return jsonResponse;
    }
    public static String updateBAWAttributeSyntax(String jsonResponse) {
        return jsonResponse.replace("$date", "date").replace("$oid", "oid");
    }

    public static String getDocumentJSONStr(Document document) {
        String json = "";
        json = new Gson().toJson(getDocumentJSON(document));
        json = updateBAWAttributeSyntax(json);

        return json;
    }
}
