package com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.gson.JsonObject;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.constants.Constants;
import com.usbank.wm.empexpboilerplateapi.boilerplateexpapi.service.USPService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
public class USPController {

    @Autowired
    USPService uspService;

    @PostMapping(value = "/v1/usp/formdata", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String,Object>> executeFormDataRequest(
            @RequestHeader(value = Constants.HEADER_TRANSACTION_ID, required = false) String transactionId,
            @RequestParam(value = Constants.SCREEN_SEARCH, required = false) String screenSearch,
            @RequestParam(value = Constants.IS_SAVE, required = false, defaultValue = "false") Boolean isSave,
            @RequestBody Map<String, Object> requestBody) {

        log.info("Inside USPController class in executeFormDataRequest method():- /v1/usp/formdata");
        Map<String, Object> response = new HashMap<>();
        response = uspService.executeFormDataRequest(transactionId, screenSearch, isSave, requestBody);
        if (response == null) {
            return new ResponseEntity<>(new HashMap<>(), HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/v1/appbuilder/createApp", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Object> createApplication(
            @RequestBody Map<String, Object> requestBody) {

        log.info("Inside USPController class in createApplication method():- /v1/appbuilder/createApp");
        JsonObject response = uspService.createApplication(requestBody);
        if (response == null) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(response,HttpStatus.OK);
    }

    @PostMapping(value = "/v1/appbuilder/TestService", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String,Object>> testService(
            @RequestBody Map<String, Object> requestBody) {

        log.info("Inside USPController class in testService method():- /v1/appbuilder/TestService", requestBody);
        return new ResponseEntity<>(requestBody,HttpStatus.OK);
    }
}
