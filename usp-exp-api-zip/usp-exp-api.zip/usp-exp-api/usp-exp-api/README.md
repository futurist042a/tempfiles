# uo-boilerplate-exp-api

This is the boiler plate code of API's which are used in UO 

In this service  we have created  all  common api's which are used in all existing Business lines.

If any new businessLine  is coming just clone this from repo and replace boilarPlate word to specific businessline name.

Below are the common api's for DASHBOARD.

1. **v1/userDetails - GET**
 
    * This api will  fetch the details from the camunda/BPM for the provided userID.
    * Internally it will call camunda api
  
    **Camunda URL:**
    https://dev01-onboarding-camunda.us.bank-dns.com/services/common/core/api/v1/auth/users/groups

2. **v1/metadata - GET**

    * Before calling this api we have to create some records in refs table(typeId =27).

    * This api will use for to fetch records from refs table for table headers.

    * This api not only use for dashboard headers, and also we can use it for all table headers where it is required.
    
    * Internally it will call event service platform  api through rest call.
    
    **Platform service (Event)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/event-service/swagger-ui/index.html#/Onboarding/getTableMetadata

3. **events GraphQL - POST**

    events(onboardingType:String, userRole:String, taskType:String):[Events]
    
    events(onboardingType: "boilarPlate", userRole: "boilarplaterepresentative", taskType: "My_Tasks")
    
    * This api will fetch the dashboard records which are available in uo-datapoints table based on onboardingId.
   
    * Internally it will call  two platform api's(form and event) through rest call.
    
    **Platform service (form and event)  Swagger URL:**
   1. https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/form-service/swagger-ui/index.html#/Refs/getRefsByTypeId
   2. https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/event-service/swagger-ui/index.html#/OnboardingController/fetchOnboardingEvents 
     
4. **eventtasks GraphQL - POST**

   eventtasks(onboardingType:String, onboardingId:String):[EventTasks]

   * This api will fetch the tasks tab records by calling task service as per the onboardingId and
     fetch records from uo_checklist table.

   * Internally it will call task service platform api through rest call.

   **Platform service (Task)  Swagger URL:**
   https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/task-service/swagger-ui/index.html#/TaskController/getCheckList

5. **documentList GraphQL - POST**

     documentList(onboardingId:String, onboardingType:String, AccountNumber:String):[Document]

   * This api will fetch the document tab records as per the onboardingId and filterCriteria from filenet service.
   * Internally calling filenet service api /v1/documents/search

6. **/v1/forms/audit-trail - GET**

   * This api will use for to fetch records from uo_audit_trail table for history.
   * Internally it will call audit-trail service platform api through rest call.

    **Platform service (audit-trail)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/audit-trail-service/swagger-ui/index.html#/AuditTrailController/getAuditTrails

Below api's is used for when user click on initiateOnboarding button and to save the user entered details in left panel tab when we click on save & exit button and save & continue button.

1. **/v1/forms/{formName}/tabs/{tabName}/v1/forms/{formName}/tabs/{tabName} - POST** 

   * Use this api to store the full json based on formName and tabName into uo-datapoint table.
    
   *  Internally it will call platform service POST form api through rest call.
   
    **Platform service (form)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/form-service/swagger-ui/index.html#/Form/saveFormTabData        
   
2. **/v1/forms/{formName}/tabs/{tabName} - GET** 

   * Use this api to fetch the full json based on formName and tabName from uo-datapoint table.
   * Internally it will call platform service GET form api through rest call.

    **Platform service (form)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/form-service/swagger-ui/index.html#/Form/getFormTabData
   
3. **/v1/forms/{formName}/tabs - GET** 

   * Use this api to fetch the full json based on formName from uo-form table.
    
   * Internally it will call platform service GET form api through rest call.
       
    **Platform service (form)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/form-service/swagger-ui/index.html#/Form/getFormData  
    
4. **v1/datapoint/checklist - POST** 

   * Use this api to to store individual  data into uo-datapoit table.

   * Internally it will call platform service form api through rest call.
   
    **Platform service (form)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/form-service/swagger-ui/index.html#/Form/saveChecklistAndAuditTrail
    
5. **v1/country-list - GET**
 
   * This api will fetch the country list records from uo-refs table.

    **Platform service (Event)  Swagger URL:**
    https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/event-service/swagger-ui/index.html#/Onboarding/getTableMetadata

6. **v1/state-list - GET**

   * This api will fetch the state list records from uo-refs table.
    
   **Platform service (Event)  Swagger URL:**
   https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/event-service/swagger-ui/index.html#/Onboarding/getTableMetadata