select * from refsmeta; 
--FeeSchedule typeid=1
--FeeScheduleService typeid=2
--FeeScheduleServiceSection typeid=3
--FeeScheduleServiceSectionRows typeid=4

select * from refs where typeid=1; --AIS - 610
select * from refs where typeid=2 and string3='1'  ;
--Custody 3
--Additional Services 4
--Additional Global 5
--Collateral 6
-- Margin   7

select * from refs where typeid=3 and string3='1' and string4='3'  ;

select * from refs where string49 like '%FLD39%' and typeid=4;
select * from refs where string49 = 'SEC171';

select * from refs where typeid=8;

--styleName:USBHeader3,spaceBefore:100,spaceAfter:0,italics:false,bullet:false

select * from refs where typeid=4;


insert into refs (typeId,typeName,name,sortorder,string1,string2,string3,string4,string5,string6,string46,string47,string49)
values (3	,'FeeScheduleServiceSection'	,'Section2'	,2	,NULL,'2'	,'1'	,'3',	'SEC171'	,NULL	,'styleName:fieldtxt,spaceBefore:0,spaceAfter:0,italics:true,bullet:false'	,NULL	,'SEC172');



use USB_FSAO;
select * from refs where typeid=1;
--id = 5
select * from refs where typeid=2 and string3=4; --custody is 4

--Service=3, custody has table;
select * from refs where typeid=3 and string3=4 and string4 = 3;

select * from refs where typeid='4' and string3='4' and string4 = '3' and string5='1';

select * from refs where typeid=6;

select * from refs where typeid=1 ;

typeid=3, string4=4, string4=3 (Custody, 3rd Service) (Section 1 has table)

typeid=6 (if render = yes) then it is table (where as typeid=7 text afte table)

