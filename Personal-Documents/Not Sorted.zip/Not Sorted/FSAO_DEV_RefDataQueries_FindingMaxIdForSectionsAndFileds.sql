select * from databasechangelog order by cast(id as bigint) desc;

select ID,count(ID) from databasechangelog group by ID order by cast(id as bigint) desc;




delete from databasechangelog where id in ('171','177','181','182');

-----

select substring(string49,4,10),string49 from refs where typeid=3 order by Cast(substring(string49,4,10) AS bigint) desc ;
--194;
--195
select * from refs where typeid=3 and string49 = 'SEC195' ;
select substring(string49,4,10),string49 from refs where typeid=4 order by Cast(substring(string49,4,10) AS bigint) desc ;
--459
--453

select string49,string5 from refs where typeid=4 and string49 in (select string49 from refs where typeid=4 group by string49 having count(String49) > 1) order by String49;

select count(*) from refs where typeid=3;
--194

------ Get refs (2,3,4) for Fee Schedules.

--get Services

select typeid,typeName,Name,sortOrder,string1,string2,string3,string4,string5,string6,string7,string8,string9,string10,string11,string12,string13,string14,string15,string16,string17,string18,string46,string47,string49
from refs where typeid=2 and string3 = '5' order by cast (String2 as bigint);

--get Sections
select typeid,typeName,Name,sortOrder,string1,string2,string3,string4,string5,string6,string7,string8,string9,string10,string11,string12,string13,string14,string15,string16,string17,string18,string46,string47,string49
from refs where typeid=3 and string3 = '5' order by cast (String4 as bigint),cast (String2 as bigint);

--get fields
select typeid,typeName,Name,sortOrder,string1,string2,string3,string4,string5,string6,string7,string8,string9,string10,string11,string12,string13,string14,string15,string16,string17,string18,string46,string47,string49
from refs where typeid=4 and string3 = '5' order by cast (String4 as bigint),cast (substring(string5,4,10) as bigint),cast (String2 as bigint);