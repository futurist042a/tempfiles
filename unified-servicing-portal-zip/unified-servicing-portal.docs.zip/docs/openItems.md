# Unified Service Portal - Open Items / Issues
This readme provides the current open items and issues list.
- Retrieve the Process Instance owners from the BPM REST API based on the process InstanceId
    - Currently we are only getting all the teams and team's manager mapped in the process.
    - In addition, also checking whether the process is exposed to user logged in.
- EKS Cluster: Application Load Balancer is currently configured to NodeIP Address, in case the node gets destoryed and recreated the IP address will get changed. So we need to find a solution to avoid IP address change.
    - One of the possible solution was to look at using Nginx within the EKS Cluster.