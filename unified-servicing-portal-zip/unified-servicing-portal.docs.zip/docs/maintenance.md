# Maintenance

## Creating/updating environment variables

Whenever a new environment variable is needed within the application, or if an existing variable needs to be updated, there are a few files that need to be changed. We have a script to automate this tedious task:

```bash
npm run update-env-var
```
