# Deploy Docker Image in AWS EKS using Rancher

## Rancher Login
- Browse to the Rancher URL: https://rancher.cps.nonprod.aws.prv/dashboard
![image-26.png](./image-26.png)
- Login using your US Bank id and password.
- Click on 'Login in with Active Directory'.
- Once login successfully, the dashboard will be displayed as shown below.
![image-27.png](./image-27.png)

## Create Namespace
Create a namespace to logically group all the workloads related to a project, if one is not already present.

Follow the below steps to create a new namespace.
- From the Rancher Dashboard, navigate to Cluster -> Projects/Namespaces.
- Click on Create Namespace button as shown below.
![image-29.png](./image-29.png)
- Provide the below values, the filled in values are shown in the screenshot provided.
    - Name
    - Description
    - In Labels & Annotations, add the below values for label
        - kubernetes.io/metadata.name: <namespace_name>
    - In Labels & Annotations, add the below values for annotations
        - kubernetes.io/metadata.name: <namespace_name>    
        - usb-assigneeGroup: APL_Trust:Lombardi
![image-31.png](./image-31.png)
- Click on the Create button
- The successful namespace created will be shown as below
![image-32.png](./image-32.png)

## Create Secrets
To connect with the Artifactory, create the secrets with the login details
- From the Rancher Dashboard, navigate to Storage -> Secrets and click on Create button as shown below
![image-33.png](./image-33.png)
- In the next screen, select Registry as the option for creating the secrets
![image-34.png](./image-34.png)
- Provide the below details to create the secret
    - Name
    - Select Artifactory option for Data
    - Provide the Registry Domain name, Username and Password

![image-35.png](./image-35.png)
- Click on the Create button
- The secret will be displayed on successfully creation.
![image-36.png](./image-36.png)

## Deploy the usp-exp-api Docker Image
To Deploy the Docker image, follow the below steps.
- From the Rancher Dashboard, navigate to Workloads -> Pods and click on the Create button as shown below.
![image-37.png](./image-37.png)
- Provide the below values in the Deployment Form
     Key               |  Value
    ------------------ | -------------------
    Name               | usp-exp-api
    Description	       | USP Experience API Service 
    Container Name     | usp-exp-api
    Type	           | Select Standard Container
    Container Image	   | artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0
    Pull Policy        | IfNotPresent
    Pull Secret        | usp-artifactory (Select)
![image-38.png](./image-38.png)
- Provide the below Networking Information by clicking on 'Add Port or Service' button
     Key               |  Value
    ------------------ | -------------------
    Service Type       | Node Port
    Name	           | USP Experience API Service 
    Container port     | 8080
    Protocol	       | TCP
    Listening Port	   | Blank (Automically a port will be assigned)
![image-39.png](./image-39.png)
- Provide the below Environment Variables by clicking on 'Add Variable' button
     Name                      |  Value
    -------------------------- | -------------------
    AWS_DEFAULT_REGION         | us-east-2
    HTTP_PROXY	               | http://proxy.us-east-2.nonprod.aws.prv:3128 
    HTTPS_PROXY                | http://proxy.us-east-2.nonprod.aws.prv:3128
    NO_PROXY	               | sts.us-east-2.amazonaws.com,localhost,127.0.0.1,172.20.0.0/16
    AWS_STS_REGIONAL_ENDPOINTS | regional
    AWS_ROLE_ARN	           | arn:aws:iam::627873121129:role/cps-eks-ibmbawcontainer-devtest-use2-dwou-p-tl7kn-dns-Role
    AWS_WEB_IDENTITY_TOKEN_FILE| /var/run/secrets/eks.amazonaws.com/serviceaccount/token
![image-40.png](./image-40.png)
- In the Health Check section, add the below details for Readiness Checks. Select Type as 'HTTP request returns a successful status (200-399)'
    Key                |  Value
    ------------------ | -------------------
    Check Port         | 8080
    Check Interval	   | 10 
    Initial Delay port | 60
    Timeout	           | 1
    Success Threshold  | 1
    Failure Threshold  | 20
    Request Path	   | /api/onboarding/corp-apply/usp-service/actuator/health

![image-42.png](./image-42.png)

- In the Health Check section, add the below details for Liveness Checks. Select Type as 'HTTP request returns a successful status (200-399)'
    Key                |  Value
    ------------------ | -------------------
    Check Port         | 8080
    Check Interval	   | 10 
    Initial Delay port | 60
    Timeout	           | 1
    Success Threshold  | 1
    Failure Threshold  | 10
    Request Path	   | /api/onboarding/corp-apply/usp-service/actuator/health

![image-44.png](./image-44.png)

- In the Resources section, add the below details
    Key                |  Value
    ------------------ | -------------------
    CPU Reservation    | 500
    CPU Limit	       | 1000
    Memory Reservation | 256
    Memory Limit	   | 512
![image-43.png](./image-43.png)

- Click on the Create button
- The docker image will be pulled from the repository and the container will get created.
![image-45.png](./image-45.png)
- Once the Container gets started and the readiness check is successful, the pod will change the status to running as shown below 
![image-46.png](./image-46.png)
- Click on the dot at the end of the Pod to view the log and to login into the container
![image-48.png](./image-48.png)
![image-47.png](./image-47.png)
- Log will be shown as below
![image-49.png](./image-49.png)

### Retrieve the Service Port
- To retrieve the URL, identify the service port by navigating to Service Discovery -> Services
![image-51.png](./image-51.png)
- The port for this deployment is shown as 30515
- The URL will be in the format : http://NodeIPAddress:NodePort/api/onboarding/corp-apply/usp-service.
- For this deployment the URL will be 
    - GraphQl: https://portal.usp.ba.nonprod.aws.cloud.bank-dns.com/api/onboarding/corp-apply/usp-service/graphql 

## Deploy the unified-servicing-portal Docker Image
To Deploy the Docker image, follow the below steps.
- From the Rancher Dashboard, navigate to Workloads -> Pods and click on the Create button as shown below.
![image-37.png](./image-37.png)
- Provide the below values in the Deployment Form
     Key               |  Value
    ------------------ | -------------------
    Name               | unified-servicing-portal
    Description	       | Unified Servicing Portal
    Container Name     | unified-servicing-portal
    Type	           | Select Standard Container
    Container Image	   | artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.3
    Pull Policy        | IfNotPresent
    Pull Secret        | usp-artifactory (Select)
![image-58.png](./image-58.png)
- Provide the below Networking Information by clicking on 'Add Port or Service' button
     Key               |  Value
    ------------------ | -------------------
    Service Type       | Node Port
    Name	           | usp-portal-srv
    Container port     | 5031
    Protocol	       | TCP
    Listening Port	   | Blank (Automically a port will be assigned)
![image-59.png](./image-59.png)
- Provide the below Environment Variables by clicking on 'Add Variable' button
     Name                      |  Value
    -------------------------- | -------------------
    AWS_DEFAULT_REGION         | us-east-2
    HTTP_PROXY	               | http://proxy.us-east-2.nonprod.aws.prv:3128 
    HTTPS_PROXY                | http://proxy.us-east-2.nonprod.aws.prv:3128
    NO_PROXY	               | sts.us-east-2.amazonaws.com,localhost,127.0.0.1,172.20.0.0/16,.us.bank-dns.com,10.87.100.37
    AWS_STS_REGIONAL_ENDPOINTS | regional
    AWS_ROLE_ARN	           | arn:aws:iam::627873121129:role/cps-eks-ibmbawcontainer-devtest-use2-dwou-p-tl7kn-dns-Role
    AWS_WEB_IDENTITY_TOKEN_FILE| /var/run/secrets/eks.amazonaws.com/serviceaccount/token
![image-40.png](./image-40.png)

- In the Resources section, add the below details
    Key                |  Value
    ------------------ | -------------------
    CPU Reservation    | 500
    CPU Limit	       | 1000
    Memory Reservation | 1024
    Memory Limit	   | 2048
![image-60.png](./image-60.png)

- Click on the Create button
- The docker image will be pulled from the repository and the container will get created.
- Once the Container gets started and the readiness check is successful, the pod will change the status to running as shown below 
![image-61.png](./image-61.png)
- Click on the dot at the end of the Pod to view the log and to login into the container
![image-62.png](./image-62.png)
![image-63.png](./image-63.png)
- Log will be shown as below
![image-64.png](./image-64.png)

### Retrieve the Service Port
- To retrieve the URL, identify the service port by navigating to Service Discovery -> Services
![image-65.png](./image-65.png)
- The port for this deployment is shown as 32723
- The URL will be in the format : http://NodeIPAddress:NodePort/usp/home i.e http://10.87.100.37:32723/usp/home
