# Portal - Issues and Resolution

## Invalid HTTP Header

``Issue:`` While accessing the Unified Service Portal using the IP Address or DNS domain, the browser display an error message 'Invalid HTTP Header'. The same code with localhost works without any issues. 

``Resolution:``
- In the webpack.development.config.js, add the below code
```
devServer: {
   allowedHosts: ['.usp.ba.nonprod.aws.cloud.bank-dns.com']
}
```
- _Note:_ The allowedHosts should include the IP Address / DNS name through which the Portal is invoked. 

Reference:
- [Webpack Dev Server External Access - (Fix: Invalid Host Header)](https://dev.to/sanamumtaz/webpack-dev-server-external-access-fix-invalid-host-header-g81)
