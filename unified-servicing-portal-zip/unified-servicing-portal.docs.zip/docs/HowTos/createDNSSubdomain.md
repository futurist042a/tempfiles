# Create DNS for Unified Service Portal
The DNS subdomain for the Unified Service Portal and the Domain API will be added using the testing domain ba.nonprod.aws.cloud.bank-dns.com.

The settings needs to be added in the USB Central DNS AWS Account. Awais have the access to add the setting.

# Configuration
- Login into AWS Console and access Route 53
- Once logged in, copy and paste the below URL so can navigate directly to ba.nonprod.aws.cloud.bank-dns.com HostedZone.
```
https://console.aws.amazon.com/route53/v2/hostedzones#ListRecordSets/Z0830282352AAHKEERL8Y

```
![image-40.png](./image-40.png)
- Click the button 'Create record'
- Provide the below details
    Parameter          |  Value
    ------------------ | -------------------
    Record name           | *.usp.ba.nonprod.aws.cloud.bank-dns.com
    Record type        | Select CName
    Value           | Provide the application load balancer DNS
    Other Atributes           | Leave the default values
![image-41.png](./image-41.png)
- Click the button 'Create records'
