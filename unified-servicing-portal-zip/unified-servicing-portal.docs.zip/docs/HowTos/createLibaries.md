## Create and Publish Libary
This readme provides the details for creating the libary and publish the libary in the artifactory.

### RenderUI

#### Setup the code in Visual Studio
Clone the RenderUI code base from the [Gitlab](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/renderUI_Lib?ref_type=heads) into Visual Studio Code

The code base will be setup as shown below. 
![Alt text](image-67.png)

#### Create Libary
Once the code base is setup, open the terminal by navigating to view -> terminal

Install the node modules that are defined in the package.json by executing the below command
```
npm install -f
```

The node_modules will be created as shown below
![Alt text](image-68.png)

Follow the below steps to create the libary
- Check the .babelrc file and make sure the "@babel/preset-env" modules value is set as "commonjs" as shown below.
![Alt text](image-69.png)
- Execute the below command to create the commonjs modules from the react code.
```
npm run build:cjs
```
![Alt text](image-70.png)
- Check the .babelrc file and make sure the "@babel/preset-env" modules value is set as "false" as shown below.
![Alt text](image-71.png)
- Execute the below command to create the es6 modules from the react code.
```
npm run build:esm
```
![Alt text](image-72.png)
- Execute the below command to copy the libary
```
npm run build:lib
```
![Alt text](image-73.png)
- All the above commands will have created the dist folder as shown below.
![Alt text](image-74.png)

#### Publish Libary
Once the libary code is created, follow the below code to publish the libary into artifactory.
- In the package.json, set the version number for the libary to deployed. The version number for the libary should be unique, so incremenet the major or minor version accordingly.
![Alt text](image-75.png)
- Execute the below command to publish the code into artifactory
```
npm publish
```

### USBPage

#### Setup the code in Visual Studio
Clone the USBPage code base from the [Gitlab](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/usbPage_Lib/src?ref_type=heads) into Visual Studio Code

The code base will be setup as shown below. 


#### Create Libary
Once the code base is setup, open the terminal by navigating to view -> terminal

Install the node modules that are defined in the package.json by executing the below command
```
npm install -f
```

The node_modules will be created as shown below
![Alt text](image-76.png)

Follow the below steps to create the libary
- Check the .babelrc file and make sure the "@babel/preset-env" modules value is set as "commonjs" as shown below.
![Alt text](image-77.png)
- Execute the below command to create the commonjs modules from the react code.
```
npm run build:cjs
```
![Alt text](image-78.png)
- Check the .babelrc file and make sure the "@babel/preset-env" modules value is set as "false" as shown below.
![Alt text](image-79.png)
- Execute the below command to create the es6 modules from the react code.
```
npm run build:esm
```
![Alt text](image-80.png)
- All the above commands will have created the dist folder as shown below.
![Alt text](image-81.png)

#### Publish Libary
Once the libary code is created, follow the below code to publish the libary into artifactory.
- In the package.json, set the version number for the libary to deployed. The version number for the libary should be unique, so incremenet the major or minor version accordingly.
![Alt text](image-82.png)
- Execute the below command to publish the code into artifactory
```
npm publish
```