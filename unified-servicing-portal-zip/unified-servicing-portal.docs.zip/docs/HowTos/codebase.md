## Gitlab Code Base details

The below are the Gitlab link for the complete codebase for AppBuilder
- AppBuilder Portal (React JS Code): https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/ui_editor_v3?ref_type=heads
- AppBuilder Service (Spring Boot Code): https://gitlab.us.bank-dns.com/axsult1/usp-exp-api
- AppBuilder Web Server (Node JS): https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/appBuilderWebServer
- AppBuilder Libraries (React JS):
    - RenderUI: https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/renderUI_Lib?ref_type=heads
    - USBPage: https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/usbPage_Lib?ref_type=heads
- Account Intake POC using the Libraries (React Code): https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/account_intake_poc?ref_type=heads