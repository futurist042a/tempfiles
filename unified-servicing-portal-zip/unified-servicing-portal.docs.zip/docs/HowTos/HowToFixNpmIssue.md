# Docker Image Creation Issues

## npm install takes long or hangs during docker build
_Issue:_ 
During the docker build for portal, the npm install was takes longer to compelte and it throwns the below error message after 12 minutes.

```
1193.4 npm WARN   dev msw@"1.2.1" from the root project
1448.7 npm ERR! code EAI_AGAIN
1448.7 npm ERR! syscall getaddrinfo
1448.7 npm ERR! errno EAI_AGAIN
1448.7 npm ERR! request to https://artifactory.us.bank-dns.com/artifactory/api/npm/UX-Shield-Design-System-NPM-virtual/react-dom failed, reason: getaddrinfo EAI_AGAIN artifactory.us.bank-dns.com
1448.7
1448.7 npm ERR! A complete log of this run can be found in: /root/.npm/_logs/2024-02-16T07_48_37_826Z-debug-0.log
```

_RootCause:_
The EAI_AGAIN error is due to DNS name resolution error and timeouted. The issue was with the docker network within the build process, outside the build was able to ping the artifactory but during build had the issue.

_Resolution:_
Pass the docker network as one of the parameter to the docker build. The steps are provided below.
- Lookup docker network using the command 'docker network ls'
![Alt text](image-42.png)
- Check by passing each network name as the parameter to the docker build as shown in the below command
```
docker build --network=host -t usp/unified-servicing-portal .

Note: the issue we had with build fixed while host network was passed as the input.
```