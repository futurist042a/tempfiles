# BAW TASK URL SSO Issue from external Portal

## Issue
The IBM BAW server is configured with the PingFed. The requirement is to launch the BPM Task URL(e.g. ) from the external portal developed using react application. 

When the Task URL is launch for the first time without any active session, the URL get launched successfully. But if we click the same URL again, we get the error message “The error page you're trying to access doesn't exist. No error page was created for this error.” - 400 (Bad Request) and the URL is displayed as : https://ebpm-dev2.us.bank-dns.com/oidcclient/FundServicesBPM?code=3njCjof6bh-hu1sXjkugTwYuhXLycXJgB7IAAAAq&state=VFozvrjHR54r16ui8IYC0dynf7zYtTbiIyI02RlC6Y_1707225903246 

The console log is shown as below
GET https://ebpm-dev2.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=887866 401 (Unauthorized)
Navigated to https://ebpm-dev2.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=887866
                Navigated to https://ebpm-dev2.us.bank-dns.com/oidcclient/FundServicesBPM?code=3njCjof6bh-hu1sXjkugTwYuhXLycXJgB7IAAAAq&state=VFozvrjHR54r16ui8IYC0dynf7zYtTbiIyI02RlC6Y_1707225903246

If we clear the cookies/logout  and try to access to URL again it works for the next request. 

When we tried to analysis the network logs between failed and successful request, we see difference in the request header cookies. The details are provided below.

**Worked:** Cookie: JSESSIONID=0000kO9kqWfrtWpL-9jpwbqyBX2:1h91kpb4k; OIDCSTATE_FundServicesBPM=rO0ABXNyABNqYXZh--removed---sjianml/9Nzqky/xENsGo=; OIDCREQURL_FundServicesBPM=https://ebpm-dev2.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=887866

**Failed:** Cookie: lombardi.locale.name=en; BAYEUX_BROWSER=8b3no2vupufr1k1y; OIDCSESSIONID_FundServicesBPM=fxqQwT9CnCE--removed--BnjKzPh43FQ==; LtpaToken=0keChI+jlOhNBCGdZNMMPZRT4MWfkEM5n0+Ig--removed--kmcKUT6lg==; ibm.bpm.timezoneOffset=-330; ADRUM=s=1707225592510&r=https%3A%2F%2Febpm-it.us.bank-dns.com%2Fteamworks%2FfauxRedirect.lsw%3Fhash%3D122252827; com.ibm.bpm.servlet.LaunchDashboardServlet.defaultAvatarKey=946681200000; LtpaToken2=KGipItH9S5ryVdV2X4---removed---MsSExDv3xlz5J0=; OIDCREQURL_FundServicesBPM=https://ebpm-dev2.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=887866; JSESSIONID=0000MctGZhtdEsBJiI30cDgZgUD:1h91kpb4k; OIDCSTATE_FundServicesBPM=rO0ABXNy---removed..WlzU=

## RootCause
If there is an active session to the BAW server and invoke the BAW Task URL from the external application, only the cookies configured with SameSite as None and Lax gets added to the Task URL. So, the cookies with SameSite as Strict doesn't get added which seems to be root cause for the 401 error for the failed request.

Below screenshot provides what are the different SameSite configuration - these cookies gets added automatically on successful login to the BAW server. 

**Active Session - Cookies**
![Alt text](image-43.png)

**Sucessful Task URL Request - Cookies**
![Alt text](image-44.png)

**Failed Task URL Request - Cookies**
![Alt text](image-45.png)

## Resolution
In the BAW server, the cookie setting were updated i.e. set the cookie policy to Lax on Stack1 & 2 DEV, IT. Note : Stack1 UAT & PROD use Lax instead of strict.

THe setting was update by editing the CookieSameSite custom property in the WAS Admin console here:
Servers > Server types > WebSphere application servers > server_name >  Session management > Custom properties
 
And set that to lax instead of strict.
