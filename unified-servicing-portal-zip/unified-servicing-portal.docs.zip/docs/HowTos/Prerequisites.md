## Prerequisites

The below are the Prerequisites for setting up the React and Java project for AppBuilder
- Install Visual Studio Code
    - Windows OS Catalog Link: [Visual Studio Code](https://itsmnow.service-now.com/mytech?id=sc_cat_item&table=sc_cat_item&sys_id=4cbd098b474c1e50e831d150706d437b&recordUrl=com.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1&sysparm_id=4cbd098b474c1e50e831d150706d437b)
- Install IntelliJ IDEA Community Edition
    - Windows OS Catalog Link: [IntelliJ IDEA Community Edition](https://itsmnow.service-now.com/mytech?id=sc_cat_item&table=sc_cat_item&sys_id=aa41f886eb1016d0e94efdb7cad0cd0d&recordUrl=com.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1&sysparm_id=aa41f886eb1016d0e94efdb7cad0cd0d)
- Install Node.js
    -  Windows OS Catalog Link: [Node.js](https://itsmnow.service-now.com/mytech?id=sc_cat_item&table=sc_cat_item&sys_id=9ae29733ebed9690ef7ff9f7fcd0cddd&recordUrl=com.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1&sysparm_id=9ae29733ebed9690ef7ff9f7fcd0cddd)



