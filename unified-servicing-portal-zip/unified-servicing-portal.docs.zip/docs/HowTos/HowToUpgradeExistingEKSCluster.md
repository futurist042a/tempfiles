# Upgrade Existing EKS Cluster

## Problem Record Raised for EKS
We have a problem record -  PRB0108646 assigned to our team related to EKS cluster.
 
EKS Cluster: eks-ibmbawcontainer-devtest-use2-dwou
Instance: i-049ce67cb1b9d2755
 
Problem Description: 1 or more VMs are out of compliance and must be remediated ASAP. As per control 3081, all vm's with maintenance_type of cattle must be redeployed every 30 days. 

### Procedure for remediation:
- This is a process that teams must perform if they own dedicated clusters. This guide below will show you how to perform those functions
    - [Upgrade existing EKS cluster node groups - Cloud Platform Solutions - Enterprise Confluence (bank-dns.com)](https://confluence.us.bank-dns.com/pages/viewpage.action?spaceKey=CPS&title=Upgrade+existing+EKS+cluster+node+groups)

### Steps Followed
- Navigate to the self-service via http://hybridcloud.us.bank-dns.com/awscaas.
- Provided the below details
![Alt text](image-63.png)
![Alt text](image-64.png)
![Alt text](image-65.png)
- The details are provided below for reference
    - EKS Cluster Name: eks-ibmbawcontainer-devtest-use2-dwou
    - AWS Account ID:627873121129
    - Region: us-east-2
    - Primary Contact: Awais.Sultan@usbank.com
    - Secondary Contact: rajesh.vasireddy3@usbank.com
- Once submitted, the below confirmation screen will be displayed.
![Alt text](image-66.png)
