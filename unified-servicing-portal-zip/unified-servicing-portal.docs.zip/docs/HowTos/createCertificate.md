# Create Certificate

Reference:
- [AWS Certificate Management](https://usbank.sharepoint.com/teams/Cloud_Security_Solutions/SitePages/Creating-Venafi-Entitlements.aspx)

## Entitlement
- Create a access request for Entitlement - "Venafi AWS 627873121129 User Admin Rights NonProd"
    - The 627873121129 is the AWS Account #
- The entitlement is required to raise certificate request in Venafi.

## Raise Portal Certificate Request
- Login into Venafi Login Page: https://certservices.global.prv/login
- If the Entitlement mentioned above is assigned, the user should be able to view the 'Create New Certificate' button as shown below.
![image-28.png](./image-28.png)
- Click on the button
- Provider the folder to store the certificate - select for All Objects assigned to the AWS account as shown below 
![image-29.png](./image-29.png)
- Provide the below details
    Parameter          |  Value
    ------------------ | -------------------
    Nickname           | portal.usp.ba.nonprod.aws.cloud.bank-dns.com
    Description        | Certificate for the Unified Service Portal that will get applied to the URL http://portal.usp.ba.nonprod.aws.cloud.bank-dns.com/
    Contacts           | Add axsult1(other ids as required)
    CAR ID             | 2577
    High Certificate Criticality | Select false
![image-30.png](./image-30.png)
- Click on Next button
- In the Certificate Signing Request section, provide the below details
    Parameter          |  Value
    ------------------ | -------------------
    Common Name        | portal.usp.ba.nonprod.aws.cloud.bank-dns.com
    Organizational Units | can be left blank
![image-31.png](./image-31.png)
- Click on Next button
- In the Additional Information section, provide the below details
    Parameter          |  Value
    ------------------ | -------------------
    Subject Alternative Names (DNS)        | portal.usp.ba.nonprod.aws.cloud.bank-dns.com
    Automatic Renewal? | Select yes
    Certificate Validity | Select Use Validity period
    Start processing on creation | Select the checkbox

![image-32.png](./image-32.png)
- Click on Create Certificate button
- The certificate could be created within a day.

## Install the Certificate in AWS Certificate Manager

Once the Certificate is created, the certificate can be downloaded or can also be directly installed into the AWS Certificate Manger(ACM). 

The Certificate once installed in ACM, can be directly applied to the Application Load Balaner. To install the certificate in ACM, follow the below step.

- From the Venafi dashboard, Navigate to Inventory - > Certificates
![image-33.png](./image-33.png)
- Click on the Certificate create and Select the Add Installation from the Action menu as shown below
![image-34.png](./image-34.png)
- In the Add a New Installation screen, select "Track this Certificate" option and click on the Next button.
![image-35.png](./image-35.png)
- Provide the below details in the Installation setting
    Parameter          |  Value
    ------------------ | -------------------
    Name           | Basic-portal.usp.ba.nonprod.aws.cloud.bank-dns.com
    Description           | We need to apply the SSL for the Portal DNS
    Processing Enabled            | Select Yes option
    Contact(s) | Add axsult1(other ids as required)
    Device Settings | Leave the default value
    Installation Settings | Leave the default value expect for below attributes
    Provision To          | ACM
    Region                | US East (Ohio)
![image-36.png](./image-36.png)
![image-37.png](./image-37.png)
![image-38.png](./image-38.png)
- Click on the button to complete the installation
- The installation could reflect in ACM in 5-10 minutes, as shown below.
![image-39.png](./image-39.png)

## Appendix
### Create certificate to download the Cert files
In Case, there is a requirement to download the Cert files including the private keys then select the below Certificate Folder.

![Alt text](image-46.png)

The other steps mentioned above on creating the certificate remains the same.