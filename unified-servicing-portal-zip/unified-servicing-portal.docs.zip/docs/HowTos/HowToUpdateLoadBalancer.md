# Update AWS Application Load Balancer on EKS Node IP Change

## Current EKS Cluster Configuration
Currently the services and portal deployed in Amazon Elastic Kubernetes Service (Amazon EKS) i.e. EKS Cluster is accessed through AWS Application Load Balancer. _Note:_ The detailed steps of how to create and configure Application Load Balancer is provided in seperate [readme](applicationLoadBalancer.md)

The Application Load Balancer have different Target group as shown below 
![Alt text](image-47.png)

Each of the Target group is configured EKS Cluster Node IP to foward the request as shown below
![Alt text](image-48.png) 

If the EKS Cluster Node IP address change e.g. on update or recreate then the IP address will also get updated. In that scenario, the poral and service will throw Bad Gateway error as the Node IP will not be reachable.

The below section provides the steps to update and register a new the target with updated Node IP.

_Note:_ In parallel we are also working with EKS team to find alternative approach to fix the above issue.

## Update Target Group
To update the target group with the new Node IP address follow the below steps.
- To identify the new Node IP Address, login into the Rancher and navigate to Cluster -> Node and note the new Node IP address.
![Alt text](image-49.png)
- To update the Load balancer Target, login into AWS Console and go to EC2 Dashboard
- In the EC2 Dashboard, navigate to Load Balancing -> Load balancers and look for 'usp-alb' load balancer which is configured for EKS Cluster.
![Alt text](image-50.png)
- Click on the 'Listeners and rules' tab. Each of the rules defined for the listener are configured to a target group which needs to be updated with the new Node IP.
![Alt text](image-51.png) 
![Alt text](image-52.png)
- To update the target group, click on rules to view all the target groups configured as shown below.
![Alt text](image-53.png)
- Repeat the below step for each target group.
    - Click on the target group to be updated.
    - The registered target will show the Health status as unhealthly as shown below if the IP address is not reachable.
    ![Alt text](image-54.png)
    - Click on 'Register targets' button to regiser the new target.
    ![Alt text](image-55.png)
    - Specify the new IP address and the port used(Port will remain the same). Click on 'Include as pending below' button.
    ![Alt text](image-56.png)
    - The new target will get added as shown below. Click on 'Register Pending Targets' button.
    ![Alt text](image-57.png)
    - This will add the new target and the health status will show as 'initial' while trying to register.
    ![Alt text](image-58.png)
    - Once the target is registered, the health status will change to Healthy.
    ![Alt text](image-59.png)
    - The older unhealthy target can be deregistered. To do that, select the Unhealthy target record checkbox and click on the 'Deregister' button.
    ![Alt text](image-61.png)
    - The Unhealthy target will get drained and will be removed in 2-3 minutes.
    ![Alt text](image-62.png)
- Once all the target group is completed, the portal and service will be working with the new Node IP address.
