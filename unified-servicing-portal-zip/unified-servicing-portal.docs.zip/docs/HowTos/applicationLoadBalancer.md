# Application Load Balancer

## Create Application Load Balancer (ALB)
- Login into the AWS Console
- Launch the EC2 Dashboard and navigate to Load Balancing -> Load Balancers
![image.png](./image.png)
- Click on the Option 'Create Application Load Balaner' in the button 'Create load balancer' as shown below
![image-1.png](./image-1.png)
- Add the below details for Basic configuration section
    Parameter          |  Value
    ------------------ | -------------------
    Load balancer name | usb-alb (Add a logical name for load balancer)
    Scheme             | Internal
    IP address type    | IPv4

![image-2.png](./image-2.png)
- Add the below details for Network mapping section
    Parameter             |  Value
    --------------------- | -------------------
    VPC                   | NonProdNonPCI
    Mappings              | As mentioned below for each Availability Zones
    us-east-2a (use2-az1) | Select Subnet App(a)
    us-east-2b (use2-az2) | Select Subnet App(b)
    us-east-2c (use2-az3) | Select Subnet App(c)
![image-3.png](./image-3.png)
- Select a existing security group or create one.
- Create the target group for USP Portal as provided in the below [section]
(applicationLoadBalancer.md#user-content-create-target-group-usp-portal)
![image-5.png](./image-5.png)
- Add the below details for Listeners and routing section
    Parameter             |  Value
    --------------------- | -------------------
    Protocol              | HTTPS
    Port                  | 443
    Default action        | eks-alb-usp-portal-tg (i.e target group created for USP Portal)
![image-17.png](./image-17.png)
- In the Secure listener settings, keep the default setting but only select the certificate that needs to be applied to the HTTPS.
![image-18.png](./image-18.png)
_Note_: If the certificate is not created, create it based on the instruction provided in this [readme](createCertificate.md).

- Keep the default setting for Add-on services
- Add the below tags for the load balancer

     Key               |  Value
    ------------------ | -------------------
    assignment_group   | APL_Trust:Lombardi
    cost_center	       | 3008000561
    environment	       | dev
    car_id	           | 2577
    confidentiality	   | internal
    maintenance_type   | appliance

- Click on the 'Create load balancer' button.

## Configure ALB
Once the Application load balancer is created successfully, the listener setting could look below - the listener could be routing to the default target group configured.
![image-19.png](./image-19.png)

In this section, the steps below will provide the details how to configure the rules to route to different services.
- Select the listener and click on the option to add the rules as shown below
![image-20.png](./image-20.png)
- Add the Name for the rule as 'exp-api' - we will add rule to route to experience api
![image-22.png](./image-22.png)
- Click on Next button
- Click on the Add Condition button
- Select Path as the condition from the drop down
- Provide the path as '/api/*'
- Click on the Confirm button
![image-23.png](./image-23.png)
- Click on the Next button
![image-24.png](./image-24.png)
- In the action, route the request to the exp-api target group ([Create the target group](applicationLoadBalancer.md#user-content-create-target-group-experience-api) if not already created)
![image-25.png](./image-25.png)
- Click Next button
- Provide the Priority as 100 and click on the Next button
![image-26.png](./image-26.png)
- Review the details and click on the Create button
- The listener will now route the request to both Portal and the experience API
![image-27.png](./image-27.png)

## Create target group - USP Portal
- Login into the AWS Console
- Launch the EC2 Dashboard and navigate to Load Balancing -> Target Groups
![image-6.png](./image-6.png)
- Click on the button 'Create target groups'
- Add the below details for Basic configuration section
    Parameter             |  Value
    --------------------- | -------------------
    Choose a target type  | IP addresses
    Target group name     | eks-alb-usp-portal-tg
    Protocol : Port       | Select HTTP and provide the port number as 32723
    Protocol version      | HTTP1
    VPC                   | NonProdNonPCI
![image-7.png](./image-7.png)
![image-10.png](./image-10.png)
- Add the below details for Health check settings section
    Parameter                      |  Value
    ------------------------------ | -------------------
    Health check protocol          | HTTP
    Health check path              | /
    Advanced health check settings | Keep the default setting 

![image-9.png](./image-9.png)
- Click on the Next button
- In the Register targets screen, 'Step 2: Specify IPs and define ports' add '10.87.100.37' for 'Enter an IPv4 address from a VPC subnet' as shown below
![image-11.png](./image-11.png)
- Click on the button 'Include as pending below'
- The registered target will be displayed as below.
![image-12.png](./image-12.png)
- Click on the button 'Create target group'


## Create target group - Experience API
- Login into the AWS Console
- Launch the EC2 Dashboard and navigate to Load Balancing -> Target Groups
![image-6.png](./image-6.png)
- Click on the button 'Create target groups'
- Add the below details for Basic configuration section
    Parameter             |  Value
    --------------------- | -------------------
    Choose a target type  | IP addresses
    Target group name     | eks-alb-expi-api-tg
    Protocol : Port       | Select HTTP and provide the port number as 30515
    Protocol version      | HTTP1
    VPC                   | NonProdNonPCI
![image-7.png](./image-7.png)
![image-13.png](./image-13.png)
- Add the below details for Health check settings section
    Parameter                      |  Value
    ------------------------------ | -------------------
    Health check protocol          | HTTP
    Health check path              | /api/onboarding/corp-apply/usp-service/actuator/health
    Advanced health check settings | Keep the default setting 

![image-14.png](./image-14.png)
- Click on the Next button
- In the Register targets screen, 'Step 2: Specify IPs and define ports' add '10.87.100.37' for 'Enter an IPv4 address from a VPC subnet' as shown below
![image-15.png](./image-15.png)
- Click on the button 'Include as pending below'
- The registered target will be displayed as below.
![image-16.png](./image-16.png)
- Click on the button 'Create target group'

