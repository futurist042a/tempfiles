# AppBuilder - Building Docker Image

## Create Dockerfile

Docker builds images by reading instructions in dockerfiles. The Dockerfile used to create the image is provided below.

This dockerfile is also part of the appBuilderWebServer project in [gitlab](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/tree/appBuilderWebServer).

```
##############################
# Start with app build image #
##############################
FROM artifactory.us.bank-dns.com:5000/node:18-alpine3.17

COPY accountIntake/ /accountIntake/
COPY ideaverse/ /ideaverse/
COPY template/ /template/
COPY usbi/ /usbi/
COPY appBuilderServer.js server.js

CMD ["node","server.js"]

```

## Build the Docker Image
The steps provided below can be executed from any machine which have the docker installed and have access to the artifactory.us.bank-dns.com. 

For creating this image, the Ec2 instance (10.87.98.182) was used.

The document [Connect to Bastion server using putty](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/HowToSetupBastionServerAndConnect.md#connect-to-bastion-server-using-putty) provides the steps required to connect to bastion server.

**Move the files to Bastion Server**
- Commit the lastest code into the gitlab
- Download the AppBuilder Web Server source code as .tar.gz file as shown below
![Alt text](image-87.png)
- Create a folder in Bastion server
- Upload the download file into the Bastion server as shown below.
```
pscp -i .\AWS\ThroughPuttyv2.ppk .\UnifiedOnboarding\Upload\unified-servicing-portal-appBuilderWebServer.tar.gz operatorUsb@10.87.98.182:/home/operatorUsb/eks/appBuilderServer
```
_Note: Download [ThroughPuttyv2.ppk](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/ThroughPuttyv2.ppk) required for the command._
- Extract the tar file using the below command
```
tar -xvzf unified-servicing-portal-appBuilderWebServer.tar.gz
```
- The screenshot of the files after moving and extracting into the Bastion server are shown below.
![Alt text](image-88.png)
- Before creating the image, verify and setup docker based on the steps provided in [Appendix - Docker Setup](build-dockerfile.md#user-content-docker-setup) 
- To build the docker image use the following command from the folder in which the Dockerfile, jar and trust store is copied.
```
docker build -t usp/appbuilder-webserver .
```
_Note: usp/appbuilder-webserver is the docker image name._

Use the below command to check if the image is created successfully
```
docker images
```

## Tagging and Publish Docker image

As the next step, tag the docker image created and move the image to the Artifactory so the image can be used for deploying into the EKS.
- Tag the Docker image created using the below command
```
docker tag usp/appbuilder-webserver artifactory.us.bank-dns.com:5000/usb/appbuilder-webserver:v_1.0.0
```
_Note: If the version mentioned is already available in the respoistory, provide a different version i.e v_1.0.1_
- Verify if the connection to the Artifactory is successful using the below command.
```
docker login artifactory.us.bank-dns.com:5000
```
- If the auth token is not already configured, the login details will be requested. Provide the login details to login to the artifactory.
- Once able to login, we can publish the image to the Artifactory using the below command
```
docker push artifactory.us.bank-dns.com:5000/usb/appbuilder-webserver:v_1.0.0

```