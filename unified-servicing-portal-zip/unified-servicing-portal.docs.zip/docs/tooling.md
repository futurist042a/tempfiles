# Tooling

## Visual Studio Code Extensions

It is advisable for everyone in your team to use Visual Studio Code, so you can all take advantage of the features provided by the recommended extensions listed under `.vscode/extensions.json`. These extensions were curated to help maintain code readability and cleanliness, and to provide a smoother development experience for everyone.

When you first open this repository in VSCode, you'll see a dialog on the bottom right. You can install all the recommended extensions by clicking **Install All**. If you close this dialog, you can still see the recommended extensions by opening the Extensions tab on the far left, and browsing through the **Workspace Recommendations** list.

## Browser Extensions

- [React Developer Tools](https://chrome.google.com/webstore/detail/react-developer-tools/fmkadmapgofadopljbjfkapdkoienihi?utm_source=ext_app_menu)
- [Redux Devtools](https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?utm_source=ext_app_menu)
