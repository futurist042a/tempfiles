# Common Dashboard

## Analysis
- Each application have Dashboard which includes both Task related and Business Data. In most cases, the Business data seems to be used more.
- In each dashboard also have a filter attributes added.
- There are drill down to each of the Dashboard data e.g. a Popup screen gets opened to view more details or do some actions.
- Each application have services to retrieve the data for the Dashboard.
- Few application have tabs on the Dashboard with different details.

Analysis Details:
- [USP Dashboard Headers](https://usbank-my.sharepoint.com/:x:/r/personal/kathleen_simba_usbank_com/_layouts/15/doc2.aspx?sourcedoc=%7Bdefae939-cb9c-45fd-bf3b-6588971189db%7D&action=edit&wdinitialsession=431c847c-3375-4e14-ac71-cdf0d442cc2b&wdrldsc=10&wdrldc=1&wdrldr=Save%2CEditModeCannotAcquireLockUnrecoverable)
- [Application Specific Dashboard Video](https://usbank.sharepoint.com/teams/DigitalBusinessAutomation/Shared%20Documents/Forms/AllItems.aspx?e=5%3A84c134878482490ab50fc20b0b2bcc33&at=9&RootFolder=%2Fteams%2FDigitalBusinessAutomation%2FShared%20Documents%2FCommon%20Framework%2FApplication%20Demos&FolderCTID=0x0120008E8FE7FE3CEA554D992B7F5EC9C5BDC5)

## Challenges/Queries in the Common Dashboard Design
- Identification of common data to be shown on the common dashboard i.e. there seems to be use of application specific data. 
	- Should we configure the data that needs to be shown in the Dashboard based on application.
	- How do we retrieve the data for each application? Service configured for each application?
- Should we keep it simple and only provide the link to the application specific Dashbaord and have it configured in the UO table.
	- Are we planning to replace the existing BAW Dashboard or use it in iFrame in USP
- The current UO tables could need changes to configure the Dashboard data.
- For the Common Dashboard should we restrict the number of attributes shown on the screen and have that configured for each application.- 

