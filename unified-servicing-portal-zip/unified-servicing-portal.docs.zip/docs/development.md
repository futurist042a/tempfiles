# Development

## Connecting to a new API endpoint

During development, there may be a disconnect between the backend team and the frontend, where you need to connect to an endpoint that has not been developed yet. For this reason (and for unit testing purposes) we have created a mock server using [msw](https://mswjs.io/docs) that will intercept requests to our external API and serve static content instead.

There are a few steps to follow when connecting to a new API endpoint:

1. Create a new environment variable with the relative path for the new endpoint using `npm run update-env-var`
2. Create a JSON file in `./src/stubs` with the response that you expect to get from this new endpoint
3. Create a handler for the mock server in [./src/mocks/handlers.js](./src/mocks/handlers.js)
   1. Follow the patterns used in the file, or refer to the [msw documentation](https://mswjs.io/docs/basics/request-handler)
   2. For graphql, make sure that the query has a name so it can be intercepted. See example in [./src/actions/dashboardTableAction.js](./src/actions/dashboardTableAction.js) or refer to the [msw documentation](https://mswjs.io/docs/api/graphql/query#basic-query)

To enable the mock server, set `ENABLE_MOCK_SERVER` to `true` in [./src/bootstrap.jsx](./src/bootstrap.jsx). The mock server will not be included in the production bundle, but **please make sure to return this value to `false` before committing!**

You can also change the user role in [./src/bootstrap.jsx](./src/bootstrap.jsx) by changing the value of `window.MOCK_USER_ROLE`.

## Derived state using selectors

This pattern has been seen in a few other projects:

```js
const { firstName, lastName } = useSelector((state) => state.user);

useEffect(() => {
  dispatch(
    updateFullName({ firstName, lastName })
  );
}, [firstName, lastName])
```

This is an anti-pattern, as we are relying on a component update to take data from Redux, modify it in some way, and store it in the Redux store. If we need the same updates elsewhere, we need to either duplicate the useEffect, or hoist the useEffect to a component higher in the tree. This approach also goes against the recommendations in the Redux docs:

> Keep the actual data in the Redux store as minimal as possible, and *derive additional values from that state as needed*.

For these reasons, we use selectors for any piece of state that is derived from the Redux store. You can find them in the [`src/selectors`](./src/selectors) folder. Some of them use [`createSelector`](https://redux-toolkit.js.org/api/createSelector), which comes from a library called [Reselect](https://github.com/reduxjs/reselect) and is available as an import from Redux Toolkit.

### Debugging selectors

One downside of using selectors is that they are not visible in Redux DevTools. To make debugging a bit easier, you can type `debugSelectors()` in the browser console, and this function will return an object containing the state of all selectors.

If a new file is added to the [`src/selectors`](./src/selectors) folder, please include it in [`src/initSelectorDebugger.js`](./src/initSelectorDebugger.js).
