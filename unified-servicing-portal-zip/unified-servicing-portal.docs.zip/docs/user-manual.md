# Unified Servicing Portal User Manual

Use this manual as a high level summary and resource for understanding the Unified Servicing Portal. This manual is intended for both technical and non-technical users

**NOTE:**
The Unified Servicing Portal expands on and uses resources from the Unified Onboarding (UO) team. For more information about Unified Onboarding, see their [knowledge transfer documents on Confluence.](https://confluence.us.bank-dns.com/pages/viewpage.action?spaceKey=DASC&title=Knowledge+Transfer+UO-+Harsha+Sidhwani)

## Content

- [Configuring Portal Via Database](#configuring-portal-via-database)
  - [First Time Setup](#first-time-setup)
    - [Common Objects](#common-objects)
    - [Table Headers](#table-headers)
    - [Milestones](#milestones)
  - [Runtime Process](#runtime-setup)
    - [Onboarding IDs](#onboarding-ids)
    - [Milestones](#milestones-1)
    - [Datapoints](#datapoints)
- [Backend](#backend)
  - [Domain API](#domain-api)
    - [Milestone Service](#milestone-service)
    - [Event Service](#event-service)
    - [BAW Common Object Service](#baw-common-object-service)
  - [Experience Layer](#experience-layer)
- [Frontend](#frontend)
  - [Main Screen](#main-screen)
  - [Stitching Layer](#stitching-layer)
    - [Ping Fed Authorization](#ping-fed-authorization)
    - [Unified Onboarding Federated Modules](#unified-onboarding-federated-modules)

## Configuring Portal via Database

This application uses the UO Database (USB_UO). See [updated details here.](https://confluence.us.bank-dns.com/pages/viewpage.action?spaceKey=DASC&title=Unified+Onboarding+Database+Details)

### First Time Setup

#### Common Objects

Common Objects are objects that can be used by every application in the portal. Common Objects can include client name, account name, and product line.

Unified Servicing uses a Common Object structure created by the UO Team. See the [JSON structure here.](https://confluence.us.bank-dns.com/display/DASC/Common+Object+Details+Version+1)

Common Object configuration is in [USB_UO].[dbo].[refs] with typeid 161.

<details open>
    <summary>To access the Common Objects table, use the following SQL query:</summary>

```SQL
SELECT * FROM [USB_UO].[dbo].[refs] WHERE typeid = 161;
```

</details>

Common object refs table
![typeid_161](./typeid_161.png)

##### Common Object Table Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|typeid|Specifies the component ID|161|
|typename|Specifies the component name|CommonDashboardEvent|
|name|Plain name of common parent object|ClientDetails, AccountDetails, ...|
|string1|Reference name of common object parent|ClientDetailsInfo, AccountInfo, ...|
|string3|Path of common child object|clientDetails-legalName, accountDetails-accountNumber|
|string4|Datapoint address of common child object|@dp.clientDetails-legalName, @dp.accountDetails-accountNumber|

##### Common Object Example

Common objects are JSON objects.

<details open>
    <summary>Example Blank Common Object (client details)</summary>

```JSON
  "clientDetails": {
          "legalName": "",
          "EIN": "",
          "LEI": "",
          "LPID": "",
          "address": {
            "addressLine1": "",
            "addressLine2": "",
            "city": "",
            "state": "",
            "zipCode": "",
            "country": ""
          }
```

</details>

Each field within the object (legalName, EIN, LEI, etc.) will correspond to an individual datapoint entry. To understand datapoint configuration, jump to [datapoints.](#datapoints)

**Note:**
Users are not required to configure/update the Common Object table.

[Top](#content)

#### Table Headers

Unified Servicing stores table headers in [USB_UO].[dbo].[refs].

<details open>
    <summary>To access the Unified Servicing Portal table headers, use the following query:</summary>

```SQL
SELECT TOP (1000) * FROM [USB_UO].[dbo].[refs] WHERE typeid = 27 AND string1 = 'unifiedServicingPortal';
```

</details>

Unified Servicing Portal table headers:
![usp_tableheaders](./usp_tableheaders.png)

##### Table Headers Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|typeid|Specifies the component ID|27|
|typename|Specifies the component name|TableHeader|
|name|Specifies table name|My_Tasks|
|sortorder|Determines order of which the object is returned|
|string3|Specifies the plain name of the table header|Client Legal Name, Business Line, ...|
|string4|Specifies the path of the common child object|clientDetails-legalName, productDetails-productFamily|

##### Adding to Table Headers

To configure table headers for your businessline, user must add to [USB_UO].[dbo].[refs] where typeid = 27.

<details open>
    <summary>To add table headers into the refs table, use the following SQL query script (change @tablename as needed):</summary>

```SQL
DECLARE @tablename AS VARCHAR(3000) = 'table name'

INSERT INTO [USB_UO].[dbo].[refs] (typeid,
  typename,
  name,
  sortorder,
  string1,
  string2,
  string3,
  string4,
  string5,
  string6,
  string7,
  string8,
  string9,
  string10,
  string11
  ,String12)
  values (27,
  'TableHeader',
  @tablename,
  1,
  'unifiedServicingPortal',
  '',
  'Date Send',
  'dateSend',
  'TRUE',
  '["Oldest", "Newest"]',
  'specialCellType',
  'MM/DD/YYYY',
  '16%',
  '',
  'TRUE',
  'date')

```

</details>

[Top](#content)

#### Milestones

Milestones are defined as servicing events that can consist of multiple tasks.

During first time setup, milestones are added to [USB_UO].[dbo].[refs] under typeid 16.

##### refs Milestones Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|typeid|Specifies the component ID|16|
|typename|Specifies the component name|Milestones|
|name|Specifies milestone name|Account open, Document submission, ...|
|sortorder|Determines order of which the object is returned|
|string1|Specifies the business line, should be unique for each process|ITC, DPG, ...|
|string2|Inital status of the milestone i.e. status when the milestone is created|Yes|

The sample configuration for the businessline DPG is provided below for reference.

![Alt text](image-66.png)

##### Adding to refs Milestone

To configure milestones for your businessline, user must add to [USB_UO].[dbo].[refs] where typeid = 16.

<details open>
    <summary>To add a milestone into the refs table, use the following SQL query script (change @milestonename, @sortorder, @businessline as needed):</summary>

```SQL
DECLARE @milestonename AS VARCHAR(3000) = 'milestone name'
DECLARE @sortorder AS INT = 1
DECLARE @businessline AS VARCHAR(3000) = 'business line'

INSERT INTO [USB_UO].[dbo].[refs] (typeid,
  typename,
  name,
  sortorder,
  string1,
  string2)
  values (16,
  'Milestones',
  @milestonename,
  @sortorder,
  @businessline,
  'Not started')

```

</details>

### Runtime Setup

#### Onboarding IDs

Onboarding IDs are automatically generated for each BPM instance and can be found in [USB_UO].[dbo].[uo_onboarding]

##### uo_onboarding Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|id|Unique identifier, referenced as onboarding_id in other tables|
|baw_instance_id|Instance ID taken from IBM BPM|
|business_line|Specifies the business line these records correspond to|CT, CCB|

##### Generating Onboarding IDs

To generate onboarding IDs, use the [saveUoOnboarding method](#saveuoonboarding).

[Top](#content)

#### Milestones

For every BPM instance, the milestone and any changes to its status are retrieved from [USB_UO].[dbo].[refs] and added into [USB_UO].[dbo].[uo_milestone].

##### uo_milestone Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|onboarding_id|References corresponding id from [USB_UO].[dbo].[uo_onboarding]|
|name|Specifies milestone name, references name from refs table|Account open, Document submission, ...|
|status|Specifies status of milestone for a specific onboarding_id|
|details|JSON object storing details of this milestone|

##### Adding milestones to uo_milestone

To add milestones for an instance into uo_milestones, use the [saveAllMilestone method](#saveallmilestone).

##### Updating milestone status in uo_milestone

To update milestones for an instance, use the [updateMilestone](#updatemilestone).

[Top](#content)

#### Datapoints

All datapoints of each BPM instance are stored in [USB_UO].[dbo].[uo_datapoint].

<details open>
    <summary>To access Unified Servicing datapoints, use the following query:</summary>

```SQL
SELECT TOP(1000) * FROM [USB_UO].[dbo].[uo_datapoint] WHERE source_system = 'unifiedServicingPortal';
```

</details>

##### uo_datapoint Structure

|Column Name|Description|Examples|
|-----------|-----------|--------|
|source_system|Specifies the application/product line the datapoint is coming from|UO, unifiedServicingPortal, ...|
|onboarding_id|References corresponding id from [USB_UO].[dbo].[uo_onboarding]|
|source_system_dp_id|References the path of the common child|clientDetails-legalName, productDetails-productFamily|

##### Datapoint Example

![example_datapoint](./example-datapoint.png)

The image above shows 3 datapoints from 3 different onboarding IDs. These datapoints show the client name (seen under the 'value' column).

##### Adding datapoints to the datapoint table

To add datapoints to the datapoint table, use the [saveDataPoints method.](#savedatapoints)

[Top](#content)

## Backend

### Domain API

*Owned by the UO team*

Access this API by downloading the Postman collection from this [link](Domain-API.postman_collection.json)

Domain API Services & Methods:

- [Milestone Service](#milestone-service)
  - [saveAllMilestone](#saveallmilestone)
  - [updateMilestone](#updatemilestone)
- [Event Service](#event-service)
  - [saveUoOnboarding](#saveuoonboarding)
- [BAW Common Object Service](#baw-common-object-service)
  - [saveDataPoints](#savedatapoints)

[Top](#content)

#### Milestone Service

The uo-milestone-service provides different operations to manage the UO milestone data. Below are the different methods that are provided as part of milestone service which will be used by IBM BAW.

|Environment|Base URL|
|-----------|--------|
|Dev|<https://dev-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/milestone-service/|>
|IT|<https://it-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/milestone-service/|>
|UAT|<https://uat-unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/milestone-service/|>
|PROD|<https://unifiedonboarding.us.bank-dns.com/api/onboarding/corp-apply/milestone-service/|>

##### saveAllMilestone

The save all milestone creates all the milestones related to a businessline.

All the milestones related to the businessline should be preconfigured in the refs table with typeId 16. The details of the refs table configuration are [here.](#refs-milestones-structure)

###### Request

|Method|URL|
|------|---|
|POST|/v1/milestone|

|Query String Params|Description|Example|
|-------------------|-----------|------|
|onboardingId|Specify the onboardingId created in uo_onboarding for the instance|43578|
|businessLine|Specify the business line for the process and configured in Refs table(typeid 16)|DPG|

<details open>
    <summary>Request Payload (JSON)</summary>

```text
Payload not required for this request
```

</details>

###### Response

|Status|Response|
|------|--------|
|201|JSON response with Array of milestone created|
|400|Bad Request|
|401|Unauthorized|

<details open>
    <summary>Sample response</summary>

```JSON
[
    {
        "createdBy": "c080842",
        "createdDate": "2024-01-31 13:33:04",
        "modifiedBy": "c080842",
        "modifiedDate": "2024-01-31 13:33:04",
        "id": "ca9adfd7-82e5-457b-a9fd-e72e562de517",
        "onboardingId": 43578,
        "businessLine": "fx",
        "name": "FX customer profile",
        "status": "In progress",
        "startDate": "2024-01-31T13:33:04.405738048",
        "completionDate": null,
        "details": "{\"onboardingId\":43578,\"businessLine\":\"fx\",\"name\":\"FX customer profile\",\"status\":\"In progress\",\"startDate\":\"2024-01-31T13:33:04.405738048\",\"sortOrder\":1}",
        "sortOrder": 1,
        "workflowId": null
    }]
```

</details>

[Top](#content)

[Domain API](#domain-api)

##### updateMilestone

Use this API to update the milestone status based on the onboardingId and instanceId.

###### Request

|Method|URL|
|------|---|
|PUT|/v1/milestone|

|Query String Params|Description|Example|
|-------------------|-----------|------|
|onboardingId|Specify the onboardingId |43578|
|instanceId|Specify the BAW instance id|288606|

<details open>
    <summary>Request Payload (JSON)</summary>

```JSON
{
    "name": "Milestone name",
    "status": "Completed"
}
```

</details>

*Note:*

- name: should be the milestone name for which the status needs to be updated.
- status: updated status of the milestone. The status can be 'In progress' / 'Not started' / 'Completed' / 'Approved'

###### Response

|Status|Response|
|------|--------|
|201|JSON response with milestone updated|
|400|Bad Request|
|401|Unauthorized|

<details open>
    <summary>Sample response</summary>

```JSON
{
    "createdBy": "c080842",
    "createdDate": "2024-01-31 09:23:51",
    "modifiedBy": "c080842",
    "modifiedDate": "2024-01-31 09:36:22",
    "id": "8e93fed4-14a9-434d-9c84-56941722fa90",
    "onboardingId": 143558,
    "businessLine": "fx",
    "name": "FX customer profile",
    "status": "Completed",
    "startDate": "2024-01-31T09:23:51.051737143",
    "completionDate": null,
    "details": "{\"createdBy\":\"c080842\",\"createdDate\":\"2024-01-31 09:23:51\",\"modifiedBy\":\"c080842\",\"modifiedDate\":\"2024-01-31 09:23:51\",\"id\":\"8e93fed4-14a9-434d-9c84-56941722fa90\",\"onboardingId\":143558,\"businessLine\":\"fx\",\"name\":\"FX customer profile\",\"status\":\"Completed\",\"startDate\":\"2024-01-31T09:23:51.051737143\",\"sortOrder\":1}",
    "sortOrder": 1,
    "workflowId": null
}
```

</details>

[Top](#content)

[Domain API](#domain-api)

#### Event Service

The uo-event-service provides different operations to manage UO onboarding and datapoint data. Below are the different methods that are provided as part of event service which will be used by IBM BAW.

##### saveUoOnboarding

Use this method to generate an onboarding ID for a BAW instance.

###### Request

|Method|URL|
|------|---|
|POST|/v4/saveUoOnboarding|

|Query String Params|Description|Example|
|-------------------|-----------|-------|
|businessLine|Specify the business line|CCB|
|bawInstanceId|Specify the BAW instance id|288606|
|formAction|Specify the form action|submit|
|performedByUserId|Specify the user (using USB id)|c080842|
|formName|Specify the name of the form (can leave this unchanged)|formName|

<details open>
    <summary>Request Payload (JSON)</summary>

```text
Payload not required for this request
```

</details>

###### Response

|Status|Response|
|------|--------|
|201|JSON response with onboarding ID generated|
|400|Bad Request|
|401|Unauthorized|

<details open>
    <summary>Sample Response</summary>

```JSON
{
    "onboardingId": 44105,
    "instanceId": "288606",
    "bpmStatus": null
}
```

</details>

[Top](#content)

[Domain API](#domain-api)

#### BAW Common Object Service

##### saveDataPoints

Use this method to generate datapoint records in [USB_UO].[dbo].[uo_datapoint] for an onboarding ID.

###### Request

|Method|URL|
|------|---|
|POST|/v1/datapoint|

|Query String Params|Description|Example|
|-------------------|-----------|-------|
|onboardingId|Specify the onboarding ID|43578|

<details open>
    <summary>Request Payload (JSON)</summary>

```JSON
{
    "clientDetails": {
        "legalName": "Legal Name",
        "EIN": "EIN Value",
        "LEI": "LEI Value",
        "LPID": "LPID Value",
        "contactDetails": {
            "businessPhoneNumber": "0000000000",
            "email": "test@mailtest.com"
        }
    },
    "productDetails": {
        "productName": "Product Name",
        "productType": "Product Type",
        "productFamily": "Product Family"
    }
}
```

</details>

*Note:*

- JSON follows [Common Object model](#common-object-example).
- Product name should be application name (example: CCBLW)
- Product type should be onboarding/servicing
- Product family should be business line (example: Corporate and Commercial Banking)

###### Response

|Status|Response|
|------|--------|
|201|JSON response with datapoints inputted into [USB_UO].[dbo].[uo_datapoint]|
|400|Bad Request|
|401|Unauthorized

<details open>
    <summary>Sample Response</summary>

```JSON
[
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            683000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            653926055
        ],
        "id": "662372a3-7222-4cf7-8aa0-51b2c9618c49",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-EIN",
        "object": false,
        "value": "EIN Value",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            693000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            661439261
        ],
        "id": "2c3fe628-0830-44e7-9ff6-10d3d3bf4de0",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "productDetails-productName",
        "object": false,
        "value": "Product Name",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            697000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            667864860
        ],
        "id": "d1d4b955-dec1-4a88-8b77-2df26e6e9549",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "productDetails-productType",
        "object": false,
        "value": "Product Type",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            700000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            674961962
        ],
        "id": "7228fc33-8222-4df6-a2a9-94d68f1e8456",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-legalName",
        "object": false,
        "value": "Legal Name",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            707000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            680472186
        ],
        "id": "bc0adfb6-6683-4bb5-b7d1-58537479489a",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-contactDetails-email",
        "object": false,
        "value": "test@mailtest.com",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            710000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            685559932
        ],
        "id": "2fd35280-3f70-4a8d-825c-b13634453795",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "productDetails-productFamily",
        "object": false,
        "value": "Product Family",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            713000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            690784397
        ],
        "id": "c21bcc4a-68b8-4ad7-8a45-59f9790f5824",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-LEI",
        "object": false,
        "value": "LEI Value",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            717000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            696147773
        ],
        "id": "1a98ca94-8bce-4450-bbef-cc701f9be4d5",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-contactDetails-businessPhoneNumber",
        "object": false,
        "value": "0000000000",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    },
    {
        "createdBy": "c080842",
        "createdDate": [
            2024,
            2,
            6,
            11,
            26,
            23,
            723000000
        ],
        "modifiedBy": "c091082",
        "modifiedDate": [
            2024,
            2,
            6,
            20,
            31,
            38,
            702477246
        ],
        "id": "2a8ae2e2-3ca5-40f2-91f4-7e26c915fd93",
        "sourceSystem": "unifiedServicingPortal",
        "sourceSystemDpId": "clientDetails-LPID",
        "object": false,
        "value": "LPID Value",
        "modifiedBySystem": "unifiedServicingPortal",
        "advisorId": null,
        "fundId": null,
        "classId": null,
        "checklistId": null,
        "checklistCompletionValue": null,
        "previousChecklistCompletionValue": null,
        "checklistOnchangeTrigger": null,
        "objValue": null,
        "version": 1,
        "pageName": null,
        "required": null
    }
]
```

</details>

[Top](#content)

[Domain API](#domain-api)

### Experience Layer

The Experience layer provides the enter point for the front end to access the backend system in addition to the Domain API. Below are the different methods that are provided as part of experience layer which will be used by frontend.

|Environment|BaseURL|
|-----------|-------|
|DEV|<https://portal.usp.ba.nonprod.aws.cloud.bank-dns.com/api/onboarding/corp-apply/usp-service|>

#### GetCommonOnBoardingEvent

This method provides an graphql API to rerieve the Common Onboarding Event based on the Onboarding type and Onboarding Id.

This API will be used at the frontend dashboard to display the Process and Task details.

##### GraphQl Schema

<details open>
    <summary>The GraphQl request will be based on the below Schema definition, this aligns with the Common Object structure.</summary>

```GraphQl
type CommonOnBoardingEvent{
    clientDetails:ClientDetails
    accountDetails:AccountDetails
    onboardingTeam:OnboardingTeam
    processDetails:ProcessDetails
    beneficialOwnerList:[BeneficialOwner]
    productDetails:ProductDetails
    kycDetails:KycDetails
    idpDetails:IdpDetails
}

type ClientDetails{
    onboardingId:String
    legalName:String
    businessLine:String
    EIN:String
    LEI:String
    LPID:String
    address:Address
    contactDetails:ContactDetails
    dbaList:[DBA]
    additionalDetails:AdditionalDetails
}

type DBA{
    dbaName:String
    address:Address
}

type Address{
    addressLine1:String
    addressLine2:String
    city:String
    state:String
    zipCode:String
    country:String
}

type ContactDetails{
    businessPhoneNumber:String
    email:String
}

type AdditionalDetails{
    countryOfFormation:String
    countryOfPrimaryBusinessOperations:String
    estimatedOrProjectedAnnualRevenue:String
    hasAnyDBA:String
    legalStructure:String
    naicsCode:String
    purposeOfAccount:String
    offerCheckCashingServices:String
}

type AccountDetails{
    accountNumber:String
    accountName:String
    accountType:String
}

type OnboardingTeam{
    relationshipManager:String
    role1:String
    role2:String
    role3:String
    role4:String
    role5:String
}

type ProcessDetails{
    instanceId:String
    workFlowStatus:String
    targetOnboardingCompletionDate:String
    createdBy:String
    mileStoneTracker:[MileStoneTracker]
    taskDetails:[TaskDetails]
}

type MileStoneTracker{
    mileStoneName:String
    status:String
    updateDate:String
}

type TaskDetails{
    taskId:String
    taskName:String
    instanceId:String
    status:String
    assignedTo:String
    modifiedBy:String
    modifiedDate:String
    taskURL:String
}

type BeneficialOwner{
    address:Address
    dateOfBirth:String
    identificationNumber:String
    firstName:String
    middleName:String
    lastName:String
    ownershipPercentage:String
}

type ProductDetails{
    productName:String
    productType:String
    productFamily:String
}

type KycDetails{
    kycId:String
    policyYear:String
    formType:String
    status:String
}

type IdpDetails{
    status:String
    mitigationReason:String
    comments:String
}
```

</details>

##### Request

|Method|URL|
|------|---|
|POST|/graphql|

<details open>
    <summary>Sample GraphQl Request Payload</summary>

```GraphQl
{   commonOnBoardingEvent(onboardingType: "CCB",onboardingId:""){
  clientDetails{
   onboardingId
   legalName
   EIN
   LEI
   LPID
   additionalDetails{
    countryOfFormation
    countryOfPrimaryBusinessOperations
    estimatedOrProjectedAnnualRevenue
    hasAnyDBA
    legalStructure
    naicsCode
    purposeOfAccount
    offerCheckCashingServices
   }
  }
  accountDetails{
   accountNumber
   accountName
   accountType
  }
  onboardingTeam{
   relationshipManager
   role1
  }
  processDetails{
   instanceId
   mileStoneTracker{
    mileStoneName
    status
   }
   taskDetails{
    taskId
    taskName
    taskURL
   }
  }
  productDetails{
   productName
   productType
   productFamily
  }
 }
}
```

</details>

###### Response

|Status|Response|
|------|--------|
|201|JSON response with Common Onboarding Event|
|400|Bad Request|
|401|Unauthorized|

<details open>
    <summary>Sample Response</summary>

```JSON
{
    "data": {
        "commonOnBoardingEvent": [
            {
                "clientDetails": {
                    "onboardingId": "36171",
                    "legalName": "Full Name",
                    "EIN": "EIN 36171",
                    "LEI": "LEI 36171",
                    "LPID": "",
                    "additionalDetails": {
                        "countryOfFormation": "",
                        "countryOfPrimaryBusinessOperations": "",
                        "estimatedOrProjectedAnnualRevenue": "",
                        "hasAnyDBA": "",
                        "legalStructure": "",
                        "naicsCode": "",
                        "purposeOfAccount": "",
                        "offerCheckCashingServices": ""
                    }
                },
                "accountDetails": {
                    "accountNumber": "",
                    "accountName": "",
                    "accountType": ""
                },
                "onboardingTeam": {
                    "relationshipManager": "rm name",
                    "role1": "onboarding role"
                },
                "processDetails": {
                    "instanceId": "499261",
                    "mileStoneTracker": [
                        {
                            "mileStoneName": "New account initiation",
                            "status": "Completed"
                        },
                        {
                            "mileStoneName": "Derivatives customer profile",
                            "status": "Approved"
                        },
                        {
                            "mileStoneName": "KYC Documentation",
                            "status": "Not started"
                        },
                        {
                            "mileStoneName": "ISDA",
                            "status": "Completed"
                        },
                        {
                            "mileStoneName": "Credit Limit approval",
                            "status": "In progress"
                        },
                        {
                            "mileStoneName": "Dodd Frank Packet",
                            "status": "Not started"
                        },
                        {
                            "mileStoneName": "Green light memo",
                            "status": "Not started"
                        }
                    ],
                    "taskDetails": [
                        {
                            "taskId": "3290397",
                            "taskName": "Submit Account Maintenance Changes",
                            "taskURL": "https://ebpm-dev.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=3290397"
                        }
                    ]
                },
                "productDetails": {
                    "productName": "CCBLW",
                    "productType": "Onboarding",
                    "productFamily": "Corporate and Commercial Banking"
                }
            },
            {
                "clientDetails": {
                    "onboardingId": "36170",
                    "legalName": "Full Name",
                    "EIN": "EIN 36170",
                    "LEI": "LEI 36170",
                    "LPID": "",
                    "additionalDetails": {
                        "countryOfFormation": "",
                        "countryOfPrimaryBusinessOperations": "",
                        "estimatedOrProjectedAnnualRevenue": "",
                        "hasAnyDBA": "",
                        "legalStructure": "",
                        "naicsCode": "",
                        "purposeOfAccount": "",
                        "offerCheckCashingServices": ""
                    }
                },
                "accountDetails": {
                    "accountNumber": "",
                    "accountName": "",
                    "accountType": ""
                },
                "onboardingTeam": {
                    "relationshipManager": "rm name",
                    "role1": "onboarding role"
                },
                "processDetails": {
                    "instanceId": "498708",
                    "mileStoneTracker": [
                        {
                            "mileStoneName": "Derivatives customer profile",
                            "status": "Approved"
                        },
                        {
                            "mileStoneName": "KYC Documentation",
                            "status": "Not started"
                        },
                        {
                            "mileStoneName": "ISDA",
                            "status": "Completed"
                        },
                        {
                            "mileStoneName": "Credit Limit approval",
                            "status": "In progress"
                        },
                        {
                            "mileStoneName": "Dodd Frank Packet",
                            "status": "Not started"
                        },
                        {
                            "mileStoneName": "Green light memo",
                            "status": "Not started"
                        }
                    ],
                    "taskDetails": [
                        {
                            "taskId": "3288200",
                            "taskName": "Exception Handler for System Tasks",
                            "taskURL": "https://ebpm-dev.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=3288200"
                        },
                        {
                            "taskId": "3288197",
                            "taskName": "Pending Form (FA)",
                            "taskURL": "https://ebpm-dev.us.bank-dns.com/ProcessPortal/launchTaskCompletion?taskId=3288197"
                        }
                    ]
                },
                "productDetails": {
                    "productName": "CCBLW",
                    "productType": "Onboarding",
                    "productFamily": "Corporate and Commercial Banking"
                }
            }
        ]
    }
}
```

</details>

[Top](#content)

[Experience Layer](#experience-layer)

## Frontend

Frontend Content:

- [Main Screen](#main-screen)
  - [Expanded Process](#expanded-process)
    - [Completed Tasks List](#completed-tasks-list)
  - [Filter Dropdown Checklist](#filter-dropdown-checklist)
    - [Filtered Main Screen](#filtered-main-screen)
- [Stitching Layer](#stitching-layer)
  - [Ping Fed Authorization](#ping-fed-authorization)
  - [UO Federated Modules](#unified-onboarding-federated-modules)

### Main Screen

![main_screen](./main-screen.png)

Display Elements (in orange)
|Number|Description|Data Source|
|------|-----------|-----------|
|1|Table Headers|Table header data is sourced from [USB_UO].[dbo].[refs] where typeid = 27|
|2|Status Bar|Array of completed & approved milestones / total milestones. Milestones are sourced from [common object](#common-objects).|
|3|Datapoints|Datapoints are sourced from [USB_UO].[dbo].[uo_datapoint]|

Action Elements (in red)
|Number|Description|Action|
|------|-----------|------|
|1|Filter objects dropdown|[Show filter dropdown checklist](#filtered-main-screen)|
|2|Expand process arrow|[Show process details](#expanded-process) (Milestone and completed task details)|

[Top](#content)

[Frontend](#frontend)

#### Expanded Process

![expanded_process](./expanded-process.png)

Display Elements (in orange)
|Number|Description|Data Source|
|------|-----------|-----------|
|1|Milestone details|Individual milestones and statuses are sourced from [USB_UO].[dbo].[uo_milestone]|

Action Elements (in red)
|Number|Description|Action|
|------|-----------|------|
|1|Completed task list|[Show completed task details](#completed-tasks-list)|

[Top](#content)

[Frontend](#frontend)

##### Completed Tasks List

![completed_tasks](./completed-tasks.png)

Display Elements (in orange)
|Number|Description|Data Source|
|------|-----------|-----------|
|1|Completed task details|Completed tasks are sourced from process details [common object](#common-objects).|

[Top](#content)

[Frontend](#frontend)

#### Filter Dropdown Checklist

![filter_dropdown_unchecked](./filter-dropdown-unchecked.png)

Display Elements (in orange)
|Number|Description|Data Source|
|------|-----------|-----------|
|1|Filter checklist|Check one/more checkboxes to filter what displays on the table. User can filter by Active instance, Corporate Trust instances, and/or Corporate and Commercial banking instances.|

[Top](#content)

[Frontend](#frontend)

##### Filtered Main Screen

![filter-dropdown-checked](./filter-dropdown-checked.png)

Action Elements (in red)
|Number|Description|Action|
|------|-----------|------|
|1|Check box to filter processes shown|Show filtered processes|

[Top](#content)

[Frontend](#frontend)

### Stitching Layer

*Owned by the Unified Servicing team, built on React*

This layer was built using a template from the UO team. Using this template gives our team access to UO and SHIELD components.

This layer:

- obtains authentication for the user
- gathers and displays common objects in one table

#### Ping Fed Authorization

This is used to get authorization tokens.

Details to come.

#### Unified Onboarding Federated Modules

*Owned by UO team*

This is used to get table components. Changes made by the UO team will be propagated to all applications that use these components.

[Top](#content)

[Frontend](#frontend)
