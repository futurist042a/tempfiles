# Setup React Project in Visual Studio Code

## Clone the unified-servicing-portal project 
- Clone the unified-servicing-portal project from the [gitlab](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal.git)
	- Click on '
Visual Studio Code (HTTPS)' as shown in the below screen shot.
![Alt text](image-67.png)
    - This will launch the Visual Studio IDE and launch the windows explore to select the folder in which the project needs to be cloned.
    - Select the folder.
    - Enter the username to login 
    ![Alt text](image-68.png)
    - Enter the password
    ![Alt text](image-69.png)
    - Click 'Open' to open the cloned project in the Visual Studio
    ![Alt text](image-70.png)

## Select the Project type to load
- The default cloned repository will load the main branch but select the correct branch mentioned below the respective project. 
    Project Type        |  Branch Name          | Describition 
    ------------------- | --------------------- | --------------------- 
    UI Editor           | ui_editor_v3          | UI Editor Project Code
    USB Page Library    | usbPage_Lib           | Library project for USPage
    Render UI Library   | renderUI_Lib          | Library Project for Render UI 
    Account Intake      | account_intake_poc    | Account Intake POC project to test both the libraries
    Web Server          | appBuilderWebServer   | AppBuilder Web Server to store the jsFunction and css
_Note: To setup local environment, setup Ui Editor and Web Server_

- To select the branch in Visual Studio, click on the current gitlab branch in the bottom left corner of the Visual Studio as shown below.
![Alt text](image-71.png)
- The above action, will list all the branch as shown below.
![Alt text](image-72.png)
- Select origin/ui_editor_v3 to load the UI Editor code.
![Alt text](image-73.png)
- Repeat the above steps to load other project type as required. 

### UI Editor: Build and run the project
Follow the steps below to build and execute the UI Editor project.
- Make sure you have node.js installed in the machine, else raise a request to get Node.js installed before executing the below steps.
- Launch the terminal by navigating to View -> Terminal as shown below
![Alt text](image-74.png)
- In the Terminal select PowerShell as shown below.
![Alt text](image-75.png)
- Execute the below command to install all the dependencies for this project.
```npm install -f```
![Alt text](image-76.png)
- The installation could take few minutes to completed. This will create the node_modules in the project as shown below.
![Alt text](image-77.png)
- To start the application, execute the below command as shown below
```npm run dev```
- The command will execute for few seconds and the application will be ready to access.
![Alt text](image-79.png)
- Access the UI Editor through the URL: [http://localhost:5031/usp/home/ui-editor](http://localhost:5031/usp/home/ui-editor)

### AppBuilder Web Server: Build and run the project
Follow the steps below to run the AppBuilder Web Server.
- Make sure you have node.js installed in the machine, else raise a request to get Node.js installed before executing the below steps.
- Launch the terminal by navigating to View -> Terminal as shown below
![Alt text](image-89.png)
- In the Terminal select PowerShell as shown below.
![Alt text](image-90.png)
- Execute the below command to run the Web Server
```node appBuilderServer.js```
- The command will show that the server is listening on the 3000 port
![Alt text](image-91.png)