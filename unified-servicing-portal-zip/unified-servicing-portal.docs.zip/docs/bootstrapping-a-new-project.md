# Bootstrapping a new project

Since this is a template, there are a number of things you need to change before your new project is ready for development.

## 1. Request authentication URLs

If you run this template as-is, you will notice an authentication error. This is because `http://localhost:5031/template/home` has not been registered as a valid redirect_url in PingFed, our OAuth service.

In order to be able to run your app, you will need to file a request in ServiceNow, under [Information Security Authentication Services](https://itsmnow.service-now.com/mytech?id=sc_cat_item&table=sc_cat_item&sys_id=ef8644b01b938154dc77ecaa234bcbed).

Enter these details:

|                 |                                             |
|-----------------|---------------------------------------------|
| Primary Contact | **(your name)**                             |
| CAR ID          | **Unified Onboarding** (8531)               |
| Business Line   | **Wealth Management & Investment Services** |

Under **Describe Your Request Needs**, enter this description, replacing <strong style="color: #09f">port</strong> and <strong style="color: #f09">business-line</strong> appropriately. (See more details about this in the sections about HOME_PATH and port number).

<pre>
Please add the redirect URLs below for our application's integration with PingFed:

clientId: IBMBAW

http://localhost:<strong style="color: #09f">port</strong>/<strong style="color: #f09">business-line</strong>/home
http://localhost:<strong style="color: #09f">port</strong>/<strong style="color: #f09">business-line</strong>/home/callback
http://localhost:<strong style="color: #09f">port</strong>/<strong style="color: #f09">business-line</strong>/home/silent_renew

http://dev-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home
http://dev-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home/callback
http://dev-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home/silent_renew

http://it-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home
http://it-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home/callback
http://it-unifiedonboarding.us.bank-dns.com/<strong style="color: #f09">business-line</strong>/home/silent_renew
</pre>

In the future, you will need to file another request for UAT, and another for DR and Prod, but the process is a little more complicated and out of the scope of this document. Check Confluence for more info.

## 2. Enter your credentials in .npmrc

1. Ask your manager to unlock your credentials in JFrog Artifactory. This may take a few minutes.
2. Once unlocked, go to [https://artifactory.us.bank-dns.com/artifactory/webapp/#/home](https://artifactory.us.bank-dns.com/artifactory/webapp/#/home) and log in.
3. In the "Set Me Up" section, filter by **UX-Shield-Design-System-NPM-release-local** and click on the search result.
4. Enter your password in the modal to generate the code snippets.
5. Copy the values of `_auth` and `_password`.
6. Edit the `.npmrc` file, replacing the values of `_auth`, `_password`, `username` and `email` according to your credentials.

## 3. Change the HOME_PATH variable

The `HOME_PATH` environment variable represents the root of your app. The pattern that is commonly followed in other projects is `/{business-line}/home`. For example, the DPG project uses `/usp/home`, whereas Money Center uses `/money-center/home`. **The leading slash is important!**

This needs to be changed in a number of files, but it's easy using `npm run update-env-var`.

## 4. Find and replace "template"

There are a lot of files where we need to change the word "template" to the name of your business line. Here's a breakdown of all strings on which you should perform a global find and replace (**case sensitive**):

- `template-stitching-layer` -> the name of your repo
- `templatestitchinglayer` -> the name of your repo without dashes
- `template-service` -> part of the path for your backend service
- `template/home` -> the value of your HOME_PATH variable without the leading slash
- `TEMPLATE_STITCHING_LAYER` -> the name of your repo in SCREAMING_SNAKE_CASE
- `InitiateOnboardingTemplate` -> `InitiateOnboarding` plus the name of your business line in PascalCase
- `initiateOnboardingTemplate` -> `initiateOnboarding` plus the name of your business line in camelCase
- `"template"` -> the name of your business line in quotes. Lots of endpoints take in the business line name as a parameter, and on the front end we should *always* use the BUSINESS_LINE variable for that.

## 5. Choose a port number for development

In order for authentication to work for your project, you should decide which port number to use for local development. The default is 5031. You can pick a port number that's already used by another project, but you will not be able to run two projects that share a port number at the same time.

As of writing, these are the port numbers used by various projects:

project                      | port |
-----------------------------|------|
onboarding-portal            | 3000 |
fs-client-ui                 | 5000 |
dpg-stitching-layer          | 5031 |
gct-stitching-layer          | 5031 |
itc-stitching-layer          | 5031 |
money-center-stitching-layer | 5031 |
onboarding-employee-portal   | 5031 |
fx-stitching-layer           | 5033 |
pt-stitching-layer           | 5041 |
money-center-client-portal   | 5045 |
fbo-stitching-layer          | 5046 |
collaboration-portal         | 5046 |
corporate-commons            | 5047 |
onboarding-client-portal     | 8000 |

**If you choose to change the port number, update `webpack.development.js` and `docker-compose.yml`**
