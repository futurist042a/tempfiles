# USP Experience API - Building Docker Image
To build the Docker image, the usp-exp-api jar file is required as the first step. Refer the document [creating usp-exp-api package](setup-experience-api-project.md#user-content-creating-the-package) for the steps.

## Create Dockerfile

Docker builds images by reading instructions in dockerfiles. The Dockerfile used to create the image is provided below.

This [dockerfile](https://gitlab.us.bank-dns.com/axsult1/usp-exp-api/-/blob/main/Dockerfile) is also part of the usp-exp-api project in gitlab.

```
# Start with a base image of OpenJDK
FROM artifactory.us.bank-dns.com:5000/usb/eclipse-temurin-jdk17:v_1.0.0

# Add a volume pointing to /home
VOLUME /home

# Set the working directory in the container
WORKDIR /home

# The application's jar file
ARG JAR_FILE=usp-exp-api-1.0.1-SNAPSHOT.jar

# Add the application's jar to the container
# ARG artifactoryUser
# ARG artifactoryPassword
# ADD --chown=appuser https://$artifactoryUser:$artifactoryPassword@artifactory.us.bank-dns.com:443/artifactory/unified-onboarding-maven-snapshot-local/com/usbank/wm/boilerplate-service/boilerplate-exp-api/1.0.0-SNAPSHOT/boilerplate-exp-api-1.0.0-SNAPSHOT.jar /home/boilerplate-exp-api.jar

# Copy the jar and trust store in the container
COPY ${JAR_FILE} usp-exp-api.jar
COPY cacerts cacerts

# Make port 8080 available to the world outside this container
EXPOSE 8080

# Run the jar file
ENTRYPOINT ["java","-Djavax.net.ssl.trustStore=cacerts","-jar","usp-exp-api.jar","--spring.profiles.active=local"]

```

## Build the Docker Image
The steps provided below can be executed from any machine which have the docker installed and have access to the artifactory.us.bank-dns.com. 

For creating this image, the Ec2 instance (BAW Linux POC - 10.87.97.132) was used. 

The document [Connect to Bastion server using putty](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/HowToSetupBastionServerAndConnect.md#connect-to-bastion-server-using-putty) provides the steps required to connect to bastion server.

**Move the files to Bastion Server**
Create a folder in the Bastion server and Copy the following files to Bastion server to create the Docker image.
- Dockerfile
- cacerts
- usp-exp-api-1.0.1-SNAPSHOT.jar

The command to copy the files(assume all the above files are in a single folder in windows).
```
pscp -i .\AWS\ThroughPuttyv2.ppk -r .\UnifiedOnboarding\usp-exp-api  operatorUsb@10.87.96.134:/home/operatorUsb/uo
```
_Note: Download [ThroughPuttyv2.ppk](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/ThroughPuttyv2.ppk) required for the command._

The screenshot of the files after moving into the Bastion server are shown below.
![image-24.png](./image-24.png)

Before creating the image, verify and setup docker based on the steps provided in [Appendix - Docker Setup](build-dockerfile.md#user-content-docker-setup) 

To build the docker image use the following command from the folder in which the Dockerfile, jar and trust store is copied.
```
docker build -t usp/usp-exp-api .
```
_Note: usp/usp-exp-api is the docker image name._

Use the below command to check if the image is created successfully
```
docker images
```
![image-25.png](./image-25.png)

## Tagging and Publish Docker image

As the next step, tag the docker image created and move the image to the Artifactory so the image can be used for deploying into the EKS.
- Tag the Docker image created using the below command
```
docker tag usp/usp-exp-api artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0
```
- Verify if the connection to the Artifactory is successful using the below command.
```
docker login artifactory.us.bank-dns.com:5000
```
- If the auth token is not already configured, the login details will be requested. Provide the login details to login to the artifactory.
- Once able to login, we can publish the image to the Artifactory using the below command
```
docker push artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0

```
- The screenshot with the image published in the artifactory is provided below
![image-22.png](./image-22.png)

- Can use the below commands to run the docker image using the image published as shown below
```
docker run -p 8080:8080 artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0
```
![image-21.png](./image-21.png)
- To run the container in the background, can use the below commands
```
docker run -p 8080:8080 artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0 > usp-exp-api.log &

docker run -dp 8080:8080 artifactory.us.bank-dns.com:5000/usb/usp-exp-api:v_1.0.0
```
- Testing the service from the Postman
usp-exp-api End point: http://10.87.96.134:8080/api/onboarding/corp-apply/usp-service/graphql

![image-23.png](./image-23.png)

## Appendix
### Docker Setup

- Start docker
```
sudo systemctl start docker
```
- Change permission to execute docker commands
```
sudo chmod 666 /var/run/docker.sock
```
- To test, run following command:
```
docker images
```
- Disable Docker ssl verification for Artifactory and add http proxy, https proxy, no proxy to be used to access public registeries (Please note public registery urls should be white listed).
- Create daemon file if it does not exist already
```
sudo mkdir -p /etc/systemd/system/docker.service.d

sudo vi /etc/systemd/system/docker.service.d/http-proxy.conf
```
- Add following contents to the file:
```
[Service]
Environment="HTTP_PROXY=proxy.us-east-2.nonprod.aws.prv:3128"
Environment="HTTPS_PROXY=proxy.us-east-2.nonprod.aws.prv:3128"
Environment="NO_PROXY=.us.bank-dns.com"

"proxies":
 {
   "default":
   {
     "httpProxy": "proxy.us-east-2.nonprod.aws.prv:3128",
     "httpsProxy": "proxy.us-east-2.nonprod.aws.prv:3128",
     "noProxy": ".nonprod.aws.cloud.bank-dns.com,169.254.169.254,.artifactory.us.bank-dns.com,.us.bank-dns.com"
   }
 }
```
- Reload and start the Docker daemon
```
 sudo systemctl daemon-reload
 sudo systemctl restart docker
```
- Reference to the above steps are provided in [detail](https://docs.docker.com/config/daemon/systemd/)

### Docker Build - Outcome
```
[operatorUsb@ip-10-87-96-134 usp-exp-api]$ docker build -t usp/usp-exp-api .
Sending build context to Docker daemon  53.64MB
Step 1/11 : FROM artifactory.us.bank-dns.com:5000/usb/eclipse-temurin-jdk17:v_1.0.0
 ---> 6f5a28a9734c
Step 2/11 : VOLUME /home
 ---> Running in 759695cdba0a
Removing intermediate container 759695cdba0a
 ---> b550e40d54ee
Step 3/11 : WORKDIR /home
 ---> Running in 70ce2a1c5ce0
Removing intermediate container 70ce2a1c5ce0
 ---> e1d56b14bbd6
Step 4/11 : ENV JAVA_OPTS "-Xms512m -Xmx1024m -XX:MaxPermSize=256m -XX:+UnlockExperimentalVMOptions -XX:+UseCGroupMemoryLimitForHeap"
 ---> Running in 7b54da444a7f
Removing intermediate container 7b54da444a7f
 ---> 47d67403831b
Step 5/11 : ARG artifactoryUser
 ---> Running in 38c0215dadc2
Removing intermediate container 38c0215dadc2
 ---> 629ff1a29c5c
Step 6/11 : ARG artifactoryPassword
 ---> Running in 7c7619b20377
Removing intermediate container 7c7619b20377
 ---> 7133ce8c5e2f
Step 7/11 : ARG JAR_FILE=usp-exp-api-1.0.1-SNAPSHOT.jar
 ---> Running in 934687e739e2
Removing intermediate container 934687e739e2
 ---> 420c08e1303d
Step 8/11 : COPY ${JAR_FILE} usp-exp-api.jar
 ---> b8157b92aa03
Step 9/11 : COPY cacerts cacerts
 ---> 2a58b121c5ce
Step 10/11 : EXPOSE 8080
 ---> Running in ed8678993fe0
Removing intermediate container ed8678993fe0
 ---> 71b54da8074d
Step 11/11 : ENTRYPOINT ["java","-Djavax.net.ssl.trustStore=cacerts","-jar","usp-exp-api.jar","--spring.profiles.active=local"]
 ---> Running in cf456d7e595b
Removing intermediate container cf456d7e595b
 ---> bce3eb790316
Successfully built bce3eb790316
Successfully tagged usp/usp-exp-api:latest
[operatorUsb@ip-10-87-96-134 usp-exp-api]$
```

### Publish Docker Image to Artifactory - Outcome
```
[operatorUsb@ip-10-87-96-134 usp-exp-api]$ docker push artifactory.us.bank-dns.com:5000/usb/usp/usp-exp-api:v_1.0.0
The push refers to repository [artifactory.us.bank-dns.com:5000/usb/usp/usp-exp-api]
fa9b96516fa2: Pushed
cad52e644c21: Pushed
1f1bf08dccc7: Layer already exists
5f70bf18a086: Layer already exists
7af9278e8510: Layer already exists
bc81d4ecff8e: Layer already exists
fbd66e4ff0ab: Layer already exists
48391edafb74: Layer already exists
0f92191dc4a8: Layer already exists
7c44cdc69570: Layer already exists
50467638fead: Layer already exists
f6e572ab134b: Layer already exists
3de9bbd55c1d: Layer already exists
8ceb9643fb36: Layer already exists
v_1.0.0: digest: sha256:97b83c34ad04b8bc79f49f5cba458646e83cad078d0ebe726bfd2c5a932355cf size: 3460
[operatorUsb@ip-10-87-96-134 usp-exp-api]$
```
