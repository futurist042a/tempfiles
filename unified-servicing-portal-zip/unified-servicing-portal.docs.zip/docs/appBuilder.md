# AppBuilder Component User Guide
This readme provides the details on using AppBuilder Component.

The AppBuilder provides the below key components.
- UI Editor: Provides the Low Code/No code tool to build apps​. The Editor can be accessed through the URL: [AppBuilder](http://appbuilder-dev.us.bank-dns.com//usp/home/ui-editor)
- RenderUI Library: Used by the application to render the UI using the screen json build using the UI Editor.

## UI Editor:
The editor is build using the Shield components, which can be used to create the Screen UI.

The component JSON structure is provided below
```
{
    "props": { include any shield component specific properties
        "title": "Select Account"
    },
    "style": {  css style for the component
        "grid-column": "1 / span 3",
        "grid-row": "1"
        …additional style as required
    },
    "type": "<component type alias name>",
    "name": "<component name>"
}

```

### Shield Component vs AppBuilder Type Alias mapping
The below table provides the Appbuilder and Shield component type mapping. In addition to the properties provided by the Shield component, app builder specific properties that are support by each component is provided.  

Sl No  | Type Alias	        | Shield Component	    | Additional Properties Supported
------ | -------------------|---------------------- | ---------------------------------------------------------
1	   | button	            | USBButton	            | onClick
2	   | text	            | USBTextInput	        | onChange, validate, initData, data
3	   | radio	            | USBRadioGroup	        | onChange, validate, initData, data
4	   | checkbox	        | USBCheckboxGroup	    | onChange, validate, initData, data
5	   | textbox	        | USBTextArea           | onChange, validate, initData
6	   | dropdown	        | USBDropdown	        | onChange, validate, initData, data
7	   | select	            | USBSelect             | onChange, validate, initData, data
8	   | tooltip            | USBTooltip	        | -
9	   | dateinput          | USBDateInput	        | onChange, validate, initData
10	   | icon	            | Icon	                | -
11	   | notification	    | USBNotification	    | -
12	   | label	            | None	                | data
13	   | header	            | None	                | title
14	   | modal	            | USBModal	            | openModal, title
15	   | tabs	            | USBTabs	            | -
16	   | table	            | USBTable	            | initData
17	   | accordion	        | USBAccordion	        | onClick
18	   | actionChips	    | USBActionChips	    | onClick
19	   | chip	            | USBChip 	            | -
20	   | calendar	        | USBCalendar	        | onChange
21	   | combobox	        | USBCombobox	        | onChange
22	   | line	            | USBDividerLine        | -
23	   | breadcrumb         | USBBreadcrumb	        | onClick
24	   | link               | USBLink	            | -
25	   | progressIndicator  | USBProgressIndicator  | onClick
26	   | searchInput	    | USBSearchInput	    | onChange
27	   | barChart	        | USBChartBarChart	    | -
28	   | areaChart          | USBChartAreaChart	    | -
29	   | pieChart           | USBChartPieChart	    | -
30	   | lineChart	        | USBChartLineChart	    | -
31	   | scatterChart       | USBChartScatterChart  | -
32	   | composedChart      | USBChartComposedChart | -
33	   | buttonGroup	    | USBButtonGroup	    | - 
34	   | datePicker         | USBDatePicker	        | onChange, validate, initData
35	   | check              | USBCheckbox	        | onChange, initData
36	   | diverline	        | USBDividerLine        | -
37	   | check	            | USBCheckbox	        | - 
38	   | stateCombobox      | USBStateCombobox	    | onChange, initData, data
39	   | accountInput       | USBAccountNumberInput | onChange, validate, initData
40	   | addressInput	    | USBAddressLineInput	| onChange, validate, initData
41	   | businessNameInput  | USBBusinessNameInput	| nChange, validate, initData
42	   | cityInput	        | USBCityInput	        | onChange, validate, initData
43	   | codeInput	        | USBCodeInput	        | onChange, validate, initData
44	   | emailInput         | USBEmailInput	        | onChange, validate, initData
45	   | empIdentificationInput | USBEmployerIdentificationInput | onChange, validate, initData
46	   | nameInput	        | USBNameInput	        | onChange, validate, initData
47	   | phoneInput	        | USBPhoneInput	        | onChange, validate, initData
48	   | routingNumberInput | USBRoutingNumberInput | onChange, validate, initData
49	   | taxNumberInput     | USBTaxNumberInput	    | onChange, validate, initData
50	   | avatar	            | USBAvatar	            | -
51	   | badge	            | USBBadge	            | icon (to set customIcon)
52	   | actionChip	        | USBActionChips	    | onClick, validate, initData
53	   | formChip	        | USBFormChips	        | onClick, validate, initData, data
54	   | checkboxCards      | USBCheckboxCards	    | onChange, validate, initData, data
55	   | cardNumberInput    | USBCardNumberInput	| onChange, validate, initData, data
56	   | currencyInput      | USBCurrencyInput	    | onChange, validate, initData, data
57	   | radioCards	        | USBRadioCards	        | onChange, validate, initData, data

The detail properties on each Shield component can be retrieved from [Shield Component Properties](https://design-system.usbank.com/2a57a3c5c/p/85b7e3-all-components )

The details on the additional properties are provided below.

`onClick`:
This property is used to involve framework/custom functions and can be used to navigate to next screen. The framework provides OOTB ‘updateScreen’ function and supports below parameters
- component  : array of screen name to load the form JSON. 
- objectQuery: array of object query

`onChange`:
This property is used to involve framework/custom functions and can be used to handle component level events e.g. loading another component(s). The framework provides OOTB ‘updateSelect’ function and supports below parameters
- component  : array of component object i.e. with name and data. Name represent the component to update and data will be ref name to use to update the component.

`validate`:
This property can be used to involve any custom function to execute validation. The response for the validation can be as per shield validation function. The input to the function will include the event object provided by the shield component.

`initData`:
This property will have the eventObject attribute which can be used to set the initial value for the component.

`data`:
This property will mention the ref name which can be used to load the component e.g. select, dropdown, checkbox options.

## Create Application
As a first step to create screen json, the application should be created which could store all the screen json that needs to be build.

Follow the below steps to create the application.
- Launch the App Builder using the URL: http://appbuilder-dev.us.bank-dns.com//usp/home/ui-editor
![Alt text](image-80.png)
- Navigate to the 'USB Apps' tab
![Alt text](image-81.png)
- Provide the details of the application
    - Application Name : Provide the name of the application
    - Application Acronym : Provide a acronym for the application
    - Application Details : Provide a short description for the application
    - Select Object Template : Select the object template that will be used as base for the application.
- Click on the 'Create Application'

## Create Screen JSON
Once the application is created, the screen json required for the application can be created.

Follow the below steps to create screen json.
- Launch the App Builder using the URL: http://appbuilder-dev.us.bank-dns.com//usp/home/ui-editor
- Navigate to the 'UI Editor' tab
![Alt text](image-82.png)
- From the Application drop down, select the application created. 
- By Default, once the application is created a 'Landing Page' will be created. The Landing page can be updated as required for the application.
- To add a new screen, select 'New' from the UI drop down as shown below.
![Alt text](image-83.png)
- Provide the UI Name and click on Create Button
![Alt text](image-84.png)
- The default template for the new screen will be displayed.
![Alt text](image-85.png)
- Update the JSON to create the required screen. Use the JSON structure and Shield Properties as detailed in the above section.
    - There are few sample components available in the template project as shown below, which can also be referred.
    ![Alt text](image-86.png)
- If the screen contains more section and ui components use the section and ui drop down to edit the particular section / ui components.
- Save the JSON to update in the backend.

## Import Render UI Library
To use the Screen JSON created using the AppBuilder, create / update the react project to include the below configuration.
- Edit / Create the .npmrc (Node Package Manager (npm) configuration file) in the root directory of the react project and add the below configuration to add the appBuilder library artifactory repo.
```
@usb-app-builder:registry=https://artifactory.us.bank-dns.com/artifactory/api/npm/testrepo/
//artifactory.us.bank-dns.com/artifactory/api/npm/testrepo/:_password=<<Password>
//artifactory.us.bank-dns.com/artifactory/api/npm/testrepo/:username=<<UserId>
//artifactory.us.bank-dns.com/artifactory/api/npm/testrepo/:email=<<Email Id>
//artifactory.us.bank-dns.com/artifactory/api/npm/testrepo/:always-auth=true
```
- In the package.json, include the below dependency
```
"@usb-app-builder/renderui": "^1.6.0",
```
- Install the package
- The sample code to use the RenderUi is provided below.
```
import RenderAppUI from "@usb-app-builder/renderui"; --> Import the RenderUI Library
import * as functions from "./functionHelpher"; --> Import the js file with the mandatory and custom fucntion used in JSON.
import '@usb-app-builder/renderui/dist/library/styles/index.scss'; --> Import the RenderUI scss file

export default function AccountIntakeUI() {
  return (
    <RenderAppUI app="appAcronym" functionLoc={functions}/>
  )
}

```
- The details of the JS file is provided in the below section.

#### Java Script
The framework provides a set of predefined functions to handle the standard functions like
- `updateScreen` : This function can be used to move between screen e.g. onClick on a button on the screen. This function supports the below parameters
    - component: array of screen name to load the form JSON. 
    - objectQuery: array of object query

- `updateSelect`: This function will be used to handle component level events e.g. loading another component(s). The function support below parameters.
    - component  : array of component object i.e. with name and data. Name represent the component to update and data will be ref name to use to update the component.
- All Shield component function are supported.

The framework also supports invoking custom javascript functions specific to the application. To provide that support the application should include the js file that have the implementation of all the custom functions. The framework requires few mandatory functions to provide the support and the details are provided below.

The js function template can be download [here](applicationFunction.js).

Include the update JavaScript file which will include the custom function that will be configured as part of screen JSON. 

The below section provides the details on how to implement custom function and update js template provided above.

**Screen Event:**

The below function enables the support to invokve the custom screen event functon. This function invokes the custom function with the parameters defined in screen json and business data. 
```
//DON'T EDIT: Main functon to handle screen level functon i.e. onSubmit
export async function executeScreenEvent(functionName, params, businessData,serviceInfo){
    const response = await eval(functionName)(params, businessData,serviceInfo);
    return response;
}
```

The response of the custom function should be implemented by calling the createResponseObject function. The function structure is provided below
    - createResponseObject(screenFormJson, commonObject, formDataOptions)
        - screenFormJson: the next screen json to be loaded after the action.
        - commonObject: new business data for the next screen, only if there is change in business data else can be ignored.
        - formDataOptions: screen level data that needs to be used to load the form. Only if new set of form data needs to be reloaded else can be ignored.

The sample code to load the screen json is provided below.
```
const res = await processFormData("",screenSearch,false,{});
const screenFormJson = res?.data?.screenFormJson? res.data.screenFormJson[0]?.formJson : null;
```

**Validation Function:**

Define any custom validation function that could be required for the application. The validation function will be passed with the component event object which can be used for validation logic.

The sample 'checkSupportedAccountType' function is provided as a reference. The response of the validaton should be based on the shield component for which this validation fucntion is implemented.
```
export function checkSupportedAccountType(eventObj) {
    console.log(`checkSupportedAccountType triggered`);
    console.log(eventObj);
    if(eventObj !== 'Agency'){//Only Agency(1) Account Type is supported for now
        return 223
    }
    return 0;
}
```

**Event Specific Function:**

Define custom event function that will be required for the application that handles component specific event e.g. onchange event of the component. The event function will be padded with the component event object and the businessData which can be used for event specific logic.

The response of the event function can be an screen json or none. To response with screen json use the createResponseObject function.

**Landing Page Input:**

For the framework to identify and load the landing page,define the details in the 'landingPageInputs' function. If any other data needs to be loaded during the landing page define other parameters as required. The sample definiton is provided below.
```
//Mandatory function to get LandingPage data
export function landingPageInputs(){
    const screenSearch = "accountIntake.LandingPage";
    const objectQueries = [];
    const dataQueries = [];
    const transactionId = "";
    const isSave = false;
    return {transactionId,screenSearch,isSave, objectQueries, dataQueries};
}
```