# Unified Service Portal - Building Docker Image

## Create Dockerfile

Docker builds images by reading instructions in dockerfiles. The Dockerfile used to create the image is provided below.

This [dockerfile](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/blob/main/Dockerfile) is also part of the unified-servicing-portal project in gitlab.

```
##############################
# Start with app build image #
##############################
FROM artifactory.us.bank-dns.com:5000/node:18-alpine3.17

ENV http_proxy=http://web-proxyapp.us.bank-dns.com:3128
ENV https_proxy=http://web-proxyapp.us.bank-dns.com:3128
ENV no_proxy="local_host,.us.bank-dns.com,10.87.100.37"
ENV DEBUG='express:*'

COPY public/ /public/
COPY src/ /src/
COPY builds/ /builds/
COPY scripts/ /scripts/
COPY .npmrc .
COPY package.json .
COPY package-lock.json .
COPY tsconfig.json .
COPY webpack.*.js .
COPY .babelrc .

RUN npm install -f

CMD ["npm", "run", "dev"]

```

## Build the Docker Image
The steps provided below can be executed from any machine which have the docker installed and have access to the artifactory.us.bank-dns.com. 

For creating this image, the Ec2 instance (BAW Linux POC - 10.87.97.132) was used.

The document [Connect to Bastion server using putty](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/HowToSetupBastionServerAndConnect.md#connect-to-bastion-server-using-putty) provides the steps required to connect to bastion server.

**Move the files to Bastion Server**
- Commit the lastest code into the gitlab
- Download the Unified Service Portal source code as .tar.gz file as shown below
![image-52.png](./image-52.png)
- Create a folder in Bastion server
- Upload the download file into the Bastion server as shown below.
```
pscp -i .\AWS\ThroughPuttyv2.ppk .\UnifiedOnboarding\unified-servicing-portal\unified-servicing-portal-main.tar.gz operatorUsb@10.87.97.132:/home/operatorUsb/unifiedOnboarding
```
_Note: Download [ThroughPuttyv2.ppk](https://gitlab.us.bank-dns.com/axsult1/bawdocs/-/blob/main/InstallationInstructions/HowTos/ThroughPuttyv2.ppk) required for the command._
- Extract the tar file using the below command
```
tar -xvzf unified-servicing-portal-main.tar.gz
```
- The screenshot of the files after moving and extracting into the Bastion server are shown below.
![image-53.png](./image-53.png)
- Update the webpack.development.config from local to the EKS environment, using the below command.
```
mv webpack.development.config.js  webpack.development.config.local.js
mv webpack.developmentEKS.config.js webpack.development.config.js
```
- Before creating the image, verify and setup docker based on the steps provided in [Appendix - Docker Setup](build-dockerfile.md#user-content-docker-setup) 
- To build the docker image use the following command from the folder in which the Dockerfile, jar and trust store is copied.
```
docker build -t usp/unified-servicing-portal .
```
_Note: usp/unified-servicing-portal is the docker image name._

Use the below command to check if the image is created successfully
```
docker images
```
![image-54.png](./image-54.png)

## Tagging and Publish Docker image

As the next step, tag the docker image created and move the image to the Artifactory so the image can be used for deploying into the EKS.
- Tag the Docker image created using the below command
```
docker tag usp/unified-servicing-portal artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.3
```
_Note: If the version mentioned is already available in the respoistory, provide a different version i.e v_1.0.3_
- Verify if the connection to the Artifactory is successful using the below command.
```
docker login artifactory.us.bank-dns.com:5000
```
- If the auth token is not already configured, the login details will be requested. Provide the login details to login to the artifactory.
- Once able to login, we can publish the image to the Artifactory using the below command
```
docker push artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.3

```
- The screenshot with the image published in the artifactory is provided below
![image-56.png](./image-56.png)

- Can use the below commands to run the docker image using the image published as shown below
```
docker run -p 5031:5031 artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.3
```
![image-57.png](./image-57.png)
- To run the container in the background, can use the below commands
```
docker run -p 5031:5031 artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.3 > unified-servicing-portal.log &

docker run -dp 5031:5031 artifactory.us.bank-dns.com:5000/usb/unified-servicing-portal:v_1.0.
```

## Appendix
### Docker Setup

- Start docker
```
sudo systemctl start docker
```
- Change permission to execute docker commands
```
sudo chmod 666 /var/run/docker.sock
```
- To test, run following command:
```
docker images
```
- Disable Docker ssl verification for Artifactory and add http proxy, https proxy, no proxy to be used to access public registeries (Please note public registery urls should be white listed).
- Create daemon file if it does not exist already
```
sudo mkdir -p /etc/systemd/system/docker.service.d

sudo vi /etc/systemd/system/docker.service.d/http-proxy.conf
```
- Add following contents to the file:
```
[Service]
Environment="HTTP_PROXY=proxy.us-east-2.nonprod.aws.prv:3128"
Environment="HTTPS_PROXY=proxy.us-east-2.nonprod.aws.prv:3128"
Environment="NO_PROXY=.us.bank-dns.com"

"proxies":
 {
   "default":
   {
     "httpProxy": "proxy.us-east-2.nonprod.aws.prv:3128",
     "httpsProxy": "proxy.us-east-2.nonprod.aws.prv:3128",
     "noProxy": ".nonprod.aws.cloud.bank-dns.com,169.254.169.254,.artifactory.us.bank-dns.com,.us.bank-dns.com"
   }
 }
```
- Reload and start the Docker daemon
```
 sudo systemctl daemon-reload
 sudo systemctl restart docker
```
- Reference to the above steps are provided in [detail](https://docs.docker.com/config/daemon/systemd/)
