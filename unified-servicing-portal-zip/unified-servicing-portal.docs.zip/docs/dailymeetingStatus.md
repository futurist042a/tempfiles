## Arun Updates

### Activities Planned and overall status
-	Complete the user validation logic in the experience api - **Completed**
-	Package the experience api (jar with the dependencies – maven will create it) -  **Completed**
    -	Execute the runnable jar from CLI (Possible and successful can have a local environment without the code) -  **Completed**
-	Certificate issue resolution -  **Completed**
-	Create docker file -   **Completed**
-   Create docker image and publish in artifactory -  **Completed**
-	Deploy usp-exp-api in EKS -  **Completed**
-   Fix the issue related to accessing docker container for service portal - _InProgress_
- 	Deploy unified service portal in EKS - _Inprogress_
-	Gitlab updates : 
    -	The existing readme are in my repository, needs to move all the files to the main repo.  **Completed**
    -	Update the notes with the certificate fix - **Completed**
    -	Update the notes with the packaging and command line execution - **Completed**
    -	Creating docker file, image and pushiblish to Artifactory - **Completed**
        - Capture the docker issue in pulling the base image from the artifactory - **Completed**
    -	Deploy in EKS - **Completed**
        -   Rancher configuration to deploy the usp-exp-api docker image and service configuration
-	Update the code in gitlab

### Daily Status
--------------
#### 12/21/2023 to  12/22/2023
Status:
- Updated the Gitlab readme to capture the below information.
    - Rancher Login and Dashboard
    - Creating New Namespace
    - Creating Secrets
    - Creating Docker Image for usp-exp-api and unified-service-portal
    - Deploying the Docker Image in EKS for usp-exp-api and unified-service-portal
- Updated the main Readme to add the link to above readme files.

#### 12/20/2023
Status:
- Deployed Docker and configured the BAW Linux EC2 instance
- Docker image was successfully created using the BAW Linux EC2 instance
- Published the docker image into Artifactory
- Debug the issues while accessing the service portal from EKS
    - Few code updates was completed but still we get the error screen

#### 12/19/2023
Status:
- Build the Docker Image for the React Application
    - The Docker file is created successfully (tried with different options - with/without nginx)
    - While creating the Docker image in the Bastion get "returned a non-zero code: 137" error code, which is related to insufficent memory in the machine.
    - Looked at the options to set few parameter like "--max-old-space-size=" but didnt work.
    - Need to look at alternative machine to create the Docker image

#### 12/18/2023
Status: Leave

#### 12/15/2023
Status:
- Able to successfully run the usp-exp-api service in the docker i.e. within the Bastion server
- Able to configure and deploy the usp-exp-api docker image from the artifactory in AWS EKS using the Rancher.
- Able to access the service from the AWS EKS through the NodePort Service
    - Need to verify the option for Load Balancer as thats the perferred way to expose the service through DNS name.

#### 12/14/2023
Status:
- The Docker file creation was completed
- There were issues in pulling the base image from the Artifactory and it was resolved by updating the docker.service with proxy details
- Docker image creation was compelted and published into Artifactory

#### 12/13/2023
Status:
- The experience api snapshot creation is completed.
- Fixed the issue with the certificate issue
    - Able to replicate the issue in my machine while trying to execute the jar from the command line.
- Able to run the experience api service from CLI
- Update the Gitlab readmes
    - Moved all the files from my local repo to the main
    - Added the readme for packaging and executing the jar from CLI

#### 12/12/2023
Status:
-	The service implementation for the user/user group validation is completed and tested.
-	Started working on packaging the exp api project and executing it from the command line.



#### 12/11/2023
Status:
-	Able to identify the REST service to get the user details
-	Implementation of the user validation is in progress – 50% completed. 


#### 12/08/2023
Status:
-	Updated the experience service to invoke the BPM REST API to get the active task for a process instance id.
-	Based on the active task details from BPM REST API, the Taskdetails[] in the Common event object from Domain API is replace. 
    -	Valid instance id is updated in the table to retrieve the task details. Current set instance Id is invalid.
    -	Task URL is mapped (User check is pending but have added the use case below to discuss and verify)
-	Analyzed the Domain API to understand from where the data gets populated for the common event object, below is the summary. All the mapping is based on the onboarding_id and for datapoints table its onboarding_id and source_system_dp_id (i.e. string3 in Refs table e.g. clientDetails-legalName etc)
    -	Process Details : from uo_onboarding. Custom value: status: if uo_submit -> set In Progress, if uo_draft -> set Draft/Pending/Not submitted
    -	Milestone Details: from uo_milestone
    -	Task Details: from uo_checklist
    -	All other objects and fields are from uo_datapoint
    -	Queries have mentioned below for reference
        -	SELECT string3  FROM refs where typeid=161
        -	SELECT * FROM uo_onboarding where business_line='CCB' (business line is the input to the REST API)
        -	Select * from uo_datapoint where onboarding_id in (36170,36171) and source_system_dp_id in (All string3 from refs table ) ORDER BY onboarding_id, source_system_dp_id
        -	Select * from uo_milestone where onboarding_id in (36170,36171) ORDER BY onboarding_id, sortOrder
        -	Select *  from uo_checklist where onboarding_id in (36170,36171)  ORDER BY onboarding_id

Use Case: User Validation for Task URL Mapping  (In the react app, if the task url is mapped shown the link else not)
-	Logic is based on the logged in user (current user logged in reach app) - we can get that from exp api logic.
-	Get the logged in user -> user group (does it change per process application - to check?)
-	Get all the active task for the process instanceId
    -	If task is assigned to a user and the user is not the logged in user, don’t map the task url
    -	If task is assigned to a user group and if
        -	the logged in user is a member of the user group, map the task url.
        -	the logged in user not a member of the user group, don’t map the task url.



#### 12/07/2023
Status:
-	Able to add additional attributes in the common event object and also control that using the graphql (test by adding taskURL in taskdetails Object)
-	Test the BPM Service REST URL from Postman, so the authentication works using the Basic Auth Token – we already have a common user id and password created, so was able to use it.
    -	This worked for Dev Stack #1 and Dev Stack #2 we have authorization issues.
    -	Discussed with Rajesh and he is crossing checking – looks Dev Stack #2 using a PingFed, so he mentioned we may have to use a different token but Rajesh will come back.
-	Updating the experience api to use the BPM service (Dev Stack #1 for now) to retrieve the task details based on the instance id
    -	Once this test is completed, will do the other checks based on the user details.
-	EKS didn’t get much time today, so will see if can spend some time tomorrow on this.


