import { processFormData} from "@usb-app-builder/renderui/dist/esm/services/usp-api-service";
import { set} from "lodash";

//Mandatory function to get LandingPage data
export function landingPageInputs(){
    const screenSearch = "accountIntake.LandingPage";
    const objectQueries = [];
    const dataQueries = [];
    const transactionId = "";
    const isSave = false;
    return {transactionId,screenSearch,isSave, objectQueries, dataQueries};
}


//DON'T EDIT: Main functon to handle screen level functon i.e. onSubmit
export async function executeScreenEvent(functionName, params, businessData,serviceInfo){
    const response = await eval(functionName)(params, businessData,serviceInfo);
    return response;
}

//DON'T EDIT: Main function to prepare respnse object
function createResponseObject(screenFormJson, commonObject, formDataOptions){
    const responseObj = {
        screenFormJson, commonObject, formDataOptions
    }
    return responseObj;
}

/** Event Specific Function **/
// DON'T EDIT: Main function to handle event specific function like onChange etc
export function handleEvent(functionName, compEvent,businessData){
    if(functionName){
        return eventFunctions[functionName](compEvent,businessData);
    }
}

//Define all the custom event function in this constants
const eventFunctions = {
    sampleEventFunction: (eventObj) => {
        console.log(`sampleEventFunction: ${eventObj}`);
    },
};

/** Validation Function **/
//DON'T EDIT: Main Function to handle all custom validation functions
export function handleValdation(functionName, compEvent){
    if(functionName){
        return validateFunctions[functionName](compEvent);
    }
}

//Define all the custom validation function in this constants
const validateFunctions = {
    sampleValidationFunc: (eventObj) => {
        console.log(`sampleValidationFunc triggered`);
        return 224;
    }
}