# Setup USP Experience API in IntelliJ IDE

## Clone the usp-exp-api project 
- Clone the usp-exp-api project from the [gitlab](https://gitlab.us.bank-dns.com/axsult1/usp-exp-api.git)
	- File -> New -> Project from Version Control
    - Provide the gitlab url and Directory to clone the project
    ![image-16.png](./image-16.png)
    - Click the Clone button   
- Alternatively can clone the project directly from gitlab as shown below.
![image-17.png](./image-17.png)

## Configure the Environment
- Download the [cacerts file](cacerts) and copy that to C:\Users\<userid>\cacerts in your machine.
- Open the BoilerplateExpApiApplication class from src > main > java > com.usbank.wm.empexpboilerplateapi.boilerplateexpapi
![image-4.png](./image-4.png)
- Click Run -> Run and Edit the configuration to update the below details
    - Environment Variable: --spring.profiles.active=local
    - JVM Option: -Djavax.net.ssl.trustStore=C:\Users\<userid>\cacerts -Dspring-boot.run.fork=false -Dserver.port=8090
        - If JVM Option is not shown, enable it(Add JVM Options) from the Modify Option as shown below
        ![image-5.png](./image-5.png)
    - Set the JDK version to 17 or above (Install the JDK if not available)
_Note: server.port is set to 8090 and can be updated as required. The default is 8080 if this property is removed._

## Run the Server
Spring boot comes with inbuilt Tomat server, so we will use this server to execute the program locally.
- To execute, click on Run > Run BoilerplateExpApiApplication as shown below. 

![image-6.png](./image-6.png)
- The Run console will be displayed as shown below, could take a minute to execute completely.
![image-8.png](./image-8.png)
- If you notice the message "Started BoilerplateExpApiApplication" then the application is started and can be used.

## Test the Service End Points
- Launch the Postman and import the postman collection provided with the project. The collection can be found in src\postmanCollection\BoilarPlate.postman_collection.json
![image-9.png](./image-9.png)
- This could load the below services in the Postman
![image-10.png](./image-10.png)
- To Run the service, the Bearer Token should be retrieved. _Note: The token will be valid only for 3 minutes_
    - From the browser make a request to 'https://dev-unifiedonboarding.us.bank-dns.com/personal-trust/home' URL and from network get the token as shown below. Use the request to userList?onboardingType=PTAO
    ![image-11.png](./image-11.png)
- Update the token in Postman i.e. Authorization > Bearer Token > Token as shown below
![image-12.png](./image-12.png)
- The service can be tested now.

## Creating the package
- To create the package/snapshot, from IntelliJ execute the maven package lifecycle as shown below.

![image-18.png](./image-18.png)
- This will execute the maven command and the results will be shown in the run
![image-19.png](./image-19.png)
- The jar file will be available in the target folder.
- If the snapshot name needs to be updated, make the changes in the pom.xml file
![image-20.png](./image-20.png)

## Executing the service from command line
This option provides the option to execute the experience api from the command line using the snapshot created from the project.

The dependencies 
- JDK version to 17 or above (Install the JDK if not available)
    - The path should be set automatically but can check with 'java -version' from the command line.

    ![image-13.png](./image-13.png)
    - If PATH is not set, for windows set using SET PATH=%PATH%;<java installation folder>\bin folder
- Download the snapshot jar and the trust store into a directory.
    - [Snapshot jar location](https://gitlab.us.bank-dns.com/axsult1/usp-exp-api/-/blob/main/target/usp-exp-api-1.0.0-SNAPSHOT.jar)
    - [Trust Store location](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/blob/main/service/cacerts)

**Run the service**:
- From the command line, execute the below command. Note: Update the  truststore location and the jar location according to your environment.
```
java -Djavax.net.ssl.trustStore=C:\Users\c080842\cacerts -jar .\target\usp-exp-api-1.0.0-SNAPSHOT.jar --spring.profiles.active=local
```
- The service should get started as shown below
![image-14.png](./image-14.png)
![image-15.png](./image-15.png)


