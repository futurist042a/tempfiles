import { createSelector } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

export const selectEventDetails = (state) => state.eventDetails;
export const selectTableMetadataStatus = (state) => state.eventDetails.tableMetadataStatus;
export const selectTaskListStatus = (state) => state.eventDetails.taskListStatus;
export const selectHistoryListStatus = (state) => state.eventDetails.historyListStatus;
export const selectHistoryTableMetadataStatus = (state) =>
  state.eventDetails.historyTableMetaDataStatus;

export const selectTasksTableStatus = createSelector(
  selectTaskListStatus,
  selectTableMetadataStatus,
  (...statuses) => {
    if (statuses.every((status) => status === API_CALL_STATUS.PENDING)) {
      return API_CALL_STATUS.PENDING;
    }
    if (statuses.some((status) => status === API_CALL_STATUS.STARTED)) {
      return API_CALL_STATUS.STARTED;
    }
    if (statuses.every((status) => status === API_CALL_STATUS.SUCCESS)) {
      return API_CALL_STATUS.SUCCESS;
    }
    if (statuses.some((status) => status === API_CALL_STATUS.FAILED)) {
      return API_CALL_STATUS.FAILED;
    }
  },
);

export const selectHistoryTableStatus = createSelector(
  selectHistoryListStatus,
  selectHistoryTableMetadataStatus,
  (...statuses) => {
    if (statuses.every((status) => status === API_CALL_STATUS.PENDING)) {
      return API_CALL_STATUS.PENDING;
    }
    if (statuses.some((status) => status === API_CALL_STATUS.STARTED)) {
      return API_CALL_STATUS.STARTED;
    }
    if (statuses.every((status) => status === API_CALL_STATUS.SUCCESS)) {
      return API_CALL_STATUS.SUCCESS;
    }
    if (statuses.some((status) => status === API_CALL_STATUS.FAILED)) {
      return API_CALL_STATUS.FAILED;
    }
  },
);
