import { createSelector } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

export const selectCountries = (state) => state.dropdowns.countries.data;
export const selectCountriesStatus = (state) => state.dropdowns.countries.status;

export const selectStates = (state) => state.dropdowns.states.data;
export const selectStatesStatus = (state) => state.dropdowns.states.status;

export const selectCountriesForDropdown = createSelector(selectCountries, (countries) => {
  return [...countries].sort(({ value }) => {
    return value === "United States" ? -1 : 0;
  });
});

export const selectCountriesAndStatesSuccess = createSelector(
  selectCountriesStatus,
  selectStatesStatus,
  (countriesStatus, statesStatus) => {
    return countriesStatus === API_CALL_STATUS.SUCCESS && statesStatus === API_CALL_STATUS.SUCCESS;
  },
);
