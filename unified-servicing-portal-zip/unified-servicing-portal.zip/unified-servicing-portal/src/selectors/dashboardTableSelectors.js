import { createSelector } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";
import { selectUserRoleStatus } from "./userSelectors";

export const selectTableMetadata = (state) => state.dashboardTable.tableMetadata;
export const selectTableMetadataStatus = (state) => state.dashboardTable.tableMetadataStatus;
export const selectTaskListStatus = (state) => state.dashboardTable.taskListStatus;

export const selectDashboardLoading = createSelector(
  selectTaskListStatus,
  //selectUserRoleStatus, //TODO turn back on when we are grabbing roles from database
  selectTableMetadataStatus,
  (...statuses) => {
    //console.log(`statuses: ${statuses}`)
    const some = statuses.some(
      (status) => status === API_CALL_STATUS.PENDING || status === API_CALL_STATUS.STARTED,
    );
    //console.log(`some: ${some}`)
    return some
  },
);

export const selectDashboardSuccess = createSelector(
  selectTaskListStatus,
 // selectUserRoleStatus, //TODO turn back on when we are grabbing roles from database
  selectTableMetadataStatus,
  (...statuses) => statuses.every((status) => status === API_CALL_STATUS.SUCCESS),
);

export const selectIsMetadataAvailable = createSelector(
  selectTableMetadata,
  (obj) => Object.keys(obj).length !== 0,
);

export const selectTaskList = (state) => {
  return state.dashboardTable.taskList
};
