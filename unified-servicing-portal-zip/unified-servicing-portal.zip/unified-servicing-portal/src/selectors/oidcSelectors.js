export const selectAccessToken = (state) => state.oidc?.user?.access_token;
export const selectPreferredId = (state) => state.oidc.user?.preferred_username;
export const selectPreferredUsername = (state) => state.oidc?.user?.profile?.preferred_username;
export const selectOidcUser = (state) => state.oidc.user;

export function selectFullName(state) {
  if (!state.oidc.user) return "";
  const { given_name, family_name } = state.oidc.user.profile;
  return `${given_name} ${family_name}`.trim();
}
