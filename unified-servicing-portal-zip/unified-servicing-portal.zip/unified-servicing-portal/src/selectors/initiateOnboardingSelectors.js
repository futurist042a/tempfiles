import { createSelector } from "@reduxjs/toolkit";
import {
  API_CALL_STATUS,
  FORMS_REQUIRING_COUNTRIES,
  FORMS_REQUIRING_STATES,
} from "@/constants/constant";
import { selectCountriesStatus, selectStatesStatus } from "./dropdownsSelectors";

export const selectActiveForm = (state) => state.initiateOnboarding.activeForm;
export const selectAuditTrailDetails = (state) => state.initiateOnboarding.auditTrailDetails;
export const selectInitiateOnboardingFetchingStatus = (state) =>
  state.initiateOnboarding.initiateOnboardingFetchingStatus;
export const selectFetchingFormStatus = (state) => state.initiateOnboarding.fetchingFormStatus;
export const selectTabList = (state) => state.initiateOnboarding.tabList;
export const selectTabListStatus = (state) => state.initiateOnboarding.tabListStatus;

export const selectCurrentTab = createSelector(selectTabList, (tabList) => {
  if (Array.isArray(tabList) && tabList.length > 0) {
    const allTabsCompleted = tabList.every((tab) => tab.completed);
    const selectedTab = tabList.find((tab) => tab.selectedTab);
    if (allTabsCompleted && !selectedTab) {
      return tabList[0].value;
    }
    return selectedTab?.value || null;
  }
  return null;
});

export const selectVisibleTabs = (state) => {
  return (state.initiateOnboarding.tabList || []).filter((tab) => tab.isVisible);
};

export const selectActiveTabIndex = createSelector(
  selectCurrentTab,
  selectVisibleTabs,
  (currentTab, visibleTabs) => {
    return visibleTabs.findIndex((tab) => tab.value === currentTab);
  },
);

export const selectInitiateOnboardingIsLoaded = createSelector(
  selectCurrentTab,
  selectCountriesStatus,
  selectStatesStatus,
  selectInitiateOnboardingFetchingStatus,
  selectFetchingFormStatus,
  selectTabListStatus,
  (currentTab, countriesStatus, statesStatus, ...statusesToCheck) => {
    if (FORMS_REQUIRING_COUNTRIES.includes(currentTab)) {
      statusesToCheck.push(countriesStatus);
    }
    if (FORMS_REQUIRING_STATES.includes(currentTab)) {
      statusesToCheck.push(statesStatus);
    }
    return statusesToCheck.every((status) => status === API_CALL_STATUS.SUCCESS);
  },
);

export const readOnlyFormStatus = createSelector(selectFetchingFormStatus, (fetchingFormStatus) => {
  return fetchingFormStatus === API_CALL_STATUS.SUCCESS;
});

export const checkIncompleteStatus = (state) => {
  const visibleList = state.initiateOnboarding.tabList.filter((list) => list.isVisible);
  const status =
    visibleList.find(
      (f) =>
        f.isVisible &&
        f.status !== "completed" &&
        f.value !== "reviewandsubmit" &&
        f.value !== "reviewandapprove",
    ) ?? {};
  return Object.keys(status)?.length > 0;
};
