import { createSelector } from "@reduxjs/toolkit";
import { USER_ROLE } from "@/constants/constant";

export const selectUserRoleList = (state) => state.user.roleList || [];
export const selectUserRoleStatus = (state) => state.user.roleListStatus;
export const selectUserPermission = (state) => state.user.permission;

export const selectUserRole = createSelector(selectUserRoleList, (roleList) => {
  return roleList.find((role) => Object.values(USER_ROLE).includes(role));
});
