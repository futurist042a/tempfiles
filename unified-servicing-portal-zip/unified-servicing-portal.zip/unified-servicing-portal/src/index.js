import bootstrap from "./bootstrap";

/** @see https://v4.webpack.js.org/loaders/bundle-loader/ */
const requiredCallback = () => {};
bootstrap(requiredCallback);
