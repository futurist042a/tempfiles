import { formatDateLongNumeric, formatDateTimeNumeric } from "@/utils/date";

describe("date", () => {
  describe("formatDateLongNumeric", () => {
    it("should return MM/DD/YYYY when called with a Date", () => {
      const date = new Date();
      const day = date.getDate().toString().padStart(2, 0);
      const month = (date.getMonth() + 1).toString().padStart(2, 0);
      const year = date.getFullYear();
      const expectedValue = `${month}/${day}/${year}`;
      expect(formatDateLongNumeric(date)).toBe(expectedValue);
    });

    it("should return MM/DD/YYYY when called with a string", () => {
      const dateString = "2023-01-31T00:00:00.000Z";
      const date = new Date(dateString);
      const day = date.getDate().toString().padStart(2, 0);
      const month = (date.getMonth() + 1).toString().padStart(2, 0);
      const year = date.getFullYear();
      const expectedValue = `${month}/${day}/${year}`;
      expect(formatDateLongNumeric(dateString)).toBe(expectedValue);
    });
  });

  // TODO: fix this test so that it runs accordingly in any timezone
  describe.skip("formatDateTimeNumeric", () => {
    it("should format date and time correctly with string input", () => {
      const date = "2023-07-19T10:11:44.842Z";
      expect(formatDateTimeNumeric(date)).toBe("July 19, 2023 at 3:41:44 PM");
    });
    it("should format date and time correctly with date", () => {
      const date = new Date("2023-07-19T10:11:44.842Z");
      expect(formatDateTimeNumeric(date)).toBe("July 19, 2023 at 3:41:44 PM");
    });
  });
});
