const { createUrl } = require("@/utils/createUrl");

describe("createUrl", () => {
  it("returns the path when there are no params", () => {
    const path = "/some-path";
    const url = createUrl(path);
    expect(url).toBe(path);
  });

  it("returns the path when the params are an empty object", () => {
    const path = "/some-path";
    const url = createUrl(path, {});
    expect(url).toBe(path);
  });
});
