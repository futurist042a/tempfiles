import { render, screen, fireEvent } from "@testing-library/react";
import { RouterProvider, createMemoryRouter, useNavigate } from "react-router-dom";
import HomeBackButton from "@/components/common/HomeBackButton";

const RedirectToTest = () => {
  const navigate = useNavigate();
  return (
    <button type="button" onClick={() => navigate("/test")}>
      go
    </button>
  );
};

const mockRouter = createMemoryRouter([
  {
    path: "/",
    element: <RedirectToTest />,
  },
  {
    path: "/test",
    element: <HomeBackButton />,
  },
]);

describe("HomeBackButton", () => {
  it("redirects to the home page on click", () => {
    render(<RouterProvider router={mockRouter} />);

    const goButton = screen.getByRole("button");
    fireEvent.click(goButton);
    expect(mockRouter.state.location.pathname).toBe("/test");

    const homeBackButton = screen.getByTestId("HomeBackButton");
    const actualButton = homeBackButton.querySelector("button");
    fireEvent.click(actualButton);
    expect(mockRouter.state.location.pathname).toBe("/");
  });
});
