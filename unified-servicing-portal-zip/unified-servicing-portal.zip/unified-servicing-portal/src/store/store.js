import { applyMiddleware, compose, createStore } from "redux";
import { loadUser } from "redux-oidc";
import thunk from "redux-thunk";
import { userManager } from "@/config/user-manager";
import createReducer from "@/reducers";
import { oidcMiddleware } from "./oidcMiddleware";

/**
 * Cf. redux docs:
 * https://redux.js.org/recipes/code-splitting/#defining-an-injectreducer-function
 */

function configureStore() {
  const composeEnhancers =
    typeof window === "object" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
      ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__({})
      : compose;

  const createStoreWithMiddleware = composeEnhancers(
    applyMiddleware(thunk.withExtraArgument(), oidcMiddleware),
  )(createStore);
  const Store = createStoreWithMiddleware(createReducer());

  Store.asyncReducers = {};

  return Store;
}

const store = configureStore();

loadUser(store, userManager);

export default store;
