import { silentRenewError } from "redux-oidc";
import { router } from "@/router";

const silentRenewErrorType = silentRenewError().type;

export const oidcMiddleware = () => (next) => (action) => {
  if (action.type === silentRenewErrorType) {
    router.navigate("/invalid-session");
  }
  return next(action);
};
