import { createSlice } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

const initialState = {
  initiateOnboardingFetchingStatus: API_CALL_STATUS.PENDING,
  fetchingFormStatus: API_CALL_STATUS.PENDING,
  tabList: [],
  tabListStatus: API_CALL_STATUS.PENDING,
  checkList: {},
  auditTrailDetails: {},
  activeForm: null,
};

export const initiateOnboardingSlice = createSlice({
  name: "initiateOnboarding",
  initialState,
  reducers: {
    /* eslint-disable no-param-reassign */
    startFetchingGetTab(state) {
      state.tabListStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingGetTab(state, action) {
      state.tabList = action.payload.data;
      state.tabListStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingGetTab(state) {
      state.tabListStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingMetaData(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingMetaData(state, action) {
      const { tabList, ...otherProperties } = action.payload.data;
      if (tabList) {
        state.tabList = tabList;
        state.tabListStatus = API_CALL_STATUS.SUCCESS;
      }
      state.auditTrailDetails = otherProperties;
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingMetaData(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingForm(state) {
      state.fetchingFormStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingForm(state, action) {
      state.activeForm = action.payload.data?.objValue;
      state.fetchingFormStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingForm(state) {
      state.fetchingFormStatus = API_CALL_STATUS.FAILED;
    },
    startPostingForm(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.STARTED;
    },
    successPostingForm(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.SUCCESS;
    },
    failedPostingForm(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.FAILED;
    },
    startPostMetaData(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.STARTED;
    },
    successPostMetaData(state, action) {
      const { tabList, ...otherProperties } = action.payload.data;
      if (tabList) state.tabList = tabList;
      state.auditTrailDetails = otherProperties;
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.SUCCESS;
    },
    failedPostMetaData(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.FAILED;
    },
    startPostDataPoint(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.STARTED;
    },
    successPostDataPoint(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.SUCCESS;
    },
    failedPostDataPoint(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.FAILED;
    },
    updateTabList(state, action) {
      state.tabList = action.payload;
      state.updatingTabListStatus = API_CALL_STATUS.SUCCESS;
    },
    getFormData(state, action) {
      state.formData = {
        formJson: { ...state.formData?.formJson, ...action.payload?.formJson },
        state: { ...state.formData?.state, ...action.payload?.state },
        dataPointInfo: { ...state.formData?.dataPointInfo, ...action?.payload?.dataPointInfo },
      };
    },
    startInitiateOnboarding(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.STARTED;
    },
    successInitiateOnboarding(state, action) {
      state.checkList = action.payload?.data?.checkList[0];
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.SUCCESS;
    },
    failedInitiateOnboarding(state) {
      state.initiateOnboardingFetchingStatus = API_CALL_STATUS.FAILED;
    },
    continueInitiateOnboarding(state, action) {
      state.checkList = action.payload?.checkList[0];
      state.fetchingInitiateOnboarding = API_CALL_STATUS.SUCCESS;
    },
    clearInitiateOnboarding(state) {
      Object.keys(state).forEach((key) => {
        state[key] = initialState[key];
      });
    },
    /* eslint-enable no-param-reassign */
  },
});

export const {
  startFetchingGetTab,
  successFetchingGetTab,
  failedFetchingGetTab,
  startFetchingMetaData,
  successFetchingMetaData,
  failedFetchingMetaData,
  startFetchingForm,
  successFetchingForm,
  failedFetchingForm,
  startPostingForm,
  successPostingForm,
  failedPostingForm,
  startPostMetaData,
  successPostMetaData,
  failedPostMetaData,
  startPostDataPoint,
  successPostDataPoint,
  failedPostDataPoint,
  updateTabList,
  getFormData,
  startInitiateOnboarding,
  successInitiateOnboarding,
  failedInitiateOnboarding,
  continueInitiateOnboarding,
  clearInitiateOnboarding,
} = initiateOnboardingSlice.actions;
