import { createSlice } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

const initialState = {
  countries: {
    status: API_CALL_STATUS.PENDING,
    data: [],
  },
  states: {
    status: API_CALL_STATUS.PENDING,
    data: [],
  },
};

export const dropdownsSlice = createSlice({
  name: "dropdowns",
  initialState,
  reducers: {
    /* eslint-disable no-param-reassign */
    getCountriesStarted(state) {
      state.countries.status = API_CALL_STATUS.STARTED;
    },
    getCountriesSuccess(state, action) {
      state.countries.status = API_CALL_STATUS.SUCCESS;
      state.countries.data = action.payload;
    },
    getCountriesFailed(state) {
      state.countries.status = API_CALL_STATUS.FAILED;
    },
    getStatesStarted(state) {
      state.states.status = API_CALL_STATUS.STARTED;
    },
    getStatesSuccess(state, action) {
      state.states.status = API_CALL_STATUS.SUCCESS;
      state.states.data = action.payload;
    },
    getStatesFailed(state) {
      state.states.status = API_CALL_STATUS.FAILED;
    },
    /* eslint-enable no-param-reassign */
  },
});

export const {
  getCountriesFailed,
  getCountriesStarted,
  getCountriesSuccess,
  getStatesFailed,
  getStatesStarted,
  getStatesSuccess,
} = dropdownsSlice.actions;
