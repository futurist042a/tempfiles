import { combineReducers } from "redux";
import { reducer as oidcReducer } from "redux-oidc";
import { dashboardTableSlice } from "./dashboardTableSlice";
import { dropdownsSlice } from "./dropdownsSlice";
import { eventDetailsSlice } from "./eventDetailsSlice";
import { initiateOnboardingSlice } from "./initiateOnboardingSlice";
import { userSlice } from "./userSlice";

export default function createReducer(asyncReducers) {
  return combineReducers({
    oidc: oidcReducer,
    dashboardTable: dashboardTableSlice.reducer,
    dropdowns: dropdownsSlice.reducer,
    eventDetails: eventDetailsSlice.reducer,
    initiateOnboarding: initiateOnboardingSlice.reducer,
    user: userSlice.reducer,
    ...asyncReducers,
  });
}
