import { createSlice } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

const initialState = {
  taskListStatus: API_CALL_STATUS.PENDING,
  taskList: [],
  tableMetadataStatus: API_CALL_STATUS.PENDING,
  tableMetadata: {},
};

//TODO: map headers to common objects (string4 has been renamed)
//      make exception case for status and customSubrow

export const dashboardTableSlice = createSlice({
  name: "dashboardTable",
  initialState,
  reducers: {
    /* eslint-disable no-param-reassign */
    startFetchingTaskList(state) {
      //console.log("start fetching task list")
      state.taskListStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingTaskList(state, action) {
      //console.log("good fetching task list")
      state.taskList = action.payload;
      state.taskListStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingTaskList(state) {
      //console.log("failed fetching task list")
      state.taskListStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingTableMetadata(state) {
      //console.log("start fetching metadata")

      state.tableMetadataStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingTableMetadata(state, action) {
      //console.log("good fetching metadata")
      state.tableMetadata = action.payload;
      state.tableMetadataStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingTableMetadata(state) {
      //onsole.log("failed fetching metadata")
      state.tableMetadataStatus = API_CALL_STATUS.FAILED;
    },
    /* eslint-enable no-param-reassign */
  },
});

export const {
  startFetchingTaskList,
  successFetchingTaskList,
  failedFetchingTaskList,
  startFetchingTableMetadata,
  successFetchingTableMetadata,
  failedFetchingTableMetadata,
} = dashboardTableSlice.actions;
