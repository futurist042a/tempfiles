import { createSlice } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

const initialState = {
  roleListStatus: API_CALL_STATUS.PENDING,
  roleList: [],
  permission: {},
};

export const userSlice = createSlice({
  name: "userDetails",
  initialState,
  reducers: {
    /* eslint-disable no-param-reassign */
    startUserRoleList(state) {
      state.roleListStatus = API_CALL_STATUS.STARTED;
    },
    successUserRoleList(state, action) {
      state.roleList = action.payload.userRoles;
      state.permission = action.payload.userPermission;
      state.roleListStatus = API_CALL_STATUS.SUCCESS;
    },
    failedUserRoleList(state) {
      state.roleListStatus = API_CALL_STATUS.FAILED;
    },
    /* eslint-enable no-param-reassign */
  },
});

export const { startUserRoleList, successUserRoleList, failedUserRoleList } = userSlice.actions;
