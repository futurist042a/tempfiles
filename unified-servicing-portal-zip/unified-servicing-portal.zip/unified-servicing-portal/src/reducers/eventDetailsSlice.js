import { createSlice } from "@reduxjs/toolkit";
import { API_CALL_STATUS } from "@/constants/constant";

const initialState = {
  headerDetail: null,
  headerEventStatus: API_CALL_STATUS.PENDING,
  taskList: null,
  taskListStatus: API_CALL_STATUS.PENDING,
  tasksTableMetadata: null,
  tasksTableMetadataStatus: API_CALL_STATUS.PENDING,
  historyTableMetaData: null,
  historyTableMetaDataStatus: API_CALL_STATUS.PENDING,
  historyList: null,
  historyListStatus: API_CALL_STATUS.PENDING,
};

export const eventDetailsSlice = createSlice({
  name: "eventDetails",
  initialState,
  reducers: {
    /* eslint-disable no-param-reassign */
    startFetchingDetailTaskList(state) {
      state.taskListStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingDetailTaskList(state, action) {
      state.taskList = action.payload;
      state.taskListStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingDetailTaskList(state) {
      state.taskListStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingHeader(state) {
      state.headerEventStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingHeader(state, action) {
      state.headerDetail = action.payload.data;
      state.headerEventStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingHeader(state) {
      state.headerEventStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingTasksTableMetadata(state) {
      state.tasksTableMetadataStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingTasksTableMetadata(state, action) {
      state.tasksTableMetadata = action.payload;
      state.tasksTableMetadataStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingTasksTableMetadata(state) {
      state.tasksTableMetadataStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingDetailHistoryList(state) {
      state.historyListStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingDetailHistoryList(state, action) {
      state.historyList = action.payload.data;
      state.historyListStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingDetailHistoryList(state) {
      state.historyListStatus = API_CALL_STATUS.FAILED;
    },
    startFetchingHistoryTableMetadata(state) {
      state.historyTableMetaDataStatus = API_CALL_STATUS.STARTED;
    },
    successFetchingHistoryTableMetadata(state, action) {
      state.historyTableMetaData = action.payload;
      state.historyTableMetaDataStatus = API_CALL_STATUS.SUCCESS;
    },
    failedFetchingHistoryTableMetadata(state) {
      state.historyTableMetaDataStatus = API_CALL_STATUS.FAILED;
    },
    clearEventDetails(state) {
      Object.keys(state).forEach((key) => {
        state[key] = initialState[key];
      });
    },
    /* eslint-enable no-param-reassign */
  },
});

export const {
  startFetchingDetailTaskList,
  successFetchingDetailTaskList,
  failedFetchingDetailTaskList,
  successFetchingHeader,
  failedFetchingHeader,
  startFetchingHeader,
  startFetchingTasksTableMetadata,
  successFetchingTasksTableMetadata,
  failedFetchingTasksTableMetadata,
  startFetchingDetailHistoryList,
  successFetchingDetailHistoryList,
  failedFetchingDetailHistoryList,
  startFetchingHistoryTableMetadata,
  successFetchingHistoryTableMetadata,
  failedFetchingHistoryTableMetadata,
  clearEventDetails,
} = eventDetailsSlice.actions;
