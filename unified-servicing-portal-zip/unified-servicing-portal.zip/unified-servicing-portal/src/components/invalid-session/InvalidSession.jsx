import { useNavigate } from "react-router";
import USBButton from "@/components/usb-shield/react-button";
import { USBIconWarningSign } from "@/components/usb-shield/react-icons";
import { useReloadOnUnmount } from "@/hooks/useReloadOnUnmount";
import { InvalidSessionStyles } from "./InvalidSession.styles";

export default function InvalidSession() {
  useReloadOnUnmount();
  const navigate = useNavigate();

  const handleClick = () => {
    navigate("/");
  };

  return (
    <InvalidSessionStyles>
      <USBIconWarningSign colorVariant="warning" />
      <p>Your session has expired.</p>
      <USBButton variant="utility" handleClick={handleClick}>
        Click here to log back in
      </USBButton>
    </InvalidSessionStyles>
  );
}
