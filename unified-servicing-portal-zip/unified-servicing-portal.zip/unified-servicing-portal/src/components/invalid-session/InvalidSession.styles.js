import styled from "styled-components";

export const InvalidSessionStyles = styled.div`
  min-height: 100vh;
  background-color: var(--header-blue);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  color: white;
  font-size: calc(var(--font-size-extra-large) + 0px);

  svg {
    height: 80px;
    width: 80px;
  }
`;
