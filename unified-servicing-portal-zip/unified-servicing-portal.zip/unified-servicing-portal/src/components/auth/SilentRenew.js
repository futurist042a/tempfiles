import { processSilentRenew } from "redux-oidc";

const SilentRenew = processSilentRenew();

export default SilentRenew;
