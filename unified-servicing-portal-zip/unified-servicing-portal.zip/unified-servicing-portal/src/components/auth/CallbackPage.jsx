import { useLocation } from "react-router";
import { useNavigate } from "react-router-dom";
import { CallbackComponent } from "redux-oidc";
import { userManager } from "@/config/user-manager";

export default function CallbackPage() {
  const navigate = useNavigate();
  const location = useLocation();

  const successCallback = (user) => {
    if (user?.state) {
      navigate(user.state, { replace: true });
      return;
    }
    navigate("/");
  };

  const errorCallback = (error) => {
    console.log(userManager)
    console.log(error)
    if (location?.search.includes("server_error")) {
      navigate("/invalid-session");
    }
    navigate("/error");
  };

  return (
    <CallbackComponent
      userManager={userManager}
      successCallback={successCallback}
      errorCallback={errorCallback}
    >
      <div>Redirecting...</div>
    </CallbackComponent>
  );
}
