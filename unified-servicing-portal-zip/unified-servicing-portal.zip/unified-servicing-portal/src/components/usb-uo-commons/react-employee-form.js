import EmployeeForm from "@usb-uo-commons/react-employee-form";
import "@usb-uo-commons/react-employee-form/dist/library/styles/index.css";

import "@usb-shield/react-button/dist/library/styles/index.css";
import "@usb-shield/react-forms-base/dist/library/styles/index.css";
import "@usb-shield/react-forms-combobox/dist/library/styles/index.css";
import "@usb-shield/react-icons/dist/library/styles/index.css";
import "@usb-shield/react-modal/dist/library/styles/index.css";
import "@usb-shield/react-notification/dist/library/styles/index.css";

export default EmployeeForm;
