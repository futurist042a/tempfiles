import Page from "@usb-uo-commons/react-page";
//import "@usb-uo-commons/react-page/dist/library/styles/index.css";

export default Page;
