import Dashboard from "@usb-uo-commons/react-dashboard";
import "@usb-uo-commons/react-dashboard/dist/library/styles/index.css";

import "@usb-shield/react-button/dist/library/styles/index.css";
import "@usb-shield/react-icons/dist/library/styles/index.css";
import "@usb-shield/react-notification/dist/library/styles/index.css";
import "@usb-shield/react-search-input/dist/library/styles/index.css";
import "@usb-shield/react-tabs/dist/library/styles/index.css";

export default Dashboard;
