import UOTableWithSearch from "@usb-uo-commons/react-table-with-search";
import "@usb-uo-commons/react-table-with-search/dist/library/styles/index.css";

export default UOTableWithSearch;
