import Footer from "@usb-uo-commons/react-footer";
import "@usb-uo-commons/react-footer/dist/library/styles/index.css";

export default Footer;
