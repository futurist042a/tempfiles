import UOUploadDocument from "@usb-uo-commons/react-upload-document/dist/umd";
import "@usb-uo-commons/react-upload-document/dist/library/styles/index.css";

import "@usb-inner-src/document-upload/dist/library/styles/index.css";
import "@usb-inner-src/react-progress-card/dist/library/styles/index.css";

export default UOUploadDocument;
