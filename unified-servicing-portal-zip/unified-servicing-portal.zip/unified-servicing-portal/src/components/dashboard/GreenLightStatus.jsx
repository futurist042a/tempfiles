import PropTypes from "prop-types";
import USBProgressIndicator from "@/components/usb-shield/react-progress-indicator";
import { GreenLightStatusStyles } from "./GreenLightStatus.styles";

export const GreenLightStatus = ({ current, total }) => {
  const completedStepsInPercentage = (current / total) * 100;
  return (
    <GreenLightStatusStyles>
      <USBProgressIndicator
        currentStep={current}
        variant="percentage"
        percentageValue={completedStepsInPercentage}
        addClasses={completedStepsInPercentage === 100 && "completed"}
      />
      <span>
        {current} of {total}
      </span>
    </GreenLightStatusStyles>
  );
};

GreenLightStatus.propTypes = {
  current: PropTypes.number.isRequired,
  total: PropTypes.number.isRequired,
};

export default GreenLightStatus