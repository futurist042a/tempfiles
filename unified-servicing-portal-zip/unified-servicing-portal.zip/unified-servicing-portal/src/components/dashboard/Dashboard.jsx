import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

import { getTableMetaData, getCommonObjects } from "@/actions/dashboardTableAction";
import { Loader } from "@/components/common/Loader";
import ShieldTable from "@/components/common/ShieldTable";
import UODashboard from "@/components/usb-uo-commons/react-dashboard";
import {
  selectDashboardLoading,
  selectDashboardSuccess,
  selectIsMetadataAvailable,
  selectTableMetadata,
  selectTaskList,
} from "@/selectors/dashboardTableSelectors";
import { commonObjectsToTableData } from "@/utils/commonObjectsToTableData.tsx";
import { tableMetaDataToColumnData } from "@/utils/tableMetaDataToColumnData";
import { Cell } from "./Cell";
import { DashboardStyles } from "./Dashboard.styles";
import { RowSubComponent } from "./RowSubComponent";
import Filter from "../common/Filter";

export default function Dashboard() {
  // ? Im not sure this is needed
  // DisableBackButton();
  const dispatch = useDispatch();
  // tableMetaData={headers:[],accessor:[].dataType:[]}
  const tableMetaData = useSelector(selectTableMetadata);
  const commonObjectList = useSelector(selectTaskList);
  const isMetadataAvailable = useSelector(selectIsMetadataAvailable);
  const isLoading = useSelector(selectDashboardLoading);
  const isSuccess = useSelector(selectDashboardSuccess);
  const navigate = useNavigate();
  const [filteredCommonObjectList, setFilteredCommonObjectList] = useState([]);
  useEffect(() => {
    dispatch(getCommonObjects());
    dispatch(getTableMetaData());
  }, []);

  useEffect(() => {
    setFilteredCommonObjectList(commonObjectList);
  }, [commonObjectList]);

  const columnData = useMemo(() => {
    const data = tableMetaDataToColumnData(tableMetaData);

    console.log("columnData:", data);
    return data;
  }, [tableMetaData]);

  const tableData = useMemo(() => {
    const data = commonObjectsToTableData(tableMetaData, filteredCommonObjectList);
    console.log("tableData", data);
    return data;
  }, [tableMetaData, filteredCommonObjectList]);

  const subComponent = (props) => {
    return <RowSubComponent {...props} />;
  };

  //! LOG HERE
  // console.log(columnData);

  // console.log("before")
  // console.log(commonObjectList)
  // console.log("after")
  //console.log(tableData);
  // console.log(tableData);

  // console.log(`isLoading: ${isLoading}`)
  // console.log(`isSuccess: ${isSuccess}`)
  // console.log(`isMetadataAvailable: ${isMetadataAvailable}`)

  // We add plus 1 to account for the toggle header
  return (
    <DashboardStyles numColumns={columnData.length + 1}>
      <Loader loading={isLoading}>
        {isSuccess && (
          <UODashboard
            title="Unified Servicing Portal"
            searchProps={{ placeholder: "Search onboardings" }}
            handleInitiateOnbordingClick={() => {
              //console.log("clicked button, do nothing");
            }}
            tabsProps={{ tabs: ["Servicing Events"] }}
            notifProps={{
              isNotified: location.state?.showToast,
              variant: "confirmation",
              addClasses: "document-toast",
              notificationData: [
                {
                  text: `${location.state?.message}`,
                },
              ],
              handleClose: () => {
                navigate("/", { replace: true });
              },
            }}
            TableComponent={
              <>
                <Filter
                  objList={commonObjectList}
                  setObjList={setFilteredCommonObjectList}
                  CheckList={[
                    { label: "Active", filterFunction: FilterActiveCommonObjects },
                    { label: "Corporate Trust", filterFunction: FilterByCorporateTrust },
                    { label: "Corporate and Commercial Banking", filterFunction: FilterByCCB },
                  ]}
                />
                <ShieldTable
                  borders="none"
                  expandTable="expandCell"
                  expandCellGrid={{
                    display: "grid",
                    gridTemplateColumns: "18.31rem 10rem 10rem 10rem 11.25rem 12.93rem 56px",
                  }}
                  tableData={tableData} // {fakeData}
                  columnStructure={[
                    ...(isMetadataAvailable ? columnData : []),
                    // Add another column that is the dropdown toggle button
                    {
                      header: "Toggle",
                      id: "cell-expander",
                      disableSortBy: true,
                      Cell: cell,
                    },
                  ]}
                  // This is the component that is shown when expanded
                  rowSubComponent={subComponent}
                  id="usb-table-onboarding-id"
                  key="usb-table-onboarding-id"
                  isSortable
                  isZebraStriped
                />
              </>
            }
          />
        )}
      </Loader>
    </DashboardStyles>
  );
}

function cell(row) {
  return <Cell row={row} />;
}
// /*
//  * The purpose of this code is to prevent the browser's back button
//  * from navigating back to the previous page when the user clicks it,
//  * effectively disabling the back button.
//  */
// function DisableBackButton() {
//   useEffect(
//     () => {
//       window.history.replaceState({}, document.title);
//     },
//     // Only run once
//     [],
//   );
// }

// const fakeHeaders = [
//   {
//     header: "Client Legal Name",
//     fieldFor: "clientLegalName",
//     isSortable: true,
//     dataType: "String",
//     sortValues: ["Oldest", "Newest"],
//     customDateFormat: "MM/DD/YYYY",
//     columnType: "date",
//     wrapContent: true,
//     accessor: "clientLegalName",
//     type: "String",
//   },
//   {
//     header: "Business Line",
//     fieldFor: "businessLine",
//     isSortable: true,
//     dataType: "String",
//     sortValues: ["Oldest", "Newest"],
//     customDateFormat: "MM/DD/YYYY",
//     columnType: "date",
//     wrapContent: true,
//     accessor: "businessLine",
//     type: "String",
//   },
//   {
//     header: "Process Group",
//     fieldFor: "processGroup",
//     isSortable: true,
//     dataType: "String",
//     sortValues: ["Oldest", "Newest"],
//     customDateFormat: "MM/DD/YYYY",
//     columnType: "date",
//     wrapContent: true,
//     accessor: "processGroup",
//     type: "String",
//   },
//   {
//     header: "Product",
//     fieldFor: "product",
//     isSortable: true,
//     dataType: "String",
//     sortValues: ["Oldest", "Newest"],
//     customDateFormat: "MM/DD/YYYY",
//     columnType: "date",
//     wrapContent: true,
//     accessor: "product",
//     type: "String",
//   },
//   {
//     header: "Status",
//     fieldFor: "status",
//     isSortable: true,
//     dataType: "String",
//     sortValues: ["Oldest", "Newest"],
//     customDateFormat: "MM/DD/YYYY",
//     columnType: "date",
//     wrapContent: false,
//     accessor: "status",
//     type: "String",
//   },
// ];
// const fakeData = [
//   {
//     dateSend: "test",
//     clientLegalName: "test",
//     businessLine: "test",
//     processGroup: "test",
//     product: "test",
//     status: "test",
//   },
// ];

function FilterActiveCommonObjects(commonObj) {
  const tasks = commonObj.processDetails?.taskDetails;
  console.log(commonObj);
  //If at least one of the urls is not false
  const hasAtLeastOneUrl = tasks?.some((task) => {
    // empty string is 'falsy' in javascript
    return task.taskURL;
  });
  return hasAtLeastOneUrl;
}

function FilterByCorporateTrust(commonObj) {
  const productFamily = commonObj.productDetails?.productFamily;
  return productFamily.toLowerCase() === "corporate trust";
}

function FilterByCCB(commonObj) {
  const productFamily = commonObj.productDetails?.productFamily;
  return productFamily.toLowerCase() === "corporate and commercial banking";
}
