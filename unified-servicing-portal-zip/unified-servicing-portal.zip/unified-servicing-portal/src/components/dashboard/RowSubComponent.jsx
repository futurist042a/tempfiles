import PropTypes from "prop-types";
import React from "react";
import { Link } from "react-router-dom";
import ListToolTip from "@/components/common/ListToolTip.tsx";
import { RowExpandedIconsComponent } from "@/components/common/RowExpandedIconsComponent";
import { RowSubComponentStyles } from "./RowSubComponent.styles";
import USBDividerLine from "@usb-shield/react-divider-line";
import "@usb-shield/react-divider-line/dist/library/styles/index.css";
import { CompletedTasks } from "@/components/common/CompletedTasks";

export const RowSubComponent = ({ row }) => {
  const headersData = row?.original?.customSubRow; //TODO find the field that will take in a list of headers and data
  //[{HeaderName:string ,headerValue:string }]
  const tasks = row.original.tasks ?? [];
  //console.log(row.original.tasks);
  //let tasks = []

  //const tasks = ["task1 a long string", "Twenty Five Characters--", "task3"];

  return (
    <RowSubComponentStyles>
      <div className={"subview-container"}>
        {headersData &&
          headersData.map((hed, index) => createTaskHeaderAndValue(hed, index, tasks))}
      </div>
      <div className="divider-line">
        <USBDividerLine id="divider-line" />
      </div>
      <CompletedTasks tasks={tasks} />
    </RowSubComponentStyles>
  );
};

function createTaskHeaderAndValue(hed, index, tasks) {
  const inProgress =
    hed.headerValue.toLowerCase() === "in progress" || hed.headerValue.toLowerCase() === "active";

  // filter our the tasks that are not in the Received status because we cannot map closed tasks to the appropriate milestones
  let filteredTasks = tasks.filter((task) => {
    return task.status === "Received";
  })


  const hasList = filteredTasks.length > 0;

  // if (inProgress && hasList) {
  const tasksArray = filteredTasks.map((task) => {
    const taskURL = task?.taskURL ?? "";
    const taskName = task?.taskName ?? "";
    return taskURL ? RedirectLink(taskURL, taskName) : <div>{taskName}</div>;
  });

  //Has a list and is the in task status
  //   return (
  //     <div key={hed.headerName} className={`subview-cell-${index}`}>
  //       <div className="subview-header-name">{hed.headerName}</div>
  //       <div className="step-status-container">
  //         <RowExpandedIconsComponent headerValue={hed.headerValue} />
  //         <div className="subview-header-value">{hed.headerValue}</div>
  //         <ListToolTip position="bottom" list={tasksArray} key={index} />
  //       </div>
  //     </div>
  //   );
  // }

  //Regular task
  return (
    <div key={hed.headerName} className={`subview-cell`}>
      <div className="subview-header-name">{hed.headerName}</div>
      <div className="step-status-container">
        <RowExpandedIconsComponent headerValue={hed.headerValue} />
        <div className="subview-header-value">{hed.headerValue}</div>
        {inProgress && hasList && <ListToolTip position="bottom" list={tasksArray} key={index} />}
      </div>
    </div>
  );
}

RowSubComponent.propTypes = {
  row: PropTypes.shape({
    original: PropTypes.shape({
      customSubRow: PropTypes.arrayOf(
        PropTypes.shape({
          headerName: PropTypes.node.isRequired,
          headerValue: PropTypes.node.isRequired,
        }).isRequired,
      ).isRequired,
      //onboardingId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
      tasks: PropTypes.array.isRequired,
    }).isRequired,
  }).isRequired,
};

// RowSubComponent.propTypes = {
//   headersData: PropTypes.arrayOf(
//     PropTypes.shape({
//       headerName: PropTypes.node.isRequired,
//       headerValue: PropTypes.node.isRequired,
//     }).isRequired,
//   ).isRequired,
//   onboardingId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
// };

export default RowSubComponent;

const RedirectLink = (taskUrl, taskName) => {
  //Reminder: rel="noreferrer" is a attribute in HTML is used to instruct the browser to omit the Referer header and leak no referrer information when navigating to the target resource
  return (
    <a href={taskUrl} target="_blank">{taskName}</a>
  );
};
