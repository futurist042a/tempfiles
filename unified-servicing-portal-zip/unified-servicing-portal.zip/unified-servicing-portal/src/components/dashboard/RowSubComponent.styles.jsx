import styled from "styled-components";

export const RowSubComponentStyles = styled.div`
  .subview-container {
    display: grid;
    grid-template-columns: repeat(3, max-content);
    justify-content: space-around;
    grid-template-areas:
      "top-left top-middle top-right"
      "bottom-left bottom-middle bottom-right";
  }

  .subview-cell-0 {
    grid-area: top-left;
  }

  .subview-cell-1 {
    grid-area: bottom-left;
  }

  .subview-cell-2 {
    grid-area: top-middle;
  }

  .subview-cell-3 {
    grid-area: bottom-middle;
  }

  .subview-cell-4 {
    grid-area: top-right;
  }

  .subview-cell-5 {
    grid-area: bottom-right;
  }

  .subview-header-name {
    font-weight: 500;
    font-size: 14px;
  }

  .subview-header-value {
    margin-bottom: 1rem;
    margin-top: 0.5rem;
  }

  .refresh-icon > svg,
  .success-icon > svg,
  .clock-icon > svg {
    height: 20px;
    width: 20px;
    margin-right: 10px;
  }

  .success-icon.default {
    color: green;
    fill: green;
  }
  .step-status-container {
    font-size: 14px;
    display: flex;
    justify-content: start;
    align-items: center;
  }

  .progress-bar {
    width: 90%; /* Set the width of the progress bar container */
    //background-color: red; /* Set the background color of the progress bar container */
    display: block; /* Use flexbox for centering */
    align-items: center; /* Center the progress bar vertically */
    justify-content: center; /* Center the progress bar horizontally */
    margin: 0 auto; /* Center the progress bar container horizontally */
  }

  .progress {
    width: 100%;
    height: 100%; /* Set the height of the progress bar */
    //background-color: #007bff; /* Set the color of the progress bar */
  }

  .divider-line {
    width: 90%;
    align-items: center;
    justify-content: center;
    padding-left: 5%
  }

  .link{
    color: blue;
    text-decoration: none;
   position: relative;
   cursor: pointer
  }
`;
