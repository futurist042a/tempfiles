import PropTypes from "prop-types";
import { USBIconChevronDown, USBIconChevronUp } from "@/components/usb-shield/react-icons";

export const Cell = ({ row }) => {
  const buttonId = `sub-row-btn-${row.parentId}`;
  return (
    <button
      aria-label="show details"
      aria-labelledby={`${buttonId} td-${row.cell.row.index}-0_name`}
      aria-expanded={row.isExpanded}
      className="table-expander"
      id={buttonId}
      type="button"
      {...row.cell.row.getToggleRowExpandedProps({ title: undefined })}
    >
      {row.isExpanded ? (
        <USBIconChevronUp addClasses="table-icon-hover" ariaHidden />
      ) : (
        <USBIconChevronDown addClasses="table-icon-hover" ariaHidden />
      )}
    </button>
  );
};

Cell.propTypes = {
  row: PropTypes.shape({
    isExpanded: PropTypes.bool,
    cell: PropTypes.shape({
      row: PropTypes.shape({
        index: PropTypes.number.isRequired,
        getToggleRowExpandedProps: PropTypes.func.isRequired,
      }).isRequired,
    }).isRequired,
    parentId: PropTypes.string.isRequired,
  }).isRequired,
};
