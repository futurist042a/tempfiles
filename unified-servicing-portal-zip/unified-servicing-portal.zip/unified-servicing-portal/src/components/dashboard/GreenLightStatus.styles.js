import styled from "styled-components";

export const GreenLightStatusStyles = styled.div`
  width: 100%;
  .usb-progress-indicator__steps li {
    position: relative;
    height: 0.25rem;
    flex: 0 0 0;
    background-color: #cdcdd3;
  }

  .usb-progress-indicator__bar {
    z-index: 0;
  }

  .usb-progress-indicator__steps--percentage li:first-of-type:after,
  .usb-progress-indicator__steps--percentage li:last-of-type:after {
    display: none;
  }
  .usb-progress-indicator__percentage {
    display: none;
  }
  .usb-progress-indicator--percentage_variant {
    padding: unset;
  }
  .usb-progress-indicator progress[value] {
    border-radius: 50px;
  }

  .usb-progress-indicator {
    margin: 0.5rem 0 !important;
    &.completed {
      progress::-webkit-progress-bar {
        background-color: var(--lime-green);
        width: 100%;
      }

      progress::-webkit-progress-value {
        background-color: var(--lime-green) !important;
      }

      progress::-moz-progress-bar {
        background-color: var(--lime-green) !important;
      }
    }
  }
`;
