import { useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { getTableMetaData, getTaskList } from "@/actions/dashboardTableAction";
import { initiateOnboardingAction } from "@/actions/initiateOnboardingAction";
import { Loader } from "@/components/common/Loader";
import ShieldTable from "@/components/common/ShieldTable";
import { StyledLink } from "@/components/common/StyledLink";
import UODashboard from "@/components/usb-uo-commons/react-dashboard";
import { INITIATE_ONBOARDING, INITIATE_ONBOARDING_FORM_NAME } from "@/constants/constant";
import {
  selectDashboardLoading,
  selectDashboardSuccess,
  selectIsMetadataAvailable,
  selectTableMetadata,
  selectTaskList,
} from "@/selectors/dashboardTableSelectors";
import { selectUserPermission, selectUserRoleList } from "@/selectors/userSelectors";
import "@/scss/_pagination.scss";
import { createUrl } from "@/utils/createUrl";
import { Cell } from "./Cell";
import { DashboardStyles } from "./Dashboard.styles";
import { GreenLightStatus } from "./GreenLightStatus";
import { RowSubComponent } from "./RowSubComponent";

const tabsProps = { tabs: ["Onboardings"] };

const createBatches = (numberOfTasks = 0) => {
  const batchAmount = 10;
  const pages = Math.ceil(numberOfTasks / batchAmount);
  const batchGroups = [];
  for (let index = 1; index <= pages; index++) {
    const numberOfRows = index * batchAmount;
    batchGroups.push({ label: `${numberOfRows} rows`, value: numberOfRows });
  }
  return batchGroups;
};

const customCompareFunctions = {
  specialCellLinkType: (a, b) =>
    a.props.children.toString().localeCompare(b.props.children.toString()),
};

const expandCellGrid = {
  display: "grid",
  gridTemplateColumns: "18.31rem 10rem 10rem 10rem 11.25rem 12.93rem 56px",
};

export default function Dashboard() {
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch();

  const isLoading = useSelector(selectDashboardLoading);
  const isMetadataAvailable = useSelector(selectIsMetadataAvailable);
  const isSuccess = useSelector(selectDashboardSuccess);
  const tableHeaders = ["12", "123", "4"]; //useSelector(selectTableMetadata);
  const tableRows = useSelector(selectTaskList);
  const userPermission = useSelector(selectUserPermission);
  const userRoleList = useSelector(selectUserRoleList);

  useEffect(() => {
    window.history.replaceState({}, document.title);
  }, []);

  useEffect(() => {
    if (userRoleList?.length) {
      if (!isMetadataAvailable) dispatch(getTableMetaData());
      dispatch(getTaskList("onboardingTask"));
    }
  }, [userRoleList]);

  const handleInitiateOnboardingClick = async () => {
    const { onboardingId, checkListId } = await dispatch(initiateOnboardingAction());
    if (onboardingId && checkListId) {
      navigate(
        createUrl(`/${INITIATE_ONBOARDING}`, {
          onboardingId,
          checklistId: checkListId,
          formName: INITIATE_ONBOARDING_FORM_NAME,
        }),
      );
    }
  };

  const renderCell = (row) => <Cell row={row} />;

  const rowSubComponent = (props) => <RowSubComponent tab="onboardingDataTab" {...props} />;

  const tableData = useMemo(() => {
    return tableRows.map((row) => {
      const obj = {
        ...row,
        clientLegalName: (
          <StyledLink
            to={createUrl("/event-details", {
              onboardingId: row.onboardingId,
              checklistId: row.checklistId,
              taskId: row.taskId,
            })}
          >
            {row.clientLegalName}
          </StyledLink>
        ),
        product: row.product.join(", "),
        greenLightStatus: (
          <GreenLightStatus
            current={row.greenLightStatus.current}
            total={row.greenLightStatus.total}
          />
        ),
      };

      return obj;
    });
  }, [tableRows]);

  console.log(tableHeaders);
  /* cspell:ignore onbording, notifProps */
  return (
    <DashboardStyles>
      {/* <Loader loading={isLoading}>
        {isSuccess && ( */}
      <UODashboard
        title="Corporate segment onboarding"
        initiateOnboardingButtonText="Initiate onboarding"
        searchProps={{ placeholder: "Search onboardings" }}
        handleInitiateOnbordingClick={handleInitiateOnboardingClick}
        tabsProps={tabsProps}
        notifProps={{
          isNotified: location.state?.showToast,
          variant: "confirmation",
          addClasses: "document-toast",
          notificationData: [
            {
              text: `${location.state?.message}`,
            },
          ],
          handleClose: () => {
            navigate("/", { replace: true });
          },
        }}
        isInitiateOnboarding={userPermission?.initiateOnboarding}
        TableComponent={[
          <ShieldTable
            borders="none"
            columnStructure={[
              ...(tableHeaders ?? []),
              {
                header: "Toggle",
                id: "cell-expander",
                disableSortBy: true,
                Cell: renderCell,
              },
            ]}
            content={{
              paginationDropdownItems: createBatches(tableRows.length),
            }}
            customCompareFunctions={customCompareFunctions}
            expandCellGrid={expandCellGrid}
            expandTable="expandCell"
            hasPagination={tableRows.length > 10}
            id="usb-table-onboarding-id"
            isSortable
            isZebraStriped
            key="usb-table-onboarding-id"
            rowSubComponent={rowSubComponent}
            tableData={tableData}
          />,
        ]}
      />
      {/* )}
      </Loader> */}
    </DashboardStyles>
  );
}
