import styled from "styled-components";

// cspell:ignore conatiner
export const DashboardStyles = styled.div`
  padding: 48px 0 20px 0;

  .document-toast {
    padding-top: 20px;

    .usb-button--close-btn {
      margin: -9px !important;
    }
  }

  .task-list-container {
    margin: 0 auto;

    .filter-conatiner {
      margin: 2px;
    }
    h1 {
      margin: 0;
    }
  }

  .tabs__panel {
    padding-left: 0;
    padding-right: 0;
  }

  .usb-table_body--cell {
    vertical-align: middle;
  }

  .usb-table_container-shadow {
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.05), 0 3px 6px rgba(0, 0, 0, 0.1);
  }

  .usb-table_container > div {
    display: flex;
  }

  .usb-table_table {
    flex-grow: 1;
    display: grid;
    grid-template-columns: repeat(${(props) => props.numColumns || "6"}, auto);

    thead,
    tbody {
      display: contents;

      tr {
        display: contents !important;
      }
    }

    td {
      background: white;
    }

    td:not(.usb-table_body--cell--expanded-cell) {
      display: flex;
      align-items: center;
    }

    td.usb-table_body--cell--expanded-cell {
      border-bottom: 1px solid var(--border-color) !important;
      border-left: 0;
      border-right: 0;
    }

    th:focus-within,
    td:focus-within {
      outline: 0 !important;
      box-shadow: inset 0 0 0 2px var(--light-blue);
    }

    tbody tr:nth-child(2n) td {
      background: var(--token-background-secondary);
    }

    th.usb-table_accessor-greenlightstatus {
      span {
        display: none;
      }
      button {
        pointer-events: none;
      }
    }
  }
`;
