import PropTypes from "prop-types";
import React from "react";
import { Navigate } from "react-router-dom";

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, hasSessionExpired: false };
  }

  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      hasSessionExpired: error.toString().includes("user") || error.toString().includes("profile"),
    };
  }

  render() {
    if (this.state.hasError) {
      if (this.state.hasSessionExpired) {
        return <Navigate to="/invalid-session" />;
      }
      return <Navigate to="/error" />;
    }
    return this.props.children || null;
  }
}

ErrorBoundary.propTypes = {
  children: PropTypes.node,
};

export default ErrorBoundary;
