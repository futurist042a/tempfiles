import PropTypes from "prop-types";
import "./ErrorPage.css";
import { useReloadOnUnmount } from "@/hooks/useReloadOnUnmount";

function ErrorPage({ message }) {
  useReloadOnUnmount();

  const displayMessage = message || "An error occurred.";

  return (
    <div className="sessionBody">
      <div className="center">
        <p className="sessionHeader">{displayMessage}</p>
        <p className="sessionContent"> Please contact the Help Desk to get application access.</p>
      </div>
    </div>
  );
}

ErrorPage.propTypes = {
  message: PropTypes.string,
};

export default ErrorPage;
