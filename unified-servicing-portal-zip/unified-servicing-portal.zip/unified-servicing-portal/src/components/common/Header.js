import styled from "styled-components";

export const StandardView = styled.div`
  width: ${(props) => (props.width ? props.width : "1280px")};
  margin: 0px auto 20px;
`;

export const SubHeaderText = styled.div`
  height: auto;
  width: ${(props) => (props.width ? props.width : "250px")};
  max-width: ${(props) => (props.maxWidth ? props.maxWidth : "none")};
  word-break: break-word;
  font-family: "Helvetica Neue", sans-serif;
  color: ${(props) => (props.color ? props.color : "#6e6e6e")};
  font-size: 14px;
  font-weight: ${(props) => (props.fontWeight ? props.fontWeight : "500")};
  letter-spacing: 0;
  line-height: 17px;
  margin-top: ${(props) => (props.marginTop ? props.marginTop : "")};
  margin-bottom: ${(props) => (props.marginBottom ? props.marginBottom : "")};
`;
