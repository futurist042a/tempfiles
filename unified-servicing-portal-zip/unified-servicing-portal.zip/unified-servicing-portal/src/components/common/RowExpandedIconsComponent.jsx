import PropTypes from "prop-types";
import { USBIconClock, USBIconRefresh2, USBIconSuccess } from "@/components/usb-shield/react-icons";

export const RowExpandedIconsComponent = ({ headerValue }) => {
  const lowerCase = headerValue.toLowerCase();
  switch (lowerCase) {
    case "not started":
      return <USBIconClock addClasses="clock-icon" />;
    case "in progress":
    case "in draft":
    case "submitted":
    case "active":
      return <USBIconRefresh2 addClasses="refresh-icon" />;
    case "completed":
    case "completed on":
    case "approved":
    case "signed":
      return <USBIconSuccess addClasses="success-icon" />;
    default:
      return null;
  }
};

RowExpandedIconsComponent.propTypes = {
  headerValue: PropTypes.string.isRequired,
};

export default RowExpandedIconsComponent;