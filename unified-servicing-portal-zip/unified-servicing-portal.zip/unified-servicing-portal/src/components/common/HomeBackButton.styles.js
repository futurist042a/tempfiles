import styled from "styled-components";

export const HomeBackButtonStyles = styled.div`
  margin: 0px auto 20px;

  .usb-button.button--default {
    margin: 1rem auto 1rem -25px !important;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    column-gap: 7px;
  }

  .icon-wrapper {
    width: 20px;
    height: 20px;
  }
`;
