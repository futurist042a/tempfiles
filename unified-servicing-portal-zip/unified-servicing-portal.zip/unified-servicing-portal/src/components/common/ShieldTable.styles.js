import styled from "styled-components";

export const ShieldTableStyles = styled.div`
  .usb-tabs .tabs__panel {
    padding: 0 !important;
  }

  .usb-table_container {
    box-shadow: 0px 0px 2px 2px rgb(0 0 0 / 10%);
  }

  .usb-table_header--row {
    border-bottom: 2px solid var(--border-color);
    align-items: center;
  }

  .usb-table_header--cell,
  .usb-table_header--cell:last-child {
    border-bottom: none;
  }

  .usb-table_header--sort-button {
    display: flex;
    justify-content: flex-start;
    align-items: center;

    .sort-icon {
      padding-left: 5px;
    }
  }

  .usb-table_accessor-clientlegalname,
  .usb-table_accessor-marketername,
  .usb-table_accessor-docreviewer,
  .usb-table_accessor-rm,
  .usb-table_accessor-product,
  .usb-table_accessor-accounttype,
  .usb-table_accessor-task,
  .usb-table_accessor-greenlightstatus,
  .usb-table_accessor-cell-expander {
    display: flex;
    align-items: center;
  }

  .usb-table_pagination {
    & .usb-table_pagination--container {
      & .usb-dropdown {
        & .dropdown__btn {
          background-color: inherit;
          padding-top: 42px;
          padding-bottom: 42px;
        }
      }
    }
  }

  .usb-table_pagination--page_count {
    padding-top: 32px;
    padding-bottom: 32px;
  }

  th {
    border: 0;
    border-bottom: 2px solid var(--border-color) !important;
    background: white;

    button {
      white-space: nowrap;
    }
  }

  .usb-table_container-shadow {
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.05), 0 3px 6px rgba(0, 0, 0, 0.1);
  }
`;
