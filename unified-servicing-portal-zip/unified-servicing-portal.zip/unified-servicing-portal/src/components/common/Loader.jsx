import PropTypes from "prop-types";
import { API_CALL_STATUS, ServiceNowIncidentUrl } from "@/constants/constant";
import { linkMsg, pivotErrorMsg, pivotErrorMsg1 } from "@/constants/validationMessages";
import ErrorMessage from "./ErrorMessage";
import { TabLoader, FullPageLoader } from "./Loader.styles";
import Portal from "./Portal";

const LoaderElement = () => {
  return (
    <div className="loading loading--full-height">
      <div style={{ margin: "10px" }}>Loading ...</div>
    </div>
  );
};

export const Loader = ({ children, fetchingStatus, loading, tabLoader }) => {
  if (loading || [API_CALL_STATUS.STARTED, API_CALL_STATUS.PENDING].includes(fetchingStatus)) {
    return tabLoader ? (
      <TabLoader className="loader-container">
        <LoaderElement />
      </TabLoader>
    ) : (
      <Portal>
        <div className="backgroundColor">
          <FullPageLoader className="loader-container ">
            <LoaderElement />
          </FullPageLoader>
        </div>
      </Portal>
    );
  }

  if (tabLoader && fetchingStatus === API_CALL_STATUS.FAILED)
    return (
      <ErrorMessage
        errorNotificationMessage={pivotErrorMsg}
        errorNotificationMessage2={pivotErrorMsg1}
        linkMessage={linkMsg}
        linkUrl={ServiceNowIncidentUrl}
      />
    );

  return children;
};

Loader.propTypes = {
  children: PropTypes.node,
  fetchingStatus: PropTypes.oneOf(Object.values(API_CALL_STATUS)),
  loading: PropTypes.bool,
  tabLoader: PropTypes.any,
};

export default Loader;