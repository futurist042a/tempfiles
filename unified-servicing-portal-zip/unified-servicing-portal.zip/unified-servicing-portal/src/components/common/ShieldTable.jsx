import PropTypes from "prop-types";
import USBTable from "@/components/usb-shield/react-table";
import NoDataFound from "./NoDataFound";
import { ShieldTableStyles } from "./ShieldTable.styles";

const ShieldTable = (props) => {
  const isDataAvailable = props?.tableData?.length > 0 && props.columnStructure?.length > 0;
  return isDataAvailable ? (
    <ShieldTableStyles className={(props.classes || "").trim()}>
      <USBTable {...props} />
    </ShieldTableStyles>
  ) : (
    <NoDataFound displayMessage={props.emptyTableContent} />
  );
};

ShieldTable.propTypes = {
  classes: PropTypes.string,
  id: PropTypes.string,
  columnStructure: PropTypes.array,
  tableData: PropTypes.array,
  content: PropTypes.object,
  borders: PropTypes.oneOf(["", "rows-only", "none"]),
  rowSize: PropTypes.oneOf(["", "compact", "spacious"]),
  responsiveView: PropTypes.oneOf(["", "rowBased", "columnBased", "stackable"]),
  isZebraStriped: PropTypes.bool,
  isCaptionVisible: PropTypes.bool,
  hasAltHeaderColor: PropTypes.bool,
  rowBasedAccordionSubtitleAccessor: PropTypes.string,
  dataTestId: PropTypes.string,
  addClasses: PropTypes.string,
  isSortable: PropTypes.bool,
  customCompareFunctions: PropTypes.object,
  hasPagination: PropTypes.bool,
  initialPage: PropTypes.number,
  addPaginationClasses: PropTypes.string,
  emptyTableContent: PropTypes.string,
  showHideColumns: PropTypes.bool,
  batchActionsBar: PropTypes.bool,
  a11yRole: PropTypes.string,
  rowSubComponent: PropTypes.any,
  expandTable: PropTypes.string,
  expandCellGrid: PropTypes.object,
};

ShieldTable.defaultProps = {
  id: "shield-table",
  emptyTableContent: "No results found.",
  showHideColumns: false,
  batchActionsBar: false,
  a11yRole: "table",
};

export default ShieldTable;
