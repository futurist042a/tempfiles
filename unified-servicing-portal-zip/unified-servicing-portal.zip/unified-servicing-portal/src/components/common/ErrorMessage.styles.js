import styled from "styled-components";

export const ErrorMessageStyles = styled.div`
  height: 480px;
  margin: 10px auto;
  width: 100%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  border-radius: 4px;
  background-color: #ffffff;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.12), 0 2px 4px -1px rgba(0, 0, 0, 0.12),
    0 -1px 2px -1px rgba(0, 0, 0, 0.12);

  svg {
    fill: var(--border-color);
    height: 22px;
    width: 22px;
  }
`;

export const ErrorMessageText = styled.span`
  color: #6e6e6e;
  font-size: 1rem;
  letter-spacing: 0;
  margin-top: 0.5em;
`;

export const LinkButton = styled.a`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
  text-decoration: none;
`;
