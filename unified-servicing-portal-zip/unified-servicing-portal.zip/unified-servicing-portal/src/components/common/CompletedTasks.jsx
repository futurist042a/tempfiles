import React, { useState } from "react";
import { CompletedTasksStyles } from "./CompletedTasks.styles";
import "@usb-shield/react-icons/dist/library/styles/index.css";
import {
  USBIconCircleCheckmark,
  USBIconChevronDown,
  USBIconChevronUp,
} from "@/components/usb-shield/react-icons";

export function CompletedTasks(props) {
  const [isOpen, setIsOpen] = useState(false);
  const taskObjs = props.tasks.filter((task) => {
    return task.status.toString().toLowerCase() === "closed";
  });
  const header = "Completed Tasks";

  return (
    <CompletedTasksStyles>
      {taskObjs.length > 0 && (
        <div
          className="container"
          onClick={() => {
            setIsOpen(!isOpen);
          }}
        >
          <h1 className="header">
            {header}{" "}
            <div className="header-chevron">
              {isOpen ? <USBIconChevronUp /> : <USBIconChevronDown />}
            </div>
          </h1>

          <div className="list-wrapper">
            {isOpen && (
              <ol className={`list-${isOpen ? "active" : "inactive"}`}>
                {taskObjs.map((task, i) => (
                  <li className="list-item" key={`${task}-${i}`}>
                    <USBIconCircleCheckmark addClasses="icon" />
                    {`${task.taskName} - Completed by: ${task?.modifiedBy}`}
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>
      )}
    </CompletedTasksStyles>
  );
}
