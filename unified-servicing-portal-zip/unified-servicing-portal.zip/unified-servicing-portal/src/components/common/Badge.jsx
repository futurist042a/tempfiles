import React from 'react';
import USBBadge from '@usb-shield/react-badge';
import '../../scss/_badge.scss';

const Badge = (props) => {

    return (
        <div class={props?.colorName ? `badge-color-`+props?.colorName.toLowerCase() : `badge-dot`}>
        <USBBadge badgeStyle={props?.badgeStyle} text={props?.colorName ? props.colorName : props?.value} />
        </div>
    )
}

export default Badge;