import styled from "styled-components";

export const ToolTipStyles = styled.div`
  .chevron-wrapper {
    position: relative;
    left: 105%;
    top: -50%;
  }

  // .chevron {
  //   position: absolute;
  //   z-index: 998;
  //   background-color: red;
  // }

  .tooltip-right {
    top: -5px;
    left: 105%;
  }

  .tooltip-left {
    top: -5px;
    right: 105%;
  }

  .tooltip-top {
    bottom: 105%;
    left: 0;
  }

  .tooltip-bottom {
    top: 105%;
    left: 0;
  }

  .tooltip {
    position: absolute;
    z-index: 999; /* Set a higher z-index to ensure the component appears on top */
    background-color: #ffffff;
    padding: 20px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.05), 0 3px 6px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    padding: 5px;
    width: max-content;
    line-height: 2.5;
    min-width: ${props => props.minWidth || 0}px;
  }

  .tooltip-wrapper {
    position: relative;
    top: 10px;
    left: -100px;
    visibility: hidden;
  }

  .tooltip-active {
    opacity: 1;
    visibility: visible;
    transition: 0.2s;
    transition-timing-function: ease-out;
    transform: translateY(0);
  }

  .tooltip-inactive {
    opacity: 0;
    visibility: hidden;
    transition: 0.1s;
    transition-timing-function: ease-in;
    transform: translateY(-50%);
  }

  .tooltip-header {
    font-size: large;
    line-height: 1.5;
  }
`;
