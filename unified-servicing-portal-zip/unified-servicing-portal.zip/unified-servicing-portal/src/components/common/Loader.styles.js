import styled from "styled-components";

export const TabLoader = styled.div`
  height: 250px;
  width: 1247px;
  background-color: #ffffff;
  display: flex;
  align-items: center;
  margin-bottom: 20px;
`;

export const FullPageLoader = styled.div`
  height: 222px;
  width: 469px;
  background-color: #ffffff;
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  margin: auto;
  position: absolute;
  top: 50%;
  left: 50%;
  margin-right: -50%;
  border-radius: 5px;
  transform: translate(-50%, -50%);
`;
