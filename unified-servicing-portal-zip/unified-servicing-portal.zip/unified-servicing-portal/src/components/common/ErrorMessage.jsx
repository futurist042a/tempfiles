import { USBIconExternalLink, USBIconWarning } from "@usb-shield/react-icons";
import PropTypes from "prop-types";
import { ErrorMessageText, ErrorMessageStyles, LinkButton } from "./ErrorMessage.styles";
import "@/scss/_errorMessage.scss";

const ErrorMessage = ({
  errorNotificationMessage,
  linkMessage,
  linkUrl,
  errorNotificationMessage2,
}) => {
  return (
    <ErrorMessageStyles>
      <USBIconWarning
        colorVariant="interaction"
        title="warning"
        desc="warning"
        ariaHidden
        id="icon-sys-warning"
        addClasses="error-status"
      />
      <ErrorMessageText>{errorNotificationMessage}</ErrorMessageText>
      <ErrorMessageText>{errorNotificationMessage2}</ErrorMessageText>
      <LinkButton href={linkUrl} target="_blank" rel="noreferrer">
        <USBIconExternalLink
          colorVariant="interaction"
          title="task link"
          desc="task link"
          ariaHidden
          id="icon-sys-external-link"
          addClasses="ext-link-icon"
        />
        <span className="ext-text-msg">{linkMessage}</span>
      </LinkButton>
    </ErrorMessageStyles>
  );
};

ErrorMessage.propTypes = {
  errorNotificationMessage: PropTypes.string,
  linkMessage: PropTypes.string,
  linkUrl: PropTypes.string,
  errorNotificationMessage2: PropTypes.string,
};

export default ErrorMessage;
