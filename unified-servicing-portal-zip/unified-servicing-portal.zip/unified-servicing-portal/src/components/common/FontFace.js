import { createGlobalStyle } from "styled-components";
import fontWeight8ItalicWoff2 from "@/fonts/bold/13ab58b4-b5ba-4c95-afde-ab2608fbbbd9.woff2";
import fontWeight8ItalicWoff from "@/fonts/bold/5018b5b5-c821-4653-bc74-d0b11d735f1a.woff";
import fontWeight8NormalWoff from "@/fonts/bold/7b415a05-784a-4a4c-8c94-67e9288312f5.woff";
import fontWeight8NormalWoff2 from "@/fonts/bold/800da3b0-675f-465f-892d-d76cecbdd5b1.woff2";
import fontWeightFiveWoff2 from "@/fonts/medium/240c57a0-fdce-440d-9ce3-85e0cb56f470.woff2";
import fontWeight5ItalicWoff from "@/fonts/medium/31029e78-79a0-4940-b82d-2e3c238e1355.woff";
import fontWeightFiveWoff from "@/fonts/medium/7802e576-2ffa-4f22-a409-534355fbea79.woff";
import fontWeight5ItalicWoff2 from "@/fonts/medium/de68be2a-5d0e-4b8d-b3eb-940f75503e2a.woff2";
import fontWeight4NormalWoff2 from "@/fonts/regular/08b57253-2e0d-4c12-9c57-107f6c67bc49.woff2";
import fontWeight4NormalWoff from "@/fonts/regular/08edde9d-c27b-4731-a27f-d6cd9b01cd06.woff";
import fontWeight4ItalicWoff2 from "@/fonts/regular/4bd56f95-e7ab-4a32-91fd-b8704cbd38bc.woff2";
import fontWeight4ItalicWoff from "@/fonts/regular/4fe1c328-1f21-434a-8f0d-5e0cf6c70dfb.woff";
import fontWeight3ItalicWoff from "@/fonts/thin/116cde47-4a07-44a5-9fac-cbdcc1f14f79.woff";
import fontWeight3Woff from "@/fonts/thin/2a34f1f8-d701-4949-b12d-133c1c2636eb.woff";
import fontWeight3ItalicWoff2 from "@/fonts/thin/5e4f385b-17ff-4d27-a63a-9ee28546c9a8.woff2";
import fontWeight3off2 from "@/fonts/thin/f9c5199e-a996-4c08-9042-1eb845bb7495.woff2";

const FontFace = createGlobalStyle`
  @font-face {
    font-family: "Helvetica Neue";
    font-style: normal;
    font-weight: 300;
    src:
      url('${fontWeight3off2}') format('woff2'),
      url('${fontWeight3Woff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: italic;
    font-weight: 300;
    src:
      url('${fontWeight3ItalicWoff2}') format('woff2'),
      url('${fontWeight3ItalicWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: normal;
    font-weight: 400;
    src:
      url('${fontWeight4NormalWoff2}') format('woff2'),
      url('${fontWeight4NormalWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: italic;
    font-weight: 400;
    src:
      url('${fontWeight4ItalicWoff2}') format('woff2'),
      url('${fontWeight4ItalicWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: normal;
    font-weight: 500;
    src:
      url('${fontWeightFiveWoff2}') format('woff2'),
      url('${fontWeightFiveWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: italic;
    font-weight: 500;
    src:
      url('${fontWeight5ItalicWoff2}') format('woff2'),
      url('${fontWeight5ItalicWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: normal;
    font-weight: 600;
    src:
      url('${fontWeightFiveWoff2}') format('woff2'),
      url('${fontWeightFiveWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: italic;
    font-weight: 600;
    src:
      url('${fontWeight5ItalicWoff2}') format('woff2'),
      url('${fontWeight5ItalicWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
  @font-face {
    font-family: "Helvetica Neue";
    font-style: normal;
    font-weight: 800;
    src:
      url('${fontWeight8NormalWoff2}') format('woff2'),
      url('${fontWeight8NormalWoff}') format('woff');
      unicode-range: U+000-5FF;
  }

  @font-face {
    font-family: "Helvetica Neue";
    font-style: italic;
    font-weight: 800;
    src:
      url('${fontWeight8ItalicWoff2}') format('woff2'),
      url('${fontWeight8ItalicWoff}') format('woff');
      unicode-range: U+000-5FF;
  }
`;

export default FontFace;
