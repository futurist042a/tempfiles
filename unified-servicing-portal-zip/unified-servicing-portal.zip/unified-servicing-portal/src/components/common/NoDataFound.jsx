import PropTypes from "prop-types";
import { USBIconInfo } from "@/components/usb-shield/react-icons";
import { ErrorMessageText, ErrorMessageStyles } from "./ErrorMessage.styles";

const NoDataFound = ({ displayMessage }) => {
  return (
    <ErrorMessageStyles>
      <USBIconInfo colorVariant="interaction" title="info" desc="info" ariaHidden />
      <ErrorMessageText>{displayMessage}</ErrorMessageText>
    </ErrorMessageStyles>
  );
};

NoDataFound.propTypes = {
  displayMessage: PropTypes.string,
};

export default NoDataFound;
