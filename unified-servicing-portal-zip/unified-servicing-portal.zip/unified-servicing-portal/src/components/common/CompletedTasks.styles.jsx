import styled from "styled-components";

export const CompletedTasksStyles = styled.div`
    .container{
        padding-left: 5%;
        width: 90%;
        z-index: -3;
    }
    .header{
        font-size: 1.10rem;
    }


    .list-wrapper {
        display:table;
        width: 100%;
    }

    .list-active {
        opacity: 1;
        visibility: visible;
        transition: 0.2s;
        transition-timing-function: ease-out;
        transform: translateY(0);
      }
    .list-inactive {
        opacity: 0;
        visibility: hidden;
        transition: 0.1s;
        transition-timing-function: ease-in;
        transform: translateY(-50%);
      }

    .icon {
        position:relative;
        bottom: -7px;
        padding-right: 5px;
      }

    .list-item {
        display: table-row;
        height: 100%;
        font-weight: 500;
        font-size: 14px;

    }

    .header-chevron {
        display: inline-block;
        vertical-align: middle;
    }
`;
