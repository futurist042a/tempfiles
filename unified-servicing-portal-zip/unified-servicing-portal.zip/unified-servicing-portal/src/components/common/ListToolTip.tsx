/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
// import USBDividerLine from "@usb-shield/react-divider-line"
// import "@usb-shield/react-divider-line/dist/library/styles/index.css"
import { ReactNode, useEffect, useRef, useState } from "react";
import { USBIconChevronDown, USBIconChevronUp } from "@/components/usb-shield/react-icons";
import { ToolTipStyles } from "./ToolTip.styles";

interface InProgressToolTip {
  chToolTipPropsildren: ReactNode; //|string | JSX.Element | JSX.Element[] | (() => JSX.Element);
  position: string;
  //text?: string;
  list?: any[];
  header: string;
  minWidth: number;
}

export default function InProgressToolTip({
  position,
  list = [],
  header = "Tasks",
  minWidth = 150,
}: InProgressToolTip) {
  const [isVisible, setIsVisible] = useState(false);
  const componentRef = useRef<HTMLDivElement>(null);

  const handleClickOutside = (event: MouseEvent) => {
    if (componentRef.current && !componentRef.current.contains(event.target as Node)) {
      setIsVisible(false);
    }
  };

  const handleOnClick = () => {
    setIsVisible(true);
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <ToolTipStyles onClick={handleOnClick} minWidth={minWidth}>
      <div className="chevron-wrapper">
        {isVisible ? (
          <USBIconChevronUp addClasses="chevron" />
        ) : (
          <USBIconChevronDown addClasses="chevron" />
        )}
      </div>
      <div ref={componentRef} className="tooltip-wrapper">
        <span
          className={`tooltip tooltip-${position} ${
            isVisible ? "tooltip-active" : "tooltip-inactive"
          }`}
        >
          <div className="tooltip-header">{header}</div>
          <hr />
          <List list={list} />
        </span>
      </div>
    </ToolTipStyles>
  );
}

function List(props: { list: string[] }) {
  return (
    <ol className="list">
      {props.list.map((listItem,i) => (
        <li className="list-item" key={`${listItem}-${i}`}>
          {listItem}
        </li>
      ))}
    </ol>
  );
}
