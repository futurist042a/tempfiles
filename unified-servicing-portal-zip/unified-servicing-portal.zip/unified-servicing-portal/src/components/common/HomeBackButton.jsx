import { useNavigate } from "react-router";
import USBButton from "@/components/usb-shield/react-button";
import { USBIconArrowLeft } from "@/components/usb-shield/react-icons";
import { HomeBackButtonStyles } from "./HomeBackButton.styles";

const HomeBackButton = () => {
  const navigate = useNavigate();

  const navToHomePage = () => navigate("/");

  return (
    <HomeBackButtonStyles data-testid="HomeBackButton">
      <USBButton variant="text" handleClick={navToHomePage}>
        <div className="icon-wrapper">
          <USBIconArrowLeft
            colorVariant="interaction"
            title="filter"
            desc="filter"
            ariaHidden
            id="icon-sys-filter"
          />
        </div>
        <span>Home</span>
      </USBButton>
    </HomeBackButtonStyles>
  );
};

export default HomeBackButton;
