import styled from "styled-components";

export const FilterStyles = styled.div`

.filter{
    box-shadow: 4px 4px 8px rgba(0, 0, 0, 0.2);
    background-color: white;
    position: absolute;
    z-index: 9999;
    //left: 100px ;
    //width: fit-content;
    padding-left: 20px;
    padding-right: 20px;
}

.header{
    padding:10px;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.05), 0 3px 6px rgba(0, 0, 0, 0.1);
    margin-bottom: 5px;
}

.wrapper {
    height: fit-content;
    width: 140px;
}
`