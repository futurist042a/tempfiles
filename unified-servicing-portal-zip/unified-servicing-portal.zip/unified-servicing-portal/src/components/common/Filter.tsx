import React, { useEffect, useRef, useState } from "react";
import { FilterStyles } from "./Filter.styles";
import USBCheckboxGroup from "@usb-shield/react-forms-checkbox-group";
import "@usb-shield/react-forms-base/dist/library/styles/index.css";
import { USBIconChevronDown, USBIconChevronUp } from "../usb-shield/react-icons";

interface FilterProps {
  objList: any[];
  setObjList: (param: any) => void;
  CheckList: ChecklistItems[];
}

interface ChecklistItems {
  label: string;
  filterFunction: (param: any) => boolean;
}

export default function Filter(props: FilterProps) {
  const { ref, isActive, setIsActive } = useClickOutside(false);
  const header = "Filter Objects";
  const [checkListOptions, setCheckListOptions] = useState(
    props.CheckList.map((obj) => {
      return { checked: false, ...obj };
    }),
  );

  useEffect(() => {
    let filteredList = props.objList;
    for (const option of checkListOptions) {
      if (option.checked) {
        filteredList = filteredList.filter(option.filterFunction);
      }
    }
    props.setObjList(filteredList);
  }, [checkListOptions]);

  //console.log(checkListOptions);
  //console.log(props.objList)
  return (
    <FilterStyles>
      <div className="wrapper" ref={ref}>
        <div
          className="header"
          // onClick={() => {
          //   console.log("click");
          //   setIsActive(!isActive);
          // }}
        >
          {header}
          {isActive ? <USBIconChevronUp /> : <USBIconChevronDown />}
        </div>
        {isActive && (
          <USBCheckboxGroup
            inputName="checkbox-group"
            legendText=""
            addClasses="filter"
            statusUpdateCallback={(i) => {
              setCheckListOptions(i.inputValue);
            }}
            options={checkListOptions}
          />
        )}
      </div>
    </FilterStyles>
  );
}

const useClickOutside = (initialState) => {
  const [isActive, setIsActive] = useState(initialState);
  const ref = useRef(null);

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) {
        setIsActive(false);
      }else{
        setIsActive(!isActive)
      }
    };

    document.addEventListener("click", handleClick);

    return () => {
      document.removeEventListener("click", handleClick);
    };
  }, [ref]);

  return { ref, isActive, setIsActive };
};
