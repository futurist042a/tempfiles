import React from 'react';
import USBProgressIndicator from '@usb-shield/react-progress-indicator';
import PropTypes from 'prop-types';

import '../../scss/_progressBar.scss';

const ProgressBar = ( { completion, classes } ) => {
  const style = completion === 100 ? 'completed' : ''

  return (
    <USBProgressIndicator
      currentStep={ 1 }
      class={classes}
      variant='percentage'
      percentageValue={ completion }
      addClasses={ `${style} ${classes}` }
      percentSuffixLabel='%'
      value={ completion }
    />
  );

};

ProgressBar.propTypes = {
  completion: PropTypes.number.isRequired
};

export default ProgressBar;