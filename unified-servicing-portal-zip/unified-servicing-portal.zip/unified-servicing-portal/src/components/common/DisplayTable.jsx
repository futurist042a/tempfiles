import PropTypes from "prop-types";
import USBTooltip from "@/components/usb-shield/react-tooltip";
import { SubHeaderText } from "./Header";

const DisplayTable = ({
  headerText,
  value,
  showIcon = false,
  toolTipContent = "",
  classNames = "",
}) => {
  return (
    <div className="event-detail-column">
      <SubHeaderText className={`icon-style ${classNames}`} fontWeight="500" color="#2C2C2C">
        {headerText}
        {showIcon && (
          <USBTooltip variant="dark" ariaLabel="status" direction="bottom">
            {toolTipContent}
          </USBTooltip>
        )}
      </SubHeaderText>
      <SubHeaderText marginTop="7px" fontWeight="400" color="#2C2C2C" width="auto" maxWidth="250px">
        {(value && typeof value === "string" ? value.trim() : value) || "TBD"}
      </SubHeaderText>
    </div>
  );
};

DisplayTable.propTypes = {
  headerText: PropTypes.string.isRequired,
  value: PropTypes.node.isRequired,
  showIcon: PropTypes.bool,
  toolTipContent: PropTypes.node,
  classNames: PropTypes.string,
};

export default DisplayTable;
