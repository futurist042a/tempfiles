import { Link } from "react-router-dom";
import styled from "styled-components";

export const StyledLink = styled(Link)`
  color: var(--light-blue);
  text-decoration: underline;
`;
