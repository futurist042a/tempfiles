import PropTypes from "prop-types";
import { useSearchParams } from "react-router-dom";
import { StyledLink } from "@/components/common/StyledLink";
import { INITIATE_ONBOARDING } from "@/constants/constant";
import { createUrl } from "@/utils/createUrl";

export function TaskNameCell({ taskName, status, rowChecklistId, formName }) {
  const [searchParams] = useSearchParams();
  const { onboardingId, taskId } = Object.fromEntries(searchParams);
  const shouldRenderAsLink = status !== "Completed";
  if (shouldRenderAsLink) {
    const linkParams = { onboardingId, checklistId: rowChecklistId, formName, taskId };
    return (
      <StyledLink to={createUrl(`/${INITIATE_ONBOARDING}`, linkParams)}>{taskName}</StyledLink>
    );
  }

  return taskName;
}

TaskNameCell.propTypes = {
  taskName: PropTypes.string.isRequired,
  status: PropTypes.string.isRequired,
  rowChecklistId: PropTypes.string.isRequired,
  formName: PropTypes.string.isRequired,
};
