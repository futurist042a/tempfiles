import styled from "styled-components";

export const TasksTabContentStyles = styled.div`
  .usb-table_table {
    width: 100%;
  }
`;
