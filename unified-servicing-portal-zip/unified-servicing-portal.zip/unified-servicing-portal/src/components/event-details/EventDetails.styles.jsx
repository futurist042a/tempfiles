import styled from "styled-components";

const limeGreen = "#0a853d";

export const EventDetailsStyles = styled.div`
  .event-detail-row {
    margin-bottom: 20px;
    display: flex;
    width: 100%;
    justify-content: space-between;
    column-gap: 90px;
  }

  .event-detail-column {
    max-width: 250px;
  }

  .event-details-container {
    width: 1280px !important;
    margin: 0px auto 20px !important;

    .icon-style {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 2px;
      width: unset;
    }

    &:last-child {
      .icon-style {
        margin-top: -2px;
      }

      .usb-progress-indicator {
        margin-top: 13px !important;
        width: 250px;
      }
    }

    .task-completed {
      display: flex;
      justify-content: space-between;
      align-items: center;
      min-width: 110px;

      svg {
        fill: ${limeGreen};
      }
    }

    .bottom-left {
      height: 20px;
      width: 20px;

      .tooltip__trigger {
        cursor: pointer;
      }

      .tooltip__content {
        left: -76px !important;
      }

      .progress-status {
        display: flex;
        flex-direction: column;
      }
    }

    .event-detail-column .bottom-left .progress-status {
      display: flex;
      flex-direction: column;
    }

    .tooltip__content {
      max-width: 230px;
    }
  }
`;

export const HeaderText = styled.h1`
  height: auto;
  color: ${(props) => (props.color ? props.color : "")};
  font-size: 28px;
  font-weight: 500;
  line-height: 35px;
  font-family: "Helvetica Neue", sans-serif;
  margin-top: ${(props) => (props.marginTop ? props.marginTop : "")};
  margin-bottom: ${(props) => (props.marginBottom ? props.marginBottom : "")};
  overflow-wrap: ${(props) => (props.overflowWrap ? props.overflowWrap : "")};
`;
