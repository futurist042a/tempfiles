import { useState } from "react";
import UOTableWithSearch from "@/components/usb-uo-commons/react-table-with-search";
import UOUploadDocument from "@/components/usb-uo-commons/react-upload-document";

// TODO: fetch documents and headers from API
import documentList from "@/stubs/documentsList.json";
import documentHeaders from "@/stubs/documentsTabHeaders.json";

const menuDropdowns = [
  {
    name: "Download",
    iconName: "USBIconDownload",
  },
];
export const DocumentsTabContent = () => {
  const [addDocumentClicked, setAddDocumentClick] = useState(false);
  return addDocumentClicked ? (
    <UOUploadDocument backButtonCallBack={() => setAddDocumentClick(false)} backButtonText="Back" />
  ) : (
    <UOTableWithSearch
      tableHeaders={documentHeaders.documentHeaders}
      data={documentList.data.documentList}
      menuDropdowns={menuDropdowns}
      handleAddDocumentClickCallback={() => setAddDocumentClick(true)}
    />
  );
};
