import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { getDetailHistoryList, getHistoryTableMetaData } from "@/actions/eventDetailsAction";
import { Loader } from "@/components/common/Loader";
import ShieldTable from "@/components/common/ShieldTable";
import { API_CALL_STATUS } from "@/constants/constant";
import { selectEventDetails, selectHistoryTableStatus } from "@/selectors/eventDetailSelectors";
import { formatDateTime } from "@/utils/date";
import { HistoryTabContentStyles } from "./HistoryTabContent.styles";

export function HistoryTabContent() {
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();
  const { onboardingId } = Object.fromEntries(searchParams);
  const { historyList, historyTableMetaData, historyListStatus, historyTableMetaDataStatus } =
    useSelector(selectEventDetails);
  const fetchingStatus = useSelector(selectHistoryTableStatus);

  useEffect(() => {
    if (onboardingId && historyListStatus === API_CALL_STATUS.PENDING) {
      dispatch(getDetailHistoryList({ onboardingId }));
    }
  }, [onboardingId]);

  useEffect(() => {
    if (!historyTableMetaData && historyTableMetaDataStatus === API_CALL_STATUS.PENDING) {
      dispatch(getHistoryTableMetaData());
    }
  }, [historyTableMetaData]);

  const tableData = (historyList || []).map((row) => ({
    ...row,
    occurredOn: formatDateTime(row.createdDate),
  }));

  return (
    <HistoryTabContentStyles>
      <Loader
        tabLoader
        fetchingStatus={fetchingStatus}
        loading={!historyTableMetaData || !historyList}
      >
        <ShieldTable
          borders="none"
          columnStructure={historyTableMetaData}
          emptyTableContent="This event contains no history"
          id="history-tab-table"
          isSortable
          isZebraStriped
          tableData={tableData}
        />
      </Loader>
    </HistoryTabContentStyles>
  );
}