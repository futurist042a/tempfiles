import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { getHeaderDetails } from "@/actions/dashboardTableAction";
import DisplayTable from "@/components/common/DisplayTable";
import { StandardView, SubHeaderText } from "@/components/common/Header";
import HomeBackButton from "@/components/common/HomeBackButton";
import { Loader } from "@/components/common/Loader";
import { GreenLightStatusStyles } from "@/components/dashboard/GreenLightStatus.styles";
import USBProgressIndicator from "@/components/usb-shield/react-progress-indicator";
import USBTabs from "@/components/usb-shield/react-tabs";
import { BUSINESS_LINE } from "@/constants/constant";
import { useAsyncError } from "@/hooks/useAsyncError";
import { clearEventDetails } from "@/reducers/eventDetailsSlice";
import { clearInitiateOnboarding } from "@/reducers/initiateOnboardingSlice";
import { selectEventDetails } from "@/selectors/eventDetailSelectors";
import { DetailsTabContent } from "./DetailsTabContent";
import { DocumentsTabContent } from "./DocumentsTabContent";
import { EventDetailsStyles, HeaderText } from "./EventDetails.styles";
import { HistoryTabContent } from "./HistoryTabContent";
import { TasksTabContent } from "./TasksTabContent";
import { WebKYCSearchForm } from "./WebKYCSearchForm";

const tabs = {
  "Client summary": <DetailsTabContent />,
  Tasks: <TasksTabContent />,
  Documents: <DocumentsTabContent />,
  History: <HistoryTabContent />,
  "KYC search": <WebKYCSearchForm />,
};

const tabNames = Object.keys(tabs);
const tabContents = Object.values(tabs);

const EventDetails = () => {
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();
  const { onboardingId } = Object.fromEntries(searchParams);
  const { headerDetail } = useSelector(selectEventDetails);
  const throwError = useAsyncError();

  useEffect(() => {
    dispatch(getHeaderDetails(onboardingId, throwError));
    return () => {
      dispatch(clearEventDetails());
      dispatch(clearInitiateOnboarding());
    };
  }, []);

  if (headerDetail === null) return <Loader loading />;

  const productVal = headerDetail.product?.join(", ");
  const detailsEventStep =
    headerDetail?.eventProgressStatus &&
    headerDetail?.eventProgressStatus.findIndex(
      (eventName) => eventName === headerDetail?.eventStage,
    );
  const current = detailsEventStep + 1;
  const total = headerDetail?.eventProgressStatus?.length;
  const stepsProgressPercentage = (current / total) * 100;

  const getProgressBarStatus = () => {
    if (detailsEventStep >= 0) {
      return `Step ${detailsEventStep + 1} of ${headerDetail?.eventProgressStatus.length}: ${
        headerDetail?.eventStage
      }`;
    }
  };

  return (
    <EventDetailsStyles>
      <StandardView>
        <HomeBackButton />
        <div className="event-details-container">
          <SubHeaderText fontWeight="500" marginTop="40px">
            {BUSINESS_LINE.toUpperCase()} ONBOARDING ID {onboardingId}
          </SubHeaderText>
          <HeaderText color="#0c2074" marginBottom="40px" marginTop="8px">
            {headerDetail.clientLegalName}
          </HeaderText>
          <div className="event-detail-row">
            <DisplayTable headerText="Marketer" value={headerDetail.marketer} />
            <DisplayTable headerText="Negotiator" value={headerDetail.negotiator} />
            <DisplayTable headerText="RM" value={headerDetail.rM} />
            <DisplayTable headerText="Product" value={productVal} />
            <DisplayTable
              headerText={getProgressBarStatus()}
              value={
                <GreenLightStatusStyles>
                  <USBProgressIndicator
                    currentStep={current}
                    class="details-progress-bar"
                    variant="percentage"
                    percentageValue={stepsProgressPercentage}
                    addClasses={stepsProgressPercentage === 100 && "completed"}
                    percentSuffixLabel="%"
                  />
                </GreenLightStatusStyles>
              }
              showIcon
              toolTipContent={
                <ol className="progress-status">
                  {headerDetail?.eventProgressStatus?.map((eventName, index) => (
                    <li key={eventName}>
                      Step {index + 1}: {eventName}
                    </li>
                  ))}
                </ol>
              }
            />
          </div>
          <USBTabs tabs={tabNames} className="usb-uo-tabs" tabToExpand={0}>
            {tabContents}
          </USBTabs>
        </div>
      </StandardView>
    </EventDetailsStyles>
  );
};

export default EventDetails;
