import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { getDetailTaskList, getTasksTableMetaData } from "@/actions/eventDetailsAction";
import { Loader } from "@/components/common/Loader";
import ShieldTable from "@/components/common/ShieldTable";
import { selectEventDetails, selectTasksTableStatus } from "@/selectors/eventDetailSelectors";
import { formatDateTime } from "@/utils/date";
import { TaskNameCell } from "./TaskNameCell";
import { TasksTabContentStyles } from "./TasksTabContent.styles";

export function TasksTabContent() {
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();
  const { onboardingId } = Object.fromEntries(searchParams);
  const { taskList, tasksTableMetadata } = useSelector(selectEventDetails);
  const fetchingStatus = useSelector(selectTasksTableStatus);

  useEffect(() => {
    if (onboardingId && !taskList) {
      dispatch(getDetailTaskList({ onboardingId }));
    }
  }, [onboardingId, taskList]);

  useEffect(() => {
    if (!tasksTableMetadata) {
      dispatch(getTasksTableMetaData());
    }
  }, [tasksTableMetadata]);

  const tableData = (taskList || []).map((row) => ({
    ...row,
    lastUpdated: row.lastUpdated === "" ? "—" : formatDateTime(row.lastUpdated),
    taskName: (
      <TaskNameCell
        taskName={row.taskName}
        status={row.status}
        rowChecklistId={row.checklistId}
        formName={row.formName}
      />
    ),
  }));

  return (
    <TasksTabContentStyles>
      <Loader tabLoader fetchingStatus={fetchingStatus} loading={!tasksTableMetadata || !tableData}>
        <ShieldTable
          borders="none"
          columnStructure={tasksTableMetadata}
          emptyTableContent="This event contains no tasks"
          id="tasks-tab-table"
          isSortable
          isZebraStriped
          tableData={tableData}
        />
      </Loader>
    </TasksTabContentStyles>
  );
}
