import USBNotification from "@usb-shield/react-notification";
import UOEmployeeForm from "@usb-uo-commons/react-employee-form";
import UOPage from "@usb-uo-commons/react-page";
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useSearchParams } from "react-router-dom";
import { getForm, getMetaData } from "@/actions/initiateOnboardingAction";
import ErrorMessage from "@/components/common/ErrorMessage";
import {StandardView} from "@/components/common/Header";
import { Loader } from "@/components/common/Loader";
import {
  API_CALL_STATUS,
  INITIATE_ONBOARDING_FORM_NAME,
  ServiceNowIncidentUrl,
} from "@/constants/constant";
import { linkMsg, pivotErrorMsg, pivotErrorMsg1 } from "@/constants/validationMessages";
import {
  readOnlyFormStatus,
  selectActiveForm,
  selectActiveTabIndex,
  selectAuditTrailDetails,
  selectCurrentTab,
  selectTabList,
  selectVisibleTabs,
  selectFetchingFormStatus,
} from "@/selectors/initiateOnboardingSelectors";
import { formatDateTimeNumeric } from "@/utils/date";

export const DetailsTabContent = () => {
  const dispatch = useDispatch();
  const [searchParams] = useSearchParams();
  const { checklistId, onboardingId } = Object.fromEntries(searchParams);

  const activeForm = useSelector(selectActiveForm);
  const activeTabIndex = useSelector(selectActiveTabIndex);
  const auditTrailDetails = useSelector(selectAuditTrailDetails);
  const currentTab = useSelector(selectCurrentTab);
  const fetchingFormStatus = useSelector(selectFetchingFormStatus);
  const isLoadedReadOnly = useSelector(readOnlyFormStatus);
  const tabList = useSelector(selectTabList);
  const visibleTabs = useSelector(selectVisibleTabs);

  const [showNotification, setShowNotification] = useState(true);
  const [{ isTabChange, onTabChangeId }, setTabChangeInfo] = useState({
    isTabChange: false,
    onTabChangeId: 0,
  });

  useEffect(() => {
    dispatch(getMetaData(onboardingId, checklistId, INITIATE_ONBOARDING_FORM_NAME));
  }, []);

  useEffect(() => {
    if (currentTab && tabList) {
      const selectedTabIndex = visibleTabs.findIndex((tab) => tab.selectedTab);
      setTabChangeInfo((prev) => ({
        ...prev,
        onTabChangeId: selectedTabIndex,
      }));
      dispatch(getForm(onboardingId, checklistId, currentTab, INITIATE_ONBOARDING_FORM_NAME));
    }
  }, [currentTab]);

  const handleTabChange = (e) => {
    setTabChangeInfo((prev) => ({
      ...prev,
      isTabChange: true,
      onTabChangeId: e.activeIndex,
    }));
  };

  const finalSubmitCallback = async () => {
    await dispatch(
      getForm(
        onboardingId,
        checklistId,
        visibleTabs[onTabChangeId].value,
        INITIATE_ONBOARDING_FORM_NAME,
      ),
    );
    if (isTabChange) {
      setTabChangeInfo((prev) => ({
        ...prev,
        isTabChange: false,
      }));
    }
  };

  const hidingActionButtonsInReadOnlyForm = (formJSON) => {
    const clonedFormJSON = structuredClone(formJSON);
    clonedFormJSON.data.showSaveAsDraft = false;
    clonedFormJSON.data.showSubmit = false;
    return clonedFormJSON;
  };

  return (
    <StandardView className="uo-form-container">
      <Loader
        fetchingStatus={fetchingFormStatus}
        loading={fetchingFormStatus === API_CALL_STATUS.FAILED ? false : !isLoadedReadOnly}
      />
      {showNotification && auditTrailDetails?.modifiedByUserName && (
        <USBNotification
          iconAssistiveText=""
          addClasses="document-toast"
          variant="information"
          notificationData={[
            {
              text: `${
                auditTrailDetails.modifiedByUserName
              } has made some changes on ${formatDateTimeNumeric(
                auditTrailDetails.modifiedDate || new Date(),
              )}`,
            },
          ]}
          handleClose={() => setShowNotification(false)}
        />
      )}
      <div>
        <UOPage>
          <UOPage.Section className="section1">
            {tabList?.length > 0 && (
              <UOPage.Tabs
                key={activeTabIndex}
                tabId="client-summary-id"
                tabListDetail={tabList?.filter((item) => item?.isVisible === true)}
                activeTab={activeTabIndex}
                onTabChange={handleTabChange}
              />
            )}
            <UOPage.Content>
              <div className={currentTab}>
                {isLoadedReadOnly && fetchingFormStatus === API_CALL_STATUS.SUCCESS && (
                  <UOEmployeeForm
                    formData={hidingActionButtonsInReadOnlyForm(activeForm)}
                    finalSubmitCallback={finalSubmitCallback}
                    readonlyForm
                    shouldValidateFrom={isTabChange}
                    activeTab={activeTabIndex + 1}
                  />
                )}
                {!isLoadedReadOnly && fetchingFormStatus === API_CALL_STATUS.FAILED && (
                  <ErrorMessage
                    errorNotificationMessage={pivotErrorMsg}
                    errorNotificationMessage2={pivotErrorMsg1}
                    linkMessage={linkMsg}
                    linkUrl={ServiceNowIncidentUrl}
                  />
                )}
              </div>
            </UOPage.Content>
          </UOPage.Section>
        </UOPage>
      </div>
    </StandardView>
  );
};
