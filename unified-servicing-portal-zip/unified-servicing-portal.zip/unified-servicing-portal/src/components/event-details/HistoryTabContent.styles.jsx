import styled from "styled-components";

export const HistoryTabContentStyles = styled.div`
  .usb-table_table {
    width: 100%;
  }
`;
