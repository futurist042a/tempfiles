import UOEmployeeForm from "@usb-uo-commons/react-employee-form";
import UOPage from "@usb-uo-commons/react-page";
import { StandardView } from "@/components/common/Header";
import { getWebKycTableData } from "@/services/exp-api-service";
import webKycData from "@/stubs/onboarding-forms/webkyc-form.json";

export const WebKYCSearchForm = () => {
  const getTableData = (e) => getWebKycTableData(e.target.value);

  return (
    <StandardView className="uo-form-container">
      <div>
        <UOPage>
          <UOPage.Section className="section1">
            <UOPage.Content>
              <div>
                <UOEmployeeForm formData={webKycData} getTableData={getTableData} />
              </div>
            </UOPage.Content>
          </UOPage.Section>
        </UOPage>
      </div>
    </StandardView>
  );
};
