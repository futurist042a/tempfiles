import styled from "styled-components";

export const TabErrorsStyles = styled.div`
  margin-top: 20px;

  .error-tab-button-link {
    font-weight: unset;
    font-size: unset;
  }
`;
