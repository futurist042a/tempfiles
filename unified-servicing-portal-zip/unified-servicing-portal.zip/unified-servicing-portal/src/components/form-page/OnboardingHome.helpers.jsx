import { INITIATE_ONBOARDING_FORM_NAME } from "@/constants/constant";
import { continueInitiateOnboarding } from "@/reducers/initiateOnboardingSlice";
import { forEachField } from "@/utils/forms";

// functional Call for when user returns to the form with same onboardingId and checklistID
export const continueInitiateOnboardingAction = (checklistId, onboardingId) => {
  return async (dispatch) => {
    const data = {
      checkList: [
        {
          checklistId,
          name: "InitiateOnboardingTemplate",
          onboardingId,
        },
      ],
    };
    dispatch(continueInitiateOnboarding(data));
  };
};

// Creating DataPoint Object
export const createDataPoint = ({
  state,
  fullName,
  preferredId,
  currentTab,
  isFinalSubmit,
  formJson,
  checklistId,
  createOpportunityId,
}) => {
  const datapointList = {};
  forEachField(formJson, (field) => {
    let currentValue = state[field.name]?.value;
    if (field.type === "checkBoxGroup") {
      const currentValueC = state[field.name]?.checkBoxGroupOptions
        ?.filter((c) => c.checked)
        .map((v) => v.label);
      currentValue = { value: currentValueC ? [...currentValueC] : "" };
    }
    datapointList[field.name] = { value: currentValue || "" };
  });

  const modifiedDate = new Date().toJSON();

  const checkListItemData = {
    modifiedByName: fullName,
    modifiedBy: preferredId,
    checklistStatus: `${isFinalSubmit ? "submitted" : "updated"}`,
    modifiedDate,
    status: `${isFinalSubmit ? "completed" : "in progress"}`,
  };

  return {
    datapointList,
    auditTrailDetails: {
      occurredOn: `${modifiedDate} ,type=Edm.DateTime`,
      performedBy: fullName,
      performedByUserId: preferredId,
      performedByUserName: fullName,
      eventDescription: `${isFinalSubmit ? "Submitted for review" : `${currentTab?.name} updated`}`,
      details: `${isFinalSubmit ? "Submitted for review" : INITIATE_ONBOARDING_FORM_NAME}`,
    },
    checklistItem: createOpportunityId
      ? { ...checkListItemData, createOpportunityId, checklistId }
      : { ...checkListItemData },
  };
};
