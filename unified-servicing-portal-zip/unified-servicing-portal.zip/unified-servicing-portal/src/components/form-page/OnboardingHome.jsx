import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate, useSearchParams } from "react-router-dom";
import { getCountries, getStates } from "@/actions/dropdownsAction";
import {
  getForm,
  getMetaData,
  processOnboarding,
  sectionContinue,
} from "@/actions/initiateOnboardingAction";
import { Loader } from "@/components/common/Loader";
import { USBIconPending } from "@/components/usb-shield/react-icons";
import UOEmployeeForm from "@/components/usb-uo-commons/react-employee-form";
import UOPage from "@/components/usb-uo-commons/react-page";
import {
  FORMS_REQUIRING_COUNTRIES,
  FORMS_REQUIRING_STATES,
  INITIATE_ONBOARDING_REQUIRED_CARDS,
  REVIEW_TAB_NAMES,
  FORM_HEADING,
  FORM_INSTRUCTION,
} from "@/constants/constant";
import {
  clearInitiateOnboarding,
  getFormData,
  updateTabList,
} from "@/reducers/initiateOnboardingSlice";
import { selectCountriesForDropdown, selectStates } from "@/selectors/dropdownsSelectors";
import {
  checkIncompleteStatus,
  selectActiveForm,
  selectActiveTabIndex,
  selectCurrentTab,
  selectInitiateOnboardingIsLoaded,
  selectVisibleTabs,
  selectTabList,
  selectInitiateOnboardingFetchingStatus,
  selectAuditTrailDetails,
} from "@/selectors/initiateOnboardingSelectors";
import { selectFullName, selectPreferredId } from "@/selectors/oidcSelectors";
import { formatDateLongNumeric } from "@/utils/date";
import { enablingTabs, formChangeUpdatedTabList } from "@/utils/forms";
import { continueInitiateOnboardingAction, createDataPoint } from "./OnboardingHome.helpers";
import { OnboardingLayout } from "./OnboardingLayout";
import { TabErrors } from "./TabErrors";

/**
 * This must be a default export because of module federation.
 */
export default function OnboardingHome() {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { checklistId, onboardingId, taskId = "", formName } = Object.fromEntries(searchParams);

  const activeForm = useSelector(selectActiveForm);
  const activeTabIndex = useSelector(selectActiveTabIndex);
  const countries = useSelector(selectCountriesForDropdown);
  const currentTab = useSelector(selectCurrentTab);
  const fullName = useSelector(selectFullName);
  const incompleteStatus = useSelector(checkIncompleteStatus);
  const initiateOnboardingFetchingStatus = useSelector(selectInitiateOnboardingFetchingStatus);
  const isLoaded = useSelector(selectInitiateOnboardingIsLoaded);
  const preferredId = useSelector(selectPreferredId);
  const states = useSelector(selectStates);
  const tabList = useSelector(selectTabList);
  const visibleTabs = useSelector(selectVisibleTabs);
  const auditTrailDetails = useSelector(selectAuditTrailDetails);
  const lastUpdatedDate = formatDateLongNumeric(auditTrailDetails.modifiedDate || new Date());
  const lastUpdatedUser = auditTrailDetails.modifiedByUserName || fullName;
  const [{ isTabChange, onTabChangeId, homeBtnEvent }, setTabChangeInfo] = useState({
    isTabChange: false,
    onTabChangeId: 0,
    homeBtnEvent: false,
  });
  const [isTabClicked, setIsTabClicked] = useState(false);
  const [isPageErrorExist, setIsPageErrorExist] = useState(false);

  useEffect(() => {
    return () => {
      dispatch(clearInitiateOnboarding());
    };
  }, []);

  useEffect(() => {
    if (checklistId && onboardingId) {
      dispatch(getMetaData(onboardingId, checklistId, formName));
    }
  }, [checklistId, onboardingId]);

  useEffect(() => {
    if (currentTab && tabList && checklistId) {
      const actualTabs = enablingTabs(tabList, formName);
      const selectedTabIndex = visibleTabs.findIndex((tab) => tab.selectedTab);
      setTabChangeInfo((prev) => ({
        ...prev,
        onTabChangeId: selectedTabIndex,
      }));
      dispatch(getForm(onboardingId, checklistId, currentTab, formName));
      dispatch(updateTabList(actualTabs));

      if (FORMS_REQUIRING_COUNTRIES.includes(currentTab)) {
        dispatch(getCountries());
      }
      if (FORMS_REQUIRING_STATES.includes(currentTab)) {
        dispatch(getStates());
      }
    }
  }, [currentTab]);

  useEffect(() => {
    if (checklistId && onboardingId) {
      dispatch(continueInitiateOnboardingAction(checklistId, onboardingId));
    }
  }, [checklistId, onboardingId]);

  const handleTabChange = (e) => {
    setIsTabClicked(true);
    setTabChangeInfo((prev) => ({
      ...prev,
      isTabChange: true,
      onTabChangeId: e.activeIndex,
    }));
  };

  const navToHomePage = () => {
    navigate("/");
  };

  const triggerSubmitForInvalidForm = (tempSubmit) => {
    const { formJson, dataPointInfo } = tempSubmit;
    const tabsUpdatedInfo = formChangeUpdatedTabList(
      tabList,
      activeTabIndex,
      onTabChangeId,
      "error",
      false,
      isTabClicked,
    );

    const isFinalSubmit = false;
    setIsPageErrorExist(false);

    dispatch(
      sectionContinue(
        tabsUpdatedInfo,
        checklistId,
        onboardingId,
        formJson,
        visibleTabs[activeTabIndex].value,
        dataPointInfo,
        isFinalSubmit,
        formName,
      ),
    ).then(() => {
      if (isTabChange) {
        setTabChangeInfo((prev) => ({
          ...prev,
          isTabChange: false,
        }));
      }
      if (homeBtnEvent) {
        navToHomePage();
      }
    });
  };

  const finalSubmitCallback = async ({ formJson, state }, type) => {
    const isFinalSubmit = type === "submit" && REVIEW_TAB_NAMES.includes(currentTab);
    const dataPointInfo = createDataPoint({
      state,
      fullName,
      preferredId,
      currentTab: tabList[activeTabIndex],
      isFinalSubmit,
      formJson,
      checklistId,
      formName,
    });
    dispatch(getFormData({ formJson, state, dataPointInfo }));

    setIsTabClicked(false);
    switch (type) {
      case "invalidForm": {
        if (isTabChange || !INITIATE_ONBOARDING_REQUIRED_CARDS.includes(currentTab)) {
          triggerSubmitForInvalidForm({ formJson, state, dataPointInfo });
        }
        break;
      }
      case "submit": {
        if (type === "submit" && REVIEW_TAB_NAMES.includes(currentTab) && !isTabClicked) {
          if (incompleteStatus) {
            setIsPageErrorExist(true);
            await dispatch(
              sectionContinue(
                tabList,
                checklistId,
                onboardingId,
                formJson,
                currentTab,
                dataPointInfo,
                false,
                formName,
              ),
            );
            return;
          }
          const clientLegalNameForMessage =
            formJson.data?.prepopulatedDataPoints?.["clientDetails-legalName"] || "TBD";
          await dispatch(
            processOnboarding(onboardingId, type, navigate, taskId, clientLegalNameForMessage),
          );
        }
        const tabsUpdatedInfo = formChangeUpdatedTabList(
          tabList,
          activeTabIndex,
          onTabChangeId,
          "completed",
          true,
          isTabClicked,
        );
        const visibleTabsForSubmit = tabList?.filter((item) => item?.isVisible === true);

        if (REVIEW_TAB_NAMES.includes(currentTab) && !isTabClicked) {
          for (const tab of tabsUpdatedInfo) {
            if (tab.value === "reviewandapprove") {
              tab.isVisible = true;
              tab.selectedTab = true;
              tab.isDisabled = false;
            }
            if (tab.value === "reviewandsubmit") {
              tab.isVisible = false;
            }
            if (currentTab === "reviewandapprove") {
              tab.selectedTab = true;
            }
          }
        }

        await dispatch(
          sectionContinue(
            tabsUpdatedInfo,
            checklistId,
            onboardingId,
            formJson,
            visibleTabsForSubmit[activeTabIndex].value,
            dataPointInfo,
            isFinalSubmit,
            formName,
          ),
        );

        if (isTabChange) {
          setTabChangeInfo((prev) => ({
            ...prev,
            isTabChange: false,
          }));
        }
        if (homeBtnEvent) {
          navToHomePage();
        }
        break;
      }
      case "saveAsDraft": {
        setIsPageErrorExist(false);
        await dispatch(
          sectionContinue(
            tabList,
            checklistId,
            onboardingId,
            formJson,
            visibleTabs[activeTabIndex].value,
            dataPointInfo,
            isFinalSubmit,
            formName,
          ),
        );
        const clientLegalNameForMessage =
          formJson.data?.prepopulatedDataPoints?.["clientDetails-legalName"] || "TBD";
        const onboardingSaveAndExitMessage = `Onboarding form has been successfully updated for ${clientLegalNameForMessage}.`;
        navigate("/", { state: { showToast: true, message: onboardingSaveAndExitMessage } });
        break;
      }
      case "noChange": {
        const tabsUpdatedInfo = tabList.map((tab) => ({
          ...tab,
          selectedTab: tab.value === visibleTabs[onTabChangeId].value,
        }));
        setIsPageErrorExist(false);
        await dispatch(
          sectionContinue(
            tabsUpdatedInfo,
            checklistId,
            onboardingId,
            formJson,
            visibleTabs[activeTabIndex].value,
            dataPointInfo,
            isFinalSubmit,
            formName,
          ),
        );
        if (isTabChange) {
          setTabChangeInfo((prev) => ({
            ...prev,
            isTabChange: false,
          }));
        }
        if (homeBtnEvent) {
          navToHomePage();
        }
        break;
      }
      default: {
        break;
      }
    }
  };

  return (
    <OnboardingLayout
      loader={<Loader fetchingStatus={initiateOnboardingFetchingStatus} loading={!isLoaded} />}
      header={
        <UOPage.Header
          checkListData={{
            name: FORM_HEADING[formName],
            taskInstructions: FORM_INSTRUCTION[formName],
            statusDetails: [
              {
                label: "In progress",
                value: "",
                hasIcon: true,
                iconContent: (
                  <span className="statusCardIcon">
                    <USBIconPending />
                  </span>
                ),
              },
              lastUpdatedUser && lastUpdatedDate
                ? {
                    label: "Last updated",
                    value: `${lastUpdatedDate} by ${lastUpdatedUser}`,
                  }
                : {},
            ],
          }}
        />
      }
      errors={
        <TabErrors
          tabs={tabList}
          onMoveToErrorTab={() => setIsPageErrorExist(false)}
          isVisible={isPageErrorExist}
        />
      }
      tabs={
        tabList?.length > 0 && (
          <UOPage.Tabs
            key={activeTabIndex}
            tabListDetail={tabList?.filter((item) => item?.isVisible === true)}
            activeTab={activeTabIndex}
            onTabChange={handleTabChange}
          />
        )
      }
      form={
        <div className={currentTab}>
          {isLoaded && (
            /**
             * UOEmployeeForm caches the formData prop, so it does not
             * update when the formData prop changes. It needs to be
             * unmounted and remounted in order to update. In our case,
             * this is done by conditionally rendering it. Other projects
             * use a `key` to accomplish this.
             */
            <UOEmployeeForm
              formData={structuredClone(activeForm)}
              readonlyForm={false}
              finalSubmitCallback={finalSubmitCallback}
              shouldValidateFrom={isTabChange}
              activeTab={activeTabIndex + 1}
              countries={countries}
              states={states}
            />
          )}
        </div>
      }
    />
  );
}
