import styled from "styled-components";

export const TabErrorStyles = styled.li`
  span.usb-link.basic {
    font-weight: unset;
    font-size: unset;
  }
`;
