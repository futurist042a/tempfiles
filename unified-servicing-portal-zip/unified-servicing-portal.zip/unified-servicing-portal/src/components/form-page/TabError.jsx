import PropTypes from "prop-types";
import USBLink from "@/components/usb-shield/react-link";
import { TabErrorStyles } from "./TabError.styles";

const tabErrorMessagesByStatus = {
  error: " contains issues.",
  not_Started: " is incomplete.",
};

export function TabError({ tab, onClick }) {
  return (
    <TabErrorStyles>
      <USBLink handleClick={() => onClick(tab.value)}>{tab.name}</USBLink>
      <span>{tabErrorMessagesByStatus[tab.status]}</span>
    </TabErrorStyles>
  );
}

TabError.propTypes = {
  tab: PropTypes.shape({
    name: PropTypes.string,
    value: PropTypes.string,
    status: PropTypes.string,
  }),
  onClick: PropTypes.func,
};
