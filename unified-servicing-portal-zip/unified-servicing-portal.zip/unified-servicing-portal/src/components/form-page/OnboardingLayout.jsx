import PropTypes from "prop-types";
import HomeBackButton from "@/components/common/HomeBackButton";
import UOPage from "@/components/usb-uo-commons/react-page";
import "@/scss/_initiateOnboarding.scss";
import "@/scss/_uoPage.scss";
import { OnboardingLayoutStyles } from "./OnboardingLayout.styles";

export function OnboardingLayout({
  backButton = <HomeBackButton />,
  loader,
  header,
  errors,
  tabs,
  form,
}) {
  return (
    <OnboardingLayoutStyles>
      {backButton}
      {loader}
      <UOPage>
        {header}
        {errors}
        <UOPage.Section className="section1">
          {tabs}
          <UOPage.Content>{form}</UOPage.Content>
        </UOPage.Section>
      </UOPage>
    </OnboardingLayoutStyles>
  );
}

OnboardingLayout.propTypes = {
  backButton: PropTypes.node,
  loader: PropTypes.node,
  header: PropTypes.node,
  errors: PropTypes.node,
  tabs: PropTypes.node,
  form: PropTypes.node,
};
