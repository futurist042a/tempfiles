import styled from "styled-components";
import { StandardView } from "@/components/common/Header";

// cspell:ignore custorm
export const OnboardingLayoutStyles = styled(StandardView)`
  .statusCard {
    grid-template-columns: 132px 198px !important;
    width: 434px;
  }

  .card-header {
    display: grid;
  }

  .statusCardIcon {
    margin-right: 8px;

    .single {
      fill: var(--light-blue);
    }
  }

  .document-toast {
    .usb-button--close-btn {
      margin: -9px !important;
    }
  }

  .formTable-container .search-container {
    height: 50px;
  }

  // @TODO convert these classes to styles component
  .external-link-class {
    display: flex;

    svg {
      margin-left: 5px;
      margin-right: 5px;
      fill: var(--light-blue);
    }
  }

  .colorClass {
    margin-right: 5px;
    color: var(--light-blue);
    display: flex;
    justify-content: center;
  }

  // Till here
  .custormEditStyle {
    margin-left: -10px !important;
  }

  .header_container {
    width: 1280px;
  }

  .save-button-container {
    width: 954px;
  }

  .form-container {
    width: 954px;
  }

  .pageText {
    font-weight: 400;
    font-size: 16px;
    line-height: 24px;
    color: #555555;
    margin-top: 20px;
    font-family: "Helvetica Neue";
  }

  .pageheading {
    line-height: 25px;
    font-family: "Helvetica Neue";
    font-weight: 500;
  }
`;
