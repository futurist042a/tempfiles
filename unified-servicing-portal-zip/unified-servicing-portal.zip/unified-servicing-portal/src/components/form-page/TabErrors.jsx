import PropTypes from "prop-types";
import { useDispatch } from "react-redux";
import USBNotification from "@/components/usb-shield/react-notification";
import { REVIEW_TAB_NAMES } from "@/constants/constant";
import { updateTabList } from "@/reducers/initiateOnboardingSlice";
import { TabError } from "./TabError";
import { TabErrorsStyles } from "./TabErrors.styles";

export function TabErrors({ isVisible: isVisibleProp, tabs, onMoveToErrorTab }) {
  const dispatch = useDispatch();

  if (!isVisibleProp || tabs.length === 0) return null;

  const moveToErrorTab = (tabName) => {
    const editedTabList = tabs.map((tab) => ({
      ...tab,
      selectedTab: tab.value === tabName,
    }));
    dispatch(updateTabList(editedTabList));
    onMoveToErrorTab();
  };

  const tabsWithErrors = tabs.filter((tab) => {
    return (
      tab.isVisible &&
      ["error", "not_Started"].includes(tab.status) &&
      !REVIEW_TAB_NAMES.includes(tab.value)
    );
  });

  return (
    <TabErrorsStyles>
      <USBNotification
        id="children-notification"
        variant="error"
        iconAssistiveText={{ label: "error" }}
        roleType="alert"
      >
        <span>The following pages need your attention:</span>
        <ul>
          {tabsWithErrors.map((tab) => (
            <TabError tab={tab} onClick={moveToErrorTab} />
          ))}
        </ul>
      </USBNotification>
    </TabErrorsStyles>
  );
}

TabErrors.propTypes = {
  isVisible: PropTypes.bool,
  tabs: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string,
      selectedTab: PropTypes.bool,
      status: PropTypes.string,
    }),
  ),
  onMoveToErrorTab: PropTypes.func.isRequired,
};
