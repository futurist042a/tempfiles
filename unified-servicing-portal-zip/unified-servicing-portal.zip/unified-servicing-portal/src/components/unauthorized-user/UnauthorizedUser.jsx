import USBNotification from "@/components/usb-shield/react-notification";
import { TabLoader } from "./UnauthorizedUser.styles";

const UnauthorizedUser = () => {
  const message = "You are not authorized to view this page";
  return (
    <TabLoader>
      <USBNotification
        iconAssistiveText=""
        addClasses="document-toast-unauthorized-user"
        variant="error"
        notificationData={[
          {
            text: message,
          },
        ]}
      />
    </TabLoader>
  );
};

export default UnauthorizedUser;
