import styled from "styled-components";

export const TabLoader = styled.div`
  margin-top: 20px;
  display: flex;
  justify-content: center;

  .document-toast-unauthorized-user {
    width: 80%;
  }
`;
