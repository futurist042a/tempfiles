import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Outlet, useLocation } from "react-router";
import  Loader  from "@/components/common/Loader";
import ErrorBoundary from "@/components/error/ErrorBoundary";
import Footer from "@/components/usb-uo-commons/react-footer";
import Header from "@/components/usb-uo-commons/react-header";
import { userManager } from "@/config/user-manager";
import { USER_PROFILE } from "@/constants/env";
import { selectOidcUser } from "@/selectors/oidcSelectors";
import UserLoadWrapper from "@/UserLoadWrapper";
import { getAppendedEnvVariable } from "@/utils/environment";
import { HomePageStyles } from "./HomePage.styles";

export default function HomePage() {
  const location = useLocation();
  const user = useSelector(selectOidcUser);
  const { sub = "", given_name = "" } = user?.profile || {};
  const [loadUser, setLoadUser] = useState(false);
  const profileUrl = getAppendedEnvVariable(USER_PROFILE, `${sub}`);

  console.log("homePage")
  useEffect(() => {
    if (!user || user?.expired) {
      setLoadUser(false);
      fetchUserInfo();
    } else {
      setLoadUser(true);
    }
  }, []);

  async function fetchUserInfo() {
    // Changed signinSilent to signInRedirect so as to change prompt as login (to get SSO login page if creds are not available in SSO)
    console.log("fetch user info")
    console.log(location)
    const res = await userManager.signinRedirect({
      state: location.pathname + location.search,
    });
    console.log("set user info")

    setLoadUser(!!res?.profile);
  }

  if (!loadUser) return <Loader loading />;

  return (
    <ErrorBoundary>
      <HomePageStyles>
        <Header profileUrl={profileUrl} userName={given_name} />
        <main className="container">
          <section>
            {/* <UserLoadWrapper>
              <Outlet />
            </UserLoadWrapper> */}
               <Outlet />
          </section>
        </main>
        <Footer />
      </HomePageStyles>
    </ErrorBoundary>
  );
}
