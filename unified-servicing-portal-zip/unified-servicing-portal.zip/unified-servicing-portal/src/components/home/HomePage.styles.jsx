import styled from "styled-components";

export const HomePageStyles = styled.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;

  &.loading .navbar-user-profile {
    display: none;
  }

  main.container {
    flex-grow: 1;
    padding-bottom: 30px;
    background-color: var(--background-color-grey);
  }
`;
