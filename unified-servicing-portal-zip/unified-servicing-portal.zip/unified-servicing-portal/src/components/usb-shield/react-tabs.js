import USBTabs from "@usb-shield/react-tabs";
import "@usb-shield/react-tabs/dist/library/styles/index.css";

export default USBTabs;
