import USBTooltip from "@usb-shield/react-tooltip";
import "@usb-shield/react-tooltip/dist/library/styles/index.css";

export default USBTooltip;
