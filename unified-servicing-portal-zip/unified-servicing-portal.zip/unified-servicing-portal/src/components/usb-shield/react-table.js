import Table from "@usb-shield/react-table";

/**
 * Importing the styles from the Shared Assets table component fixes
 * the styling of the pagination component.
 */
import "@usb-uo-commons/react-table/dist/library/styles/index.css";

export default Table;
