import USBNotification from "@usb-shield/react-notification";
import "@usb-shield/react-notification/dist/library/styles/index.css";

export default USBNotification;
