import ProgressIndicator from "@usb-shield/react-progress-indicator";
import "@usb-shield/react-progress-indicator/dist/library/styles/index.css";

export default ProgressIndicator;
