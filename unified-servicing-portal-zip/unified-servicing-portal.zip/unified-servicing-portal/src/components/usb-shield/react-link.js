import USBLink from "@usb-shield/react-link";
import "@usb-shield/react-link/dist/library/styles/index.css";

export default USBLink;
