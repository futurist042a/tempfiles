import USBTabs from "@usb-shield/react-tabs";
import React, { useEffect, useState, useMemo, useCallback } from "react";
//import UODashboard from "@/components/usb-uo-commons/react-dashboard";
import { DashboardStyles } from "./Dashboard.styles";
import Loader from "../common/Loader";
import Filter, { filterInputTypes } from "./filter/Filter";
import ShieldTable from "@/components/common/ShieldTable";
import SubRow, { SubRowObject } from "./subrow/SubRow";
import { Cell } from "../dashboard/Cell";
import LeftNavPlane from "./leftNavPlane/LeftNavPlane";
import RowIcons, { Icon } from "./table/Icons";
import USBModal, { ModalHeader, ModalBody, ModalFooter } from "@usb-shield/react-modal";
import USBRadioGroup from "@usb-shield/react-forms-radio-group";

import "./index.scss";

import USBDividerLine from "@usb-shield/react-divider-line";
import USBCheckboxGroup from "@usb-shield/react-forms-checkbox-group";
import USBCheckbox from "@usb-shield/react-forms-checkbox";

import InformationSection from "./informationSection/InformationSection";
import USBTable from "@usb-shield/react-table";

const dataResponse = require("./fakeData/data-response.json");
const metaDataResponse = require("./fakeData/metadata-response.json");

//TODO create new sections under the filter that grows and moves the other components
//TODO create a new component for CDFC component
//TODO add the names to the new section component
//TODO add labels to the component
//TODO add functionality to filter when the table is used

//TODO create dummy data for multiple rows
//TODO update the filter to show the filter and section working

//TODO add another section to the bottom of the My Tasks to demonstrate that the tabs can have sections

export default function TemplateDashboard(props) {
  //let tblData = dataResponse.commonObjects;

  const filters = {
    tableActions: [
      {
        title: "Action 1",
        action: () => {
          setModalText("Action 1");
        },
      },
      {
        title: "action 2",
        action: () => {
          setModalText("Action 2");
        },
      },
    ],
    filterBy: [
      { labelString: "Search", filterKey: undefined, inputType: filterInputTypes.text },
      {
        labelString: "Search OnboardingID",
        filterKey: "OnboardingID",
        inputType: filterInputTypes.text,
      },
      {
        labelString: "Onboarding type",
        filterKey: "Onboarding type",
        inputType: filterInputTypes.dropdown,
        dropdownValues: ["Type A", "Type B", "Type C"],
      },
      {
        labelString: "Advisors",
        filterKey: "Advisors",
        inputType: filterInputTypes.multiSelect,
        dropdownValues: ["Type A", "Type B", "Type C", "Type D"],
      },
    ],
  };
  const leftNavBar = metaDataResponse.leftNavBar;

  const subRowTitle = metaDataResponse.subRowTitle;
  //const subRowData: SubRowObject[] = metaDataResponse.subRowData;
  const tabs = metaDataResponse.tabs;

  //! The Table data only works because the icons variable is at the end of the object. The table style keeps the last column header blank
  const [currentTab, setCurrentTab] = useState(tabs[0]);
  const [modalText, setModalText] = useState("");

  const [dataForTabs, setDataForTabs] = useState(dataResponse);
  const [tableData, setTableData] = useState(
    dataForTabs[currentTab]?.commonObjects.map((commonObject) => ({
      //? Since JSON objects are coming in as strings, we need to convert the icons onClick function to be a function instead of a string
      ...commonObject,
      icons:
        commonObject?.icons.map((icon) => ({
          //!This cannot be extracted, it being here allows for it to have access to enclosing scope functions
          iconName: icon?.iconName,
          //! I am concerned that this will be a risk
          onClick: () => eval(icon?.onClick), //setModalText(icon?.iconName ?? "default text"),
        })) ?? [],
    })),
  );

  const [subRowDataArray, setSubRowDataArray] = useState(metaDataResponse.subRowData);
  const [subRowData, setSubRowData] = useState(subRowDataArray[currentTab]);

  const [tableDataSortBy, setTableDataSortBy] = useState({ sortString: "", reverse: false });
  const metadataToColumnData = (
    tableHeaders: { id: string; accessor: string }[],
    addCellExpander?: boolean,
    addRowSelect?: boolean,
  ) => {
    //console.log(tableHeaders);
    if (!tableHeaders) return [];
    let colData = [
      ...tableHeaders?.map((headerObject) => {
        const headerName = headerObject?.id;
        const AccessorKey = headerObject.accessor;

        //! SORT BY
        const sortBy = () => {
          setTableDataSortBy((prevState) => {
            return { sortString: AccessorKey, reverse: !prevState.reverse };
          });
        };

        if (AccessorKey != "icons") {
          return {
            header: headerName ?? "",
            id: headerName,
            //accessorKey: AccessorKey,
            fieldFor: AccessorKey,
            accessor: AccessorKey,
            type: "string",
            essential: true,
            //isSortable: false,
            //enableSorting: false,
            disableSortBy: true,
            //sortable: false,
            //dataType: "string",
            //sortValues: ["Oldest", "Newest"],
            isWidth: "16%",
            //customDateFormat: "MM/DD/YYYY",
            //columnType: "",
            //wrapContent: true,
            //width: "",
            toggleSortBy: sortBy,
            headerName: "Client Legal Name",
            //fieldFor: 'clientDetails-legalName',
            //isSortable: false,
            //enableSorting: false,
            dataType: "specialCellType",
            sortValues: ["Oldest", "Newest"],
            //isWidth: '16%',
            customDateFormat: "MM/DD/YYYY",
            columnType: "date",
            wrapContent: true,
            width: "",
            accessorKey: "",
          };
        } else {
          //? The Icons have a special rules
          return {
            header: headerName ?? "",
            id: "icons",
            accessorKey: "undefined",

            disableSortBy: true,
            Cell: icons,
            toggleSortBy: sortBy,
          };
        }
      }),
    ];

    let returnData: any[] = colData;

    //console.log("addRowSelect", addRowSelect);
    if (addRowSelect) {
      returnData = [
        {
          header: " ",
          id: "cell-select",
          accessorKey: "undefined",
          disableSortBy: true,
          Cell: (
            <div>
              <USBCheckbox
                inputName="terms-conditions-checkbox"
                labelText=" "
                statusUpdateCallback={() => {
                  console.log("statusUpdateCallback");
                }}
                errorMessages="Please check the box to agree and continue."
              />
            </div>
          ),
        },
        ...returnData,
      ];
    }

    if (addCellExpander) {
      returnData = [
        ...returnData,
        {
          header: "Toggle",
          id: "cell-expander",
          accessorKey: "undefined",
          disableSortBy: true,
          Cell: (
            <div>
              <Icon iconName="USBIconChevronDown" addClasses="dropdown-cell" />
            </div>
          ),
        },
      ];
    }

    return returnData;
  };

  const [columnDataArray, setColumnDataArray] = useState(metaDataResponse.tableHeaders);
  const [columnData, setColumnData] = useState(
    metadataToColumnData(columnDataArray[currentTab], true, true),
  );

  const [leftNavData, setLeftNavData] = useState(leftNavBarMetaDataToLeftNavBarData(leftNavBar));

  const renderCell = (row) => <Cell row={row} />;
  const createBatches = (numberOfTasks = 0) => {
    const batchAmount = 10;
    const pages = Math.ceil(numberOfTasks / batchAmount);
    const batchGroups = [];
    for (let index = 1; index <= pages; index++) {
      const numberOfRows = index * batchAmount;
      batchGroups.push({ label: `${numberOfRows} rows`, value: numberOfRows });
    }
    return batchGroups;
  };
  function subRow(props) {
    //console.log(props);
    return <SubRow title={subRowTitle} subRowObjectList={subRowData} columns={3} />;
  }

  useEffect(() => {
    setSubRowData(subRowDataArray[currentTab]);

    setTableData(
      dataForTabs[currentTab]?.commonObjects.map((commonObject) => ({
        //? Since JSON objects are coming in as strings, we need to convert the icons onClick function to be a function instead of a string
        ...commonObject,
        icons:
          commonObject?.icons.map((icon) => ({
            //!This cannot be extracted, it being here allows for it to have access to enclosing scope functions
            iconName: icon?.iconName,
            //! I am concerned that this will be a risk
            onClick: () => eval(icon?.onClick), //setModalText(icon?.iconName ?? "default text"),
          })) ?? [],
      })),
    );
    setColumnData(metadataToColumnData(columnDataArray[currentTab], true, true));
  }, [currentTab]);

  useEffect(() => {
    if (typeof tableData[0][tableDataSortBy.sortString] == "string") {
      const sorted = tableData.sort((a, b) => {
        const valA = a[tableDataSortBy.sortString]?.toString();
        const valB = b[tableDataSortBy.sortString]?.toString();

        return !tableDataSortBy.reverse ? valA.localeCompare(valB) : valB.localeCompare(valA);
      });

      setTableData(sorted);
    }
  }, [tableDataSortBy]);

  const SortingShieldTable = useCallback(() => {
    console.log("callBack TableData", tableData);
    return (
      <ShieldTable
        borders="none"
        expandTable="expandCell"
        expandCellGrid={{
          display: "grid",
          gridTemplateColumns: "18.31rem 10rem 10rem 10rem ",
        }}
        tableData={tableData} // {fakeData}
        columnStructure={columnData}
        // This is the component that is shown when expanded
        rowSubComponent={subRow}
        id="usb-table-onboarding-id"
        key="usb-table-onboarding-id"
        isSortable
        isZebraStriped
        hasPagination={true}
      />
    );
  }, [tableData, columnData, subRow]);

  return (
    <div>
      <LeftNavPlane navLinks={leftNavData} />
      <div className={`templateDashboard-container`}>
        <Loader loading={false}>
          <div className="filter-container">
            <Filter objList={tableData} setObjList={setTableData} filterObjects={filters} />
          </div>
          <div className={`InformationSection-container  cols-6`}>
            <InformationSection>
              <ShieldTable
                borders="none"
                // expandTable="expandCell"
                // expandCellGrid={{
                //   display: "grid",
                //   gridTemplateColumns: "18.31rem 10rem 10rem 10rem ",
                // }}
                tableData={dataForTabs["Section Tasks"]?.commonObjects} // {fakeData}
                columnStructure={metadataToColumnData(columnDataArray["Section Tasks"])}
                // This is the component that is shown when expanded
                rowSubComponent={<div></div>}
                id="usb-table-onboarding-id"
                key="usb-table-onboarding-id"
                isSortable
                isZebraStriped
              />
            </InformationSection>
          </div>
          <div className={`tabs-container cols-${columnData ? columnData?.length : 0}`}>
            <USBTabs
              id="test-ID"
              addClasses="table-tabs"
              handleClick={(e) => setCurrentTab(e.target.innerText)}
              tabId="custom-id"
              ariaLabel="aria-label-for-tabs"
              dataTestId="test-id-1"
              tabs={tabs}
            >
              {/**Tab 1 */}
              <div>
                <SortingShieldTable />
              </div>
              {/**Tab 2 */}
              <div>
                {/* <USBCheckboxGroup
                  inputName="checkbox-group"
                  legendText="Legend name"
                  options={[{ label: "Option 1" }, { label: "Option 2" }]}
                /> */}
                <USBRadioGroup
                  //ref={ref}
                  inputName="radio-group"
                  legendText="Sort by"
                  options={[
                    { value: "Newest", label: "Newest" },
                    { value: "oldest", label: "oldest" },
                  ]}
                  //statusUpdateCallback={handleStatusUpdate}
                  errorMessages={{ 224: "Please choose yes or no." }}
                />

                <USBDividerLine
                  id="divider-line"
                  variant={"dark"}
                  addClasses={""}
                  dataTestId={""}
                />
                <SortingShieldTable />
              </div>
              {/**Tab 3 */}
              <div>
                <USBTable
                  columnStructure={[
                    {
                      header: "Account name",
                      accessor: "name",
                    },
                    {
                      header: "Balance",
                      accessor: "balance",
                      dataType: "currency",
                    },
                  ]}
                  tableData={[
                    {
                      name: "Arc Security Inc",
                      balance: "$891,325.08",
                    },
                    {
                      name: "Oceanside Realty Group",
                      balance: "$1,919.58",
                    },
                  ]}
                />
              </div>
            </USBTabs>
          </div>
          <USBModal id="test-modal" isOpen={!!modalText} handleClose={() => setModalText("")}>
            <ModalHeader id="mhID">US Bank Modal</ModalHeader>
            <ModalBody>{modalText}</ModalBody>
          </USBModal>
        </Loader>
      </div>
    </div>
  );
}
function notifProps() {}
function cell(row) {
  return <Cell row={row} />;
}
function icons(row) {
  return <RowIcons rowObject={row} />;
}

function tableDataToColumnData(tableObjects) {
  try {
    return [
      ...Array.from(
        new Set<string>(tableObjects?.reduce((acc, curr) => acc.concat(Object.keys(curr)), [])),
      ).map((element: string) => {
        if (element != "icons") {
          const key = element ?? "undefined";
          return {
            header: element?.toUpperCase(),
            accessorKey: key,
            essential: false,
            id: key,
            headerName: key.toUpperCase(),
            fieldFor: key,
            isSortable: true,
            enableSorting: true,
            dataType: "specialCellType",
            sortValues: ["Oldest", "Newest"],
            isWidth: "16%",
            customDateFormat: "MM/DD/YYYY",
            columnType: "date",
            wrapContent: true,
            width: "",
            accessor: key,
            type: "string",
          };
        } else {
          //? The Icons have a special rules
          return {
            header: "Icons",
            id: "icons",
            accessorKey: "undefined",

            disableSortBy: true,
            Cell: icons,
          };
        }
      }),
      // Add another column that is the dropdown toggle button !This may not be needed with the new data
      {
        header: "",
        id: "cell-expander",
        accessorKey: "undefined",

        disableSortBy: true,
        Cell: (
          <div>
            <Icon iconName="USBIconChevronDown" addClasses="dropdown-cell" />
          </div>
        ),
      },
    ];
  } catch {
    console.error(
      "tableObjects.reduce is not a function, Likely cause is typeof tableObjects",
      typeof tableObjects,
    );
  }
}

function leftNavBarMetaDataToLeftNavBarData(
  navList: any[],
): { linkString: string; linkValue: string; isDisabled: boolean }[] {
  const a = navList.map((navObj) => {
    const type = typeof navObj;
    let returnObj: { linkString: string; linkValue: string; isDisabled: boolean };
    if (type === "object") {
      returnObj = {
        linkString: navObj.linkString,
        linkValue: navObj.linkValue,
        isDisabled: navObj.isDisabled,
      };
    } else {
      returnObj = { linkString: navObj, linkValue: navObj, isDisabled: false };
    }

    return returnObj;
  });
  //console.log(a);
  return a;
}
