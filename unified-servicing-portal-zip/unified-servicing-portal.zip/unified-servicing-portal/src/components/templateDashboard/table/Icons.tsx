import "@usb-shield/react-icons/dist/library/styles/index.css";
import {
  USBIcon,
  USBIconAdd,
  USBIconAirplane,
  USBIconAlert,
  USBIconArrowDown,
  USBIconArrowLeft,
  USBIconArrowRight,
  USBIconArrowUp,
  USBIconAtm,
  USBIconAttach,
  USBIconAttach2,
  USBIconBat,
  USBIconBed,
  USBIconBell,
  USBIconBell2,
  USBIconBin,
  USBIconBmp,
  USBIconBranch,
  USBIconBriefcase,
  USBIconBuildings,
  USBIconCalendar,
  USBIconCamera,
  USBIconCar,
  USBIconCash,
  USBIconChair,
  USBIconChat,
  USBIconChat2,
  USBIconCheck,
  USBIconChevronDown,
  USBIconChevronLeft,
  USBIconChevronRight,
  USBIconChevronUp,
  USBIconCircleArrowDown,
  USBIconCircleArrowLeft,
  USBIconCircleArrowRight,
  USBIconCircleArrowUp,
  USBIconCircleCheckmark,
  USBIconCircularArrows,
  USBIconClear,
  USBIconClock,
  USBIconClose,
  USBIconCompass,
  USBIconComplete,
  USBIconComputer,
  USBIconCreditCard,
  USBIconCreditCardAmex,
  USBIconCreditCardDiscover,
  USBIconCreditCardMastercard,
  USBIconCreditCardVisa,
  USBIconCsv,
  USBIconDat,
  USBIconDbf,
  USBIconDeactivate,
  USBIconDelete,
  USBIconDeposit,
  USBIconDislike,
  USBIconDoc,
  USBIconDocm,
  USBIconDocument,
  USBIconDocument2,
  USBIconDocuments,
  USBIconDocuments2,
  USBIconDocx,
  USBIconDownload,
  USBIconDuplicate,
  USBIconDuplicate2,
  USBIconEdit,
  USBIconEmail,
  USBIconEmf,
  USBIconEml,
  USBIconEnvelope,
  USBIconEps,
  USBIconExternalLink,
  USBIconFilter,
  USBIconFolderClosed,
  USBIconFolderClosed2,
  USBIconFolderOpen,
  USBIconGasPump,
  USBIconGauge,
  USBIconGif,
  USBIconGift,
  USBIconGlobe,
  USBIconHandle,
  USBIconHandle2,
  USBIconHeadset,
  USBIconHelp,
  USBIconHelp2,
  USBIconHide,
  USBIconHide2,
  USBIconHome,
  USBIconHorizontalContextualMenu,
  USBIconHouse,
  USBIconHtm,
  USBIconHtml,
  USBIconInfo,
  USBIconInfo2,
  USBIconInvertColor,
  USBIconJpeg,
  USBIconJpg,
  USBIconLike,
  USBIconLineGraph,
  USBIconLink,
  USBIconList,
  USBIconLocation,
  USBIconLock,
  USBIconLock2,
  USBIconLog,
  USBIconMail,
  USBIconMdb,
  USBIconMobile,
  USBIconMobileMenu,
  USBIconModalClose,
  USBIconMoneyBag,
  USBIconMoveMoney,
  USBIconMsg,
  USBIconOdp,
  USBIconOds,
  USBIconOdt,
  USBIconOne,
  USBIconPaperAirplane,
  USBIconPaybills,
  USBIconPdf,
  USBIconPending,
  USBIconPeople,
  USBIconPercentSign,
  USBIconPerson,
  USBIconPhone,
  USBIconPieChart,
  USBIconPiggyBank,
  USBIconPng,
  USBIconPpsx,
  USBIconPpt,
  USBIconPptm,
  USBIconPptx,
  USBIconPrint,
  USBIconProfile,
  USBIconPs,
  USBIconRar,
  USBIconRecurring,
  USBIconRecurring2,
  USBIconRefresh,
  USBIconRefresh2,
  USBIconRemove,
  USBIconReturn,
  USBIconRotateLeft,
  USBIconRotateRight,
  USBIconRtf,
  USBIconSave,
  USBIconScheduled,
  USBIconSearch,
  USBIconSelectDate,
  USBIconSendMoney,
  USBIconSettings,
  USBIconShare,
  USBIconShared,
  USBIconShield,
  USBIconShoppingCart,
  USBIconShow,
  USBIconShow2,
  USBIconSignupSheet,
  USBIconSldm,
  USBIconSldx,
  USBIconSort,
  USBIconSpoonFork,
  USBIconStarOutline,
  USBIconStarOutline2,
  USBIconStarSolid,
  USBIconStarSolid2,
  USBIconStoreFront,
  USBIconSuccess,
  USBIconSvg,
  USBIconTif,
  USBIconTransfer,
  USBIconTransfer2,
  USBIconTxt,
  USBIconUmbrella,
  USBIconUnlock,
  USBIconUnlock2,
  USBIconUpload,
  USBIconVerticalContextualMenu,
  USBIconViewCheck,
  USBIconWallet,
  USBIconWarning,
  USBIconWarningSign,
  USBIconWifi,
  USBIconXlm,
  USBIconXls,
  USBIconXlsb,
  USBIconXlsm,
  USBIconXlsx,
  USBIconXml,
  USBIconZip,
  USBIconZoomIn,
  USBIconZoomOut,
} from "@usb-shield/react-icons";

import "./icons.scss";

export default function RowIcons({ rowObject }: IconsProps) {
  let icons: IconProps[] = rowObject.cell.row.original.icons?.map((icons: IconProps) => {
    return {
      ...icons,
    };
  });

  icons = icons ?? [];
  const buttonId = `sub-row-btn-${rowObject.parentId}`;
  return (
    <div
      //aria-label="show details"
      aria-labelledby={`${buttonId} td-${rowObject.cell.row.index}-0_name`}
      aria-expanded={rowObject.isExpanded}
      className={"icons"}
      id={buttonId}
      key={buttonId}
      type="button"
      {...rowObject.cell.row.getToggleRowExpandedProps({ title: undefined })}
    >
      {icons?.map((icon: IconProps) => {
        icon.size = icon.size ?? "32";
        return Icon(icon);
      })}
    </div>
  );
}

interface IconsProps {
  rowObject: {
    isExpanded: boolean;
    cell: {
      row: {
        index: number;
        getToggleRowExpandedProps: Function;
        original: any;
      };
    };
    parentId: string;
  };
}

export function Icon(props: IconProps) {
  const icon = {
    USBIcon: (
      <USBIcon colorVariant={props.colorVariant} addClasses={props.addClasses} size={props.size} />
    ),
    USBIconAdd: (
      <USBIconAdd
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconAirplane: (
      <USBIconAirplane
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconAlert: (
      <USBIconAlert
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconArrowDown: (
      <USBIconArrowDown
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconArrowLeft: (
      <USBIconArrowLeft
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconArrowRight: (
      <USBIconArrowRight
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconArrowUp: (
      <USBIconArrowUp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconAtm: (
      <USBIconAtm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconAttach: (
      <USBIconAttach
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconAttach2: (
      <USBIconAttach2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBat: (
      <USBIconBat
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBed: (
      <USBIconBed
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBell: (
      <USBIconBell
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBell2: (
      <USBIconBell2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBin: (
      <USBIconBin
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBmp: (
      <USBIconBmp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBranch: (
      <USBIconBranch
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBriefcase: (
      <USBIconBriefcase
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconBuildings: (
      <USBIconBuildings
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCalendar: (
      <USBIconCalendar
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCamera: (
      <USBIconCamera
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCar: (
      <USBIconCar
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCash: (
      <USBIconCash
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChair: (
      <USBIconChair
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChat: (
      <USBIconChat
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChat2: (
      <USBIconChat2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCheck: (
      <USBIconCheck
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChevronDown: (
      <USBIconChevronDown
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChevronLeft: (
      <USBIconChevronLeft
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChevronRight: (
      <USBIconChevronRight
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconChevronUp: (
      <USBIconChevronUp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircleArrowDown: (
      <USBIconCircleArrowDown
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircleArrowLeft: (
      <USBIconCircleArrowLeft
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircleArrowRight: (
      <USBIconCircleArrowRight
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircleArrowUp: (
      <USBIconCircleArrowUp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircleCheckmark: (
      <USBIconCircleCheckmark
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCircularArrows: (
      <USBIconCircularArrows
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconClear: (
      <USBIconClear
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconClock: (
      <USBIconClock
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconClose: (
      <USBIconClose
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCompass: (
      <USBIconCompass
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconComplete: (
      <USBIconComplete
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconComputer: (
      <USBIconComputer
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCreditCard: (
      <USBIconCreditCard
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCreditCardAmex: (
      <USBIconCreditCardAmex
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCreditCardDiscover: (
      <USBIconCreditCardDiscover
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCreditCardMastercard: (
      <USBIconCreditCardMastercard
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCreditCardVisa: (
      <USBIconCreditCardVisa
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconCsv: (
      <USBIconCsv
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDat: (
      <USBIconDat
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDbf: (
      <USBIconDbf
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDeactivate: (
      <USBIconDeactivate
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDelete: (
      <USBIconDelete
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDeposit: (
      <USBIconDeposit
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDislike: (
      <USBIconDislike
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDoc: (
      <USBIconDoc
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocm: (
      <USBIconDocm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocument: (
      <USBIconDocument
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocument2: (
      <USBIconDocument2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocuments: (
      <USBIconDocuments
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocuments2: (
      <USBIconDocuments2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDocx: (
      <USBIconDocx
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDownload: (
      <USBIconDownload
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDuplicate: (
      <USBIconDuplicate
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconDuplicate2: (
      <USBIconDuplicate2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEdit: (
      <USBIconEdit
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEmail: (
      <USBIconEmail
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEmf: (
      <USBIconEmf
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEml: (
      <USBIconEml
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEnvelope: (
      <USBIconEnvelope
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconEps: (
      <USBIconEps
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconExternalLink: (
      <USBIconExternalLink
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconFilter: (
      <USBIconFilter
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconFolderClosed: (
      <USBIconFolderClosed
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconFolderClosed2: (
      <USBIconFolderClosed2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconFolderOpen: (
      <USBIconFolderOpen
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconGasPump: (
      <USBIconGasPump
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconGauge: (
      <USBIconGauge
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconGif: (
      <USBIconGif
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconGift: (
      <USBIconGift
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconGlobe: (
      <USBIconGlobe
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHandle: (
      <USBIconHandle
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHandle2: (
      <USBIconHandle2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHeadset: (
      <USBIconHeadset
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHelp: (
      <USBIconHelp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHelp2: (
      <USBIconHelp2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHide: (
      <USBIconHide
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHide2: (
      <USBIconHide2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHome: (
      <USBIconHome
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHorizontalContextualMenu: (
      <USBIconHorizontalContextualMenu
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHouse: (
      <USBIconHouse
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHtm: (
      <USBIconHtm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconHtml: (
      <USBIconHtml
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconInfo: (
      <USBIconInfo
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconInfo2: (
      <USBIconInfo2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconInvertColor: (
      <USBIconInvertColor
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconJpeg: (
      <USBIconJpeg
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconJpg: (
      <USBIconJpg
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLike: (
      <USBIconLike
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLineGraph: (
      <USBIconLineGraph
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLink: (
      <USBIconLink
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconList: (
      <USBIconList
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLocation: (
      <USBIconLocation
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLock: (
      <USBIconLock
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLock2: (
      <USBIconLock2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconLog: (
      <USBIconLog
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMail: (
      <USBIconMail
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMdb: (
      <USBIconMdb
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMobile: (
      <USBIconMobile
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMobileMenu: (
      <USBIconMobileMenu
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconModalClose: (
      <USBIconModalClose
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMoneyBag: (
      <USBIconMoneyBag
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMoveMoney: (
      <USBIconMoveMoney
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconMsg: (
      <USBIconMsg
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconOdp: (
      <USBIconOdp
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconOds: (
      <USBIconOds
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconOdt: (
      <USBIconOdt
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconOne: (
      <USBIconOne
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPaperAirplane: (
      <USBIconPaperAirplane
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPaybills: (
      <USBIconPaybills
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPdf: (
      <USBIconPdf
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPending: (
      <USBIconPending
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPeople: (
      <USBIconPeople
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPercentSign: (
      <USBIconPercentSign
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPerson: (
      <USBIconPerson
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPhone: (
      <USBIconPhone
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPieChart: (
      <USBIconPieChart
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPiggyBank: (
      <USBIconPiggyBank
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPng: (
      <USBIconPng
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPpsx: (
      <USBIconPpsx
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPpt: (
      <USBIconPpt
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPptm: (
      <USBIconPptm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPptx: (
      <USBIconPptx
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPrint: (
      <USBIconPrint
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconProfile: (
      <USBIconProfile
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconPs: (
      <USBIconPs
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRar: (
      <USBIconRar
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRecurring: (
      <USBIconRecurring
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRecurring2: (
      <USBIconRecurring2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRefresh: (
      <USBIconRefresh
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRefresh2: (
      <USBIconRefresh2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRemove: (
      <USBIconRemove
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconReturn: (
      <USBIconReturn
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRotateLeft: (
      <USBIconRotateLeft
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRotateRight: (
      <USBIconRotateRight
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconRtf: (
      <USBIconRtf
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSave: (
      <USBIconSave
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconScheduled: (
      <USBIconScheduled
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSearch: (
      <USBIconSearch
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSelectDate: (
      <USBIconSelectDate
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSendMoney: (
      <USBIconSendMoney
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSettings: (
      <USBIconSettings
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShare: (
      <USBIconShare
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShared: (
      <USBIconShared
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShield: (
      <USBIconShield
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShoppingCart: (
      <USBIconShoppingCart
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShow: (
      <USBIconShow
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconShow2: (
      <USBIconShow2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSignupSheet: (
      <USBIconSignupSheet
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSldm: (
      <USBIconSldm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSldx: (
      <USBIconSldx
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSort: (
      <USBIconSort
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSpoonFork: (
      <USBIconSpoonFork
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconStarOutline: (
      <USBIconStarOutline
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconStarOutline2: (
      <USBIconStarOutline2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconStarSolid: (
      <USBIconStarSolid
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconStarSolid2: (
      <USBIconStarSolid2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconStoreFront: (
      <USBIconStoreFront
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSuccess: (
      <USBIconSuccess
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconSvg: (
      <USBIconSvg
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconTif: (
      <USBIconTif
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconTransfer: (
      <USBIconTransfer
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconTransfer2: (
      <USBIconTransfer2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconTxt: (
      <USBIconTxt
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconUmbrella: (
      <USBIconUmbrella
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconUnlock: (
      <USBIconUnlock
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconUnlock2: (
      <USBIconUnlock2
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconUpload: (
      <USBIconUpload
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconVerticalContextualMenu: (
      <USBIconVerticalContextualMenu
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconViewCheck: (
      <USBIconViewCheck
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconWallet: (
      <USBIconWallet
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconWarning: (
      <USBIconWarning
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconWarningSign: (
      <USBIconWarningSign
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconWifi: (
      <USBIconWifi
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXlm: (
      <USBIconXlm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXls: (
      <USBIconXls
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXlsb: (
      <USBIconXlsb
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXlsm: (
      <USBIconXlsm
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXlsx: (
      <USBIconXlsx
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconXml: (
      <USBIconXml
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconZip: (
      <USBIconZip
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconZoomIn: (
      <USBIconZoomIn
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
    USBIconZoomOut: (
      <USBIconZoomOut
        colorVariant={props.colorVariant}
        addClasses={props.addClasses}
        size={props.size}
      />
    ),
  };
  return (
    <div
      onClick={() => {
        console.log(props);
        const setModalText = (peop)=>{
          console.log("test")
        }
        const runMe: (param: any) => void = props.onClick;
        //const runMe = new Function("return " + props.onClick);
        //const runMe = new Function(run);
        console.log(typeof runMe + "");
        if (runMe) runMe(undefined);
      }}
    >
      {icon[props.iconName]}
    </div>
  );
}
export interface IconProps {
  onClick?: (param: any) => void;
  colorVariant?: string; //"warning";
  addClasses?: string; //"floating";
  size?: "20" | "24" | "32" | "40";
  iconName:
    | "USBIcon"
    | "USBIconAdd"
    | "USBIconAirplane"
    | "USBIconAlert"
    | "USBIconArrowDown"
    | "USBIconArrowLeft"
    | "USBIconArrowRight"
    | "USBIconArrowUp"
    | "USBIconAtm"
    | "USBIconAttach"
    | "USBIconAttach2"
    | "USBIconBat"
    | "USBIconBed"
    | "USBIconBell"
    | "USBIconBell2"
    | "USBIconBin"
    | "USBIconBmp"
    | "USBIconBranch"
    | "USBIconBriefcase"
    | "USBIconBuildings"
    | "USBIconCalendar"
    | "USBIconCamera"
    | "USBIconCar"
    | "USBIconCash"
    | "USBIconChair"
    | "USBIconChat"
    | "USBIconChat2"
    | "USBIconCheck"
    | "USBIconChevronDown"
    | "USBIconChevronLeft"
    | "USBIconChevronRight"
    | "USBIconChevronUp"
    | "USBIconCircleArrowDown"
    | "USBIconCircleArrowLeft"
    | "USBIconCircleArrowRight"
    | "USBIconCircleArrowUp"
    | "USBIconCircleCheckmark"
    | "USBIconCircularArrows"
    | "USBIconClear"
    | "USBIconClock"
    | "USBIconClose"
    | "USBIconCompass"
    | "USBIconComplete"
    | "USBIconComputer"
    | "USBIconCreditCard"
    | "USBIconCreditCardAmex"
    | "USBIconCreditCardDiscover"
    | "USBIconCreditCardMastercard"
    | "USBIconCreditCardVisa"
    | "USBIconCsv"
    | "USBIconDat"
    | "USBIconDbf"
    | "USBIconDeactivate"
    | "USBIconDelete"
    | "USBIconDeposit"
    | "USBIconDislike"
    | "USBIconDoc"
    | "USBIconDocm"
    | "USBIconDocument"
    | "USBIconDocument2"
    | "USBIconDocuments"
    | "USBIconDocuments2"
    | "USBIconDocx"
    | "USBIconDownload"
    | "USBIconDuplicate"
    | "USBIconDuplicate2"
    | "USBIconEdit"
    | "USBIconEmail"
    | "USBIconEmf"
    | "USBIconEml"
    | "USBIconEnvelope"
    | "USBIconEps"
    | "USBIconExternalLink"
    | "USBIconFilter"
    | "USBIconFolderClosed"
    | "USBIconFolderClosed2"
    | "USBIconFolderOpen"
    | "USBIconGasPump"
    | "USBIconGauge"
    | "USBIconGif"
    | "USBIconGift"
    | "USBIconGlobe"
    | "USBIconHandle"
    | "USBIconHandle2"
    | "USBIconHeadset"
    | "USBIconHelp"
    | "USBIconHelp2"
    | "USBIconHide"
    | "USBIconHide2"
    | "USBIconHome"
    | "USBIconHorizontalContextualMenu"
    | "USBIconHouse"
    | "USBIconHtm"
    | "USBIconHtml"
    | "USBIconInfo"
    | "USBIconInfo2"
    | "USBIconInvertColor"
    | "USBIconJpeg"
    | "USBIconJpg"
    | "USBIconLike"
    | "USBIconLineGraph"
    | "USBIconLink"
    | "USBIconList"
    | "USBIconLocation"
    | "USBIconLock"
    | "USBIconLock2"
    | "USBIconLog"
    | "USBIconMail"
    | "USBIconMdb"
    | "USBIconMobile"
    | "USBIconMobileMenu"
    | "USBIconModalClose"
    | "USBIconMoneyBag"
    | "USBIconMoveMoney"
    | "USBIconMsg"
    | "USBIconOdp"
    | "USBIconOds"
    | "USBIconOdt"
    | "USBIconOne"
    | "USBIconPaperAirplane"
    | "USBIconPaybills"
    | "USBIconPdf"
    | "USBIconPending"
    | "USBIconPeople"
    | "USBIconPercentSign"
    | "USBIconPerson"
    | "USBIconPhone"
    | "USBIconPieChart"
    | "USBIconPiggyBank"
    | "USBIconPng"
    | "USBIconPpsx"
    | "USBIconPpt"
    | "USBIconPptm"
    | "USBIconPptx"
    | "USBIconPrint"
    | "USBIconProfile"
    | "USBIconPs"
    | "USBIconRar"
    | "USBIconRecurring"
    | "USBIconRecurring2"
    | "USBIconRefresh"
    | "USBIconRefresh2"
    | "USBIconRemove"
    | "USBIconReturn"
    | "USBIconRotateLeft"
    | "USBIconRotateRight"
    | "USBIconRtf"
    | "USBIconSave"
    | "USBIconScheduled"
    | "USBIconSearch"
    | "USBIconSelectDate"
    | "USBIconSendMoney"
    | "USBIconSettings"
    | "USBIconShare"
    | "USBIconShared"
    | "USBIconShield"
    | "USBIconShoppingCart"
    | "USBIconShow"
    | "USBIconShow2"
    | "USBIconSignupSheet"
    | "USBIconSldm"
    | "USBIconSldx"
    | "USBIconSort"
    | "USBIconSpoonFork"
    | "USBIconStarOutline"
    | "USBIconStarOutline2"
    | "USBIconStarSolid"
    | "USBIconStarSolid2"
    | "USBIconStoreFront"
    | "USBIconSuccess"
    | "USBIconSvg"
    | "USBIconTif"
    | "USBIconTransfer"
    | "USBIconTransfer2"
    | "USBIconTxt"
    | "USBIconUmbrella"
    | "USBIconUnlock"
    | "USBIconUnlock2"
    | "USBIconUpload"
    | "USBIconVerticalContextualMenu"
    | "USBIconViewCheck"
    | "USBIconWallet"
    | "USBIconWarning"
    | "USBIconWarningSign"
    | "USBIconWifi"
    | "USBIconXlm"
    | "USBIconXls"
    | "USBIconXlsb"
    | "USBIconXlsm"
    | "USBIconXlsx"
    | "USBIconXml"
    | "USBIconZip"
    | "USBIconZoomIn"
    | "USBIconZoomOut";
}
