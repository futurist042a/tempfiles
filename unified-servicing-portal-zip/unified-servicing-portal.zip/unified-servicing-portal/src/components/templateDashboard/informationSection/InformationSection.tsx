import "./informationSection.scss";

export default function InformationSection(props) {
  return (
    <div className="informationSection-div">
      {props.children}
    </div>
  );
}
