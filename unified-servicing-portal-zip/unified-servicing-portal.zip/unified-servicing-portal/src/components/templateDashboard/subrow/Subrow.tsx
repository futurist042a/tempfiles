import React from "react";
import { Icon, IconProps } from "../table/Icons";
import "./SubRow.scss";

export interface SubRowProps {
  title?: string; //can be null
  subRowObjectList: SubRowObject[];
  columns: number;
}

export interface SubRowObject {
  text_title: string;
  text_label: string;
  iconProps?: IconProps;
  onClick?: (param: any) => void;
}

export default function SubRow({ title, subRowObjectList, columns = 3 }: SubRowProps) {
  return (
    <div className="subrow-container">
      {title && <h2>{title}</h2>}
      <div className="subrow-grid" style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}>
        {subRowObjectList.map((subRowObject, index) => {
          return (
            <div key={index} className="subrow-item">
              <div className="subrow-content">
                <div className="subrow-text">
                  <strong>{subRowObject.text_title}</strong>
                </div>
                <div className="subrow-icon-label">
                {subRowObject.iconProps &&<Icon {...subRowObject.iconProps} />}
                  <p>{subRowObject.text_label}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
