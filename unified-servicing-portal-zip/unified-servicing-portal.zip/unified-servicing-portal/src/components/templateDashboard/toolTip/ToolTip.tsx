import React from "react";
import "./toolTip.scss";

type toolTipProps = {
  children: string | React.ReactNode; //| (() => JSX.Element);
  tooltipText: string;
  position: "right" | "left" | "top" | "bottom";
};

export default function ToolTip(props: toolTipProps) {
  return (
    <div className="tooltip-trigger">
      {props.children}
      <div className={`tooltip tooltip-${props.position}`}>{props.tooltipText}</div>
    </div>
  );
}
