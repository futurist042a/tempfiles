import styled from "styled-components";

export const LeftNavPlaneStyles = styled.div`
.floating {
 // position: -webkit-sticky;
  position: relative;
 // z-index: 9999;
  margin: 10px;
}

.floating.svg-icon.interaction {
    color: #656868;
    fill: #656868;
}
`;