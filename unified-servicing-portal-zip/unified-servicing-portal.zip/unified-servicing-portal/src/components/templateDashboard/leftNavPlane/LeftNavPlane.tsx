/* eslint-disable import/no-extraneous-dependencies */
import USBDrawer, {
  USBDrawerHeader,
  USBDrawerBody,
  USBDrawerFooter,
} from "@usb-shield/react-drawer";
import { USBIconMobileMenu } from "@usb-shield/react-icons";
import { useState } from "react";
import USBButton from "@/components/usb-shield/react-button";

import { LeftNavPlaneStyles } from "./LeftNavPlane.Style";
// Design Tokens
import "@usb-shield/react-drawer/dist/library/styles/index.css";

export default function LeftNavPlane(props: {
  navLinks: { linkString: string; linkValue: string; isDisabled: boolean }[];
}) {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <LeftNavPlaneStyles>
      <USBButton
        handleClick={() => setIsVisible(true)}
        ctaStyle="utility"
        emphasis="subtle"
        size="medium"
        title="home"
      >
        <USBIconMobileMenu addClasses="floating" size="32" />
      </USBButton>
      <USBDrawer
        handleClose={() => setIsVisible(false)}
        id="usb-drawer"
        isOpen={isVisible}
        position="left"
        preventPageScroll={false}
        shouldFooterScroll={false}
      >
        <USBDrawerHeader id="title">
          {props.navLinks &&
            props.navLinks.map(({ linkString, linkValue, isDisabled }) => {
              return (
                <USBButton
                  key={linkString}
                  ctaStyle="utility"
                  emphasis="subtle"
                  disabled={isDisabled}
                >
                  {linkString}
                </USBButton>
              );
            })}
          {/*
          <USBButton ctaStyle="utility" emphasis="subtle">
            Navigation Link 1
          </USBButton>
          <USBButton ctaStyle="utility" emphasis="subtle">
            Navigation Link 2
          </USBButton>
          <USBButton ctaStyle="utility" emphasis="subtle">
            Navigation Link 3
          </USBButton>
          <USBButton ctaStyle="utility" emphasis="subtle">
            Navigation Link 4
          </USBButton>
          <USBButton ctaStyle="utility" emphasis="subtle">
            Navigation Link 5
          </USBButton> */}
        </USBDrawerHeader>
      </USBDrawer>
    </LeftNavPlaneStyles>
  );
}
