import TemplateDashboard from "./TemplateDashboard";
import "@usb-shield/react-tabs/dist/library/styles/index.css";

export default TemplateDashboard