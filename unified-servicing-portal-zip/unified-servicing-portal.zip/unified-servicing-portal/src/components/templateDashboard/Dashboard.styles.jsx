import styled from "styled-components";

// cspell:ignore conatiner
export const DashboardStyles = styled.div`

  .usb-table_table {
    grid-template-columns: repeat(${(props) => props.numColumns || "6"}, auto);
  }
`;
