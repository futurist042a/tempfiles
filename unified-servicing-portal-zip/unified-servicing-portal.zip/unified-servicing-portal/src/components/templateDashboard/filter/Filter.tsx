import USBDropdown from "@usb-shield/react-dropdown";
import "@usb-shield/react-dropdown/dist/library/styles/index.css";
import React, { ReactNode, useCallback, useEffect, useRef, useState } from "react";

import "@usb-shield/react-forms-base/dist/library/styles/index.css";
import USBTextInput from "@usb-shield/react-forms-input-text";

import USBActionChips, { USBChip } from "@usb-shield/react-action-chips";
import "@usb-shield/react-action-chips/dist/library/styles/index.css";
import USBTooltip from "@usb-shield/react-tooltip";
import "@usb-shield/react-tooltip/dist/library/styles/index.css";

import "@usb-shield/react-calendar/dist/library/styles/index.css";
import USBDatePicker from "@usb-shield/react-date-picker";
import "@usb-shield/react-date-picker/dist/library/styles/index.css";

import USBDateInput from "@usb-shield/react-forms-input-date";

import USBButton from "@usb-shield/react-button";
// import '@usb-shield/react-button/dist/library/styles/index.css'
import { USBIconAdd } from "@usb-shield/react-icons";
import { Icon, IconProps } from "../table/Icons";

import { USBIconRefresh } from "@/components/usb-shield/react-icons";
import "./index.scss";

import USBCheckbox from "@usb-shield/react-forms-checkbox";
import USBCheckboxGroup from "@usb-shield/react-forms-checkbox-group";
import USBModal, { ModalBody, ModalFooter, ModalHeader } from "@usb-shield/react-modal";
import ToolTip from "../toolTip/ToolTip";

interface FilterChip {
  filterKey: string;
  value: string;
}

//Not currently used, but will be useful when there are more options
export enum filterInputTypes {
  text = "TEXT",
  dropdown = "DROPDOWN",
  date = "DATE",
  multiSelect = "MULTI_SELECT",
}

const filterDates = {
  filterTo: "filterTo",
  filterFrom: "filterFrom",
};

interface FilterProps {
  objList: any[];
  setObjList: (param: any) => void;
  filterObjects: {
    filterBy?: {
      labelString: string;
      filterKey: string;
      inputType: filterInputTypes;
      dropdownValues?: string[];
    }[];
    tableActions?: { title: string; action?: (param: any) => void }[];
  };
}

export default function Filter(props: FilterProps) {
  const [currentDropdownArray, setCurrentDropdownArray] = useState(undefined);
  const [currentFilterKey, setCurrentFilterKey] = useState(undefined);

  const [currentFilterByObj, setCurrentFilterByObj] = useState<{
    labelString: string;
    filterKey: string;
    inputType: filterInputTypes;
    dropdownValues?: string[];
  }>(props.filterObjects.filterBy[0]);
  //console.log("props", props);
  //! an undefined category will be treated as a search
  const maxChipCount = 6;
  const [chipsObjectArray, setChipsObjectArray] = useState<FilterChip[]>([
    { filterKey: "test", value: "Passport.jpg" },
    { filterKey: "test", value: "Paystub4-22.jpg" },
  ]);
  //const [maxArrayChipsObj, setMaxArrayChipsObj] = useState<FilterChip[]>(chipsObjectArray);

  const [input, setInput] = useState(undefined);
  const [toDateInput, setToDateInput] = useState(undefined);
  const [fromDateInput, setFromDateInput] = useState(undefined);

  const setChipsAndRemoveDuplicates = useCallback(
    (newObject: FilterChip) => {
      const chips: FilterChip[] = [...chipsObjectArray, newObject];
      // const removeDuplicatesByKey = (key: keyof FilterChip) => {
      //   const seen = new Set();
      //   const filteredItems = chips.filter((item) => {
      //     const keyValue = item[key];
      //     if (seen.has(keyValue)) {
      //       return false;
      //     } else {
      //       seen.add(keyValue);
      //       return true;
      //     }
      //   });
      //   return filteredItems;
      // };
      //const filtered: FilterChip[] = removeDuplicatesByKey("filterKey");
      const seenMap = new Map<string, FilterChip>([]);

      for (const chip of chips) {
        seenMap.set(chip.filterKey, chip);
      }
      const filtered = Array.from(seenMap.values());
      setChipsObjectArray(filtered.slice(0, maxChipCount));
    },
    [chipsObjectArray],
  );

  const FilterInputComponent = useCallback(() => {
    currentFilterByObj;
    //TODO add chip creation on click and submit
    const [openModal, setOpenModal] = useState(false);
    let filterObject;

    //console.log(currentFilterByObj?.inputType);
    switch (currentFilterByObj?.inputType) {
      case filterInputTypes.date:
        break;
      case filterInputTypes.dropdown:
        filterObject = (
          <USBDropdown
            id={currentFilterByObj.labelString}
            addClasses={"test-class"}
            dropdownType="outlined"
            label={currentFilterByObj.labelString}
            items={currentFilterByObj.dropdownValues.map((x) => {
              return { id: x, value: x };
            })}
            handleChange={(e) => {
              const value = e.target?.value;
              if (value) {
                setChipsAndRemoveDuplicates({ filterKey: currentFilterKey, value: value });
              }
              // if (value) {
              //   if (
              //     !chipsObjectArray.find((chip) => {
              //       return chip.filterKey == currentFilterKey && chip.value == value;
              //     })
              //   ) {
              //     setChipsObjectArray([
              //       ...chipsObjectArray,
              //       { filterKey: currentFilterKey, value: value },
              //     ]);
              //   }
              // }
            }}
          />
        );
        break;
      case filterInputTypes.multiSelect:
        let inputValue = [];
        filterObject = (
          <>
            <USBButton
              ctaStyle="standard"
              emphasis="heavy"
              iconElement={<USBIconAdd size="16" />}
              iconPosition="left"
              size="small"
              title="home"
              addClasses="filter-button"
              handleClick={(e) => {
                //console.log("modal click", e);
                setOpenModal(true);
              }}
            >
              {currentFilterByObj.labelString}
            </USBButton>
            <USBModal
              handleClose={() => setOpenModal(false)}
              id="modal-storybook"
              isOpen={openModal}
            >
              <ModalHeader id="one">{currentFilterByObj.labelString}</ModalHeader>
              <ModalBody>
                <USBCheckboxGroup
                  inputName="checkbox-group"
                  legendText="Legend name"
                  //options={[{ label: "Option 1" }, { label: "Option 2" }]}
                  statusUpdateCallback={(e) => {
                    inputValue = e.inputValue;
                    //console.log("status update", e);
                  }}
                  options={[
                    ...currentFilterByObj.dropdownValues.map((val) => {
                      return {
                        label: val,
                      };
                    }),
                  ]}
                />
              </ModalBody>
              <ModalFooter>
                <USBButton
                  variant="primary"
                  handleClick={(e) => {
                    console.log("inputValue", inputValue);
                    const onlyCheckedValues = inputValue.filter(
                      (val: { label: string; id: string; checked?: boolean }) => {
                        return val.checked;
                      },
                    );

                    const checkedArray = onlyCheckedValues.map((obj) => {
                      return obj.label;
                    });

                    setChipsAndRemoveDuplicates({
                      filterKey: currentFilterKey,
                      value: checkedArray.toString(),
                    });
                    setOpenModal(false);
                  }}
                >
                  Submit
                </USBButton>
                <USBButton
                  variant="secondary"
                  handleClick={(e) => {
                    inputValue = [];
                    setOpenModal(false);
                  }}
                >
                  Cancel
                </USBButton>
              </ModalFooter>
            </USBModal>
          </>
        );
        break;
      case filterInputTypes.text:
        let str = undefined;
        filterObject = (
          <div
            onKeyDown={(e) => {
              console.log("input", str);
              if (e.code == "Enter") {
                if (str) {
                  setChipsAndRemoveDuplicates({ filterKey: currentFilterKey, value: str });
                }
              }
            }}
          >
            <USBTextInput
              id={currentFilterByObj.labelString}
              inputName="input-name"
              labelText={currentFilterByObj.labelString}
              isOptional={true}
              helperTextOptional={""}
              callbackFrequency={"every"}
              autoCapitalize={"words"}
              statusUpdateCallback={(e) => {
                //console.log(e);
                const value = e.inputValue;
                if (value) {
                  //console.log("value:", value);
                  str = value;
                }
              }}
              errorMessages={(e) => {
                console.log(e);
              }}
            />
          </div>
        );
        break;
      default:
        filterObject = <></>;
        // filterObject = (
        //   <USBTextInput
        //     id={currentFilterByObj.labelString}
        //     inputName="input-name"
        //     labelText={currentFilterByObj.labelString}
        //     isOptional={true}
        //     helperTextOptional={""}
        //     callbackFrequency={"every"}
        //     statusUpdateCallback={(e) => {
        //       //console.log(e);
        //       const value = e.inputValue;
        //       if (value) {
        //         //console.log("value:", value);
        //         setInput(value);
        //       }
        //     }}
        //     errorMessages={(e) => {
        //       console.log(e);
        //     }}
        //   />
        // );
        break;
    }

    return filterObject;
  }, [currentFilterByObj]);

  //? On every change update the object list
  useEffect(() => {
    props.setObjList(
      filterObjects(
        props.objList,
        chipsObjectArray.map((chip) => {
          return { key: chip.filterKey, value: chip.value };
        }),
      ),
    );
  }, [chipsObjectArray]);

  //console.log("chips:", chips);
  return (
    <div className="filter-wrapper">
      <div key={"filter-container"} className="filter-options-container">
        {/* //? TABLE ACTION */}
        <div className="filter-table" key={"filter-table"}>
          <USBDropdown
            id={"dropdown-tableAction"}
            addClasses={"test-class"}
            dropdownType="outlined"
            label={"Actions"}
            listPosition="bottom"
            items={props.filterObjects.tableActions?.map((tableAction, index) => {
              return { id: index, value: tableAction.title, disabled: false };
            })}
            handleChange={(e) => {
              const action = props.filterObjects.tableActions[e.target.id]?.action;
              // console.log("Dropdown Changed to", e.target.id);
              // console.log("action", action);
              if (action) action(undefined);
            }}
          />
        </div>
        {/* //? FILTERED BY*/}
        <div key={"filter-by"} className="filter-by">
          <USBDropdown
            id={"dropdown-filterBy"}
            addClasses={"test-class"}
            dropdownType="outlined"
            label="FILTER BY"
            items={props.filterObjects.filterBy.map((x) => {
              return { id: x.labelString, value: x.labelString };
            })}
            handleChange={(e) => {
              const val = props.filterObjects.filterBy.find(({ labelString }) => {
                return e.target.id == labelString;
              });
              console.log(val);
              setCurrentDropdownArray(val?.dropdownValues);
              setCurrentFilterKey(val.filterKey);
              setCurrentFilterByObj(val);
              setInput(undefined); //Reset the filter input so the old input can't be used
            }}
          />
        </div>
        {/* //? FILTER FROM*/}
        <div
          key={"filter-from"}
          className="filter-from"
          onKeyDown={(e) => {
            if (e.code == "Enter" || e.code == "NumpadEnter") {
              if (fromDateInput) {
                if (
                  !chipsObjectArray.find((chip) => {
                    return chip.filterKey === filterDates.filterFrom;
                  }) &&
                  isDateValid(fromDateInput)
                ) {
                  setChipsObjectArray([
                    ...chipsObjectArray,
                    { filterKey: filterDates.filterFrom, value: fromDateInput },
                  ]);
                }
              }
            }
          }}
        >
          <Icon iconName={"USBIconCalendar"} addClasses="filter-icon" />
          <div className="filter-date-input">
            <USBDateInput
              // ref={textInputRef}
              dateFormat="mm/dd/yyyy"
              inputName="date-input"
              occurrence="both"
              labelText="From Date"
              helperTextOptional={""}
              errorMessages={{
                default: "Enter a valid date.",
                118: "Enter a valid billing date.",
                121: "You've reached the character limit. Please try again.",
                130: "Please enter your billing date again.",
                201: "Enter a valid billing date.",
                202: "Date should be in the past.",
                203: "Date should be in the future.",
                204: "You must be at least 18 years old to apply.",
                205: "You must be less than 120 years old to apply.",
                224: "Billing date is required.",
              }}
              statusUpdateCallback={({ inputValue }) => {
                setFromDateInput(inputValue);
              }}
              isOptional={true}
              callbackFrequency={"every"}
            />
          </div>
        </div>

        {/* //? FILTER BLANK*/}
        <div key={"filter-blank"} className="filter-blank">
          <USBButton
            //ctaStyle="utility"
            variant="primary"
            //emphasis="heavy"
            iconPosition="center"
            size="medium"
          >
            <Icon iconName={"USBIconRefresh"} addClasses="filter-icon" colorVariant="warning" />
          </USBButton>
        </div>
        {/* {//! Line break} */}

        {/* //? FILTER INPUT*/}
        <div className="filter-input" key={"filter-input"}>
          {FilterInputComponent()}
        </div>
        {/* //? FILTER TO */}
        <div
          key={"filter-to"}
          className="filter-to"
          onKeyDown={(e) => {
            if (e.code == "Enter" || e.code == "NumpadEnter") {
              if (toDateInput) {
                if (
                  !chipsObjectArray.find((chip) => {
                    return chip.filterKey === filterDates.filterTo;
                  }) &&
                  isDateValid(toDateInput)
                ) {
                  //console.log("set chips");
                  setChipsObjectArray([
                    ...chipsObjectArray,
                    { filterKey: filterDates.filterTo, value: toDateInput },
                  ]);
                }
              }
            }
          }}
        >
          {/* <USBDatePicker
              content={{
                dateInput: {
                  labelText: "New input label",
                  helperText: "dd/mm/yyyy",
                  calendarButtonAriaLabel: "Choose start date", // if labelText changes, then this should be updated
                  errorMessages: {
                    224: "Start date required.", // will only change this error message, the rest will be the same
                  },
                },
                calendar: {
                  srOnlyYearLegend: "New legend",
                },
                // <!-- isRange ONLY -->
                legend: "New legend",
                legendHelperText: "Legend helper text", // optional
                endDateInput: {
                  labelText: "New label text for end date",
                  helperText: "dd/mm/yyyy",
                },
              }}
            /> */}

          <Icon iconName={"USBIconCalendar"} addClasses="filter-icon" />
          <div className="filter-date-input">
            <USBDateInput
              // ref={textInputRef}
              dateFormat="mm/dd/yyyy"
              inputName="date-input"
              occurrence="both"
              labelText="To Date"
              helperTextOptional={""}
              errorMessages={{
                default: "Enter a valid date.",
                118: "Enter a valid billing date.",
                121: "You've reached the character limit. Please try again.",
                130: "Please enter your billing date again.",
                201: "Enter a valid billing date.",
                202: "Date should be in the past.",
                203: "Date should be in the future.",
                204: "You must be at least 18 years old to apply.",
                205: "You must be less than 120 years old to apply.",
                224: "Billing date is required.",
              }}
              statusUpdateCallback={({ inputValue }) => {
                setToDateInput(inputValue);
              }}
              isOptional={true}
              callbackFrequency={"every"}
            />
          </div>
        </div>
      </div>
      {/* //? FILTER CHIPS*/}
      <div key={"filter-chips"} className="filter-chips">
        <USBActionChips
          heading=""
          headingLevel="h3"
          id="storybook-action-chips"
          options={chipsObjectArray.map((chip) => {
            return chip.value;
          })}
          type="removable"
          maxChipsPerRow={5}
          mas
          statusUpdateCallback={(status) => {
            const removed = status.chips?.lastRemoved?.id;
            //console.log(removed);
            const filteredList = chipsObjectArray.filter((element) => {
              const id =
                element.filterKey +
                (element.filterKey === filterDates.filterFrom ||
                element.filterKey === filterDates.filterTo
                  ? Date.parse(element.value)
                  : element.value);
              return id != removed;
            });
            //console.log(filteredList);
            setChipsObjectArray(filteredList);
          }}
        >
          {/* <USBChip id="Passport.jpg">Passport.jpg</USBChip> */}
          {chipsObjectArray.map((chip) => {
            const id =
              chip.filterKey +
              (chip.filterKey === filterDates.filterFrom || chip.filterKey === filterDates.filterTo
                ? Date.parse(chip.value)
                : chip.value);

            const chipString =
              chip.filterKey +
              ":" +
              (isDateValid(chip.value) ? new Date(chip.value).toDateString() : chip.value);

            const maxStingLength = 30;
            const cutString = chipString.slice(0, maxStingLength);
            if (chipString.length >= maxStingLength) {
              return (
                <USBChip key={id} id={id}>
                  <ToolTip tooltipText={chipString} position={"top"}>
                    {cutString}
                  </ToolTip>
                </USBChip>
              );
            } else {
              return (
                <USBChip key={id} id={id}>
                  {cutString}
                </USBChip>
              );
            }
          })}
        </USBActionChips>
      </div>
    </div>
  );
}

//? This is defined out here because I feel the filter component should be universal and the filter logic can be passed in
//* this filter function
function filterObjects(objects: any[], filterChipObjects: { key: string; value: any }[]) {
  let filteredObjects = objects;
  //For each Filter Chip
  filterChipObjects?.forEach((chip: { key; value }) => {
    filteredObjects = filteredObjects?.filter((objectForTable) => {
      let passesFilter = false;
      //Special case for undefined keys for the 'search all'
      if (!chip.key) {
        //If any of the values[] in the object include the value
        passesFilter = Object.values(objectForTable).includes(chip.value);
      } else {
        passesFilter = objectForTable[chip.key] == chip.value;
      }

      if (chip.value === filterDates.filterTo || chip.value === filterDates.filterFrom) {
        const chipDate = Date.parse(chip.value);
        //TODO UPDATED THIS
        const objDate = objectForTable.date;
        if (objDate && chipDate)
          passesFilter =
            chip.value === filterDates.filterTo ? chipDate <= objDate : objDate <= chipDate;
        //                                        Filter To             Filter From
      }

      return passesFilter;
    });
  });
  //console.log(filteredObjects);
  return (filteredObjects?.length ?? 0 > 0 ? filterChipObjects : objects) ?? [];
}

function isDateValid(dateString: string) {
  return !isNaN(new Date(dateString).getTime());
}
