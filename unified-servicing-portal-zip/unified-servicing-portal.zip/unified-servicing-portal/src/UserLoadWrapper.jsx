import PropTypes from "prop-types";
import { useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router";
import { getUserRoleList } from "./actions/dashboardTableAction";
import { Loader } from "./components/common/Loader";
import { API_CALL_STATUS, USER_ROLE } from "./constants/constant";
import { selectAccessToken, selectPreferredUsername } from "./selectors/oidcSelectors";
import { selectUserRole, selectUserRoleStatus } from "./selectors/userSelectors";

export default function UserLoadWrapper({ children }){
  const dispatch = useDispatch();
  const mounted = useRef(false);

  const accessToken = useSelector(selectAccessToken);
  const preferredUsername = useSelector(selectPreferredUsername);
  const userRole = useSelector(selectUserRole);
  const roleListStatus = useSelector(selectUserRoleStatus);
  const rolesLoadedSuccessfully = roleListStatus === API_CALL_STATUS.SUCCESS;
  //const userHasNoValidRoles = !Object.values(USER_ROLE).includes(userRole);

  useEffect(() => {
    if (accessToken && !mounted.current) {
      dispatch(getUserRoleList(preferredUsername));
      mounted.current = true;
    }
  }, [accessToken, preferredUsername]);

  // if (rolesLoadedSuccessfully && userHasNoValidRoles) {
  //   return <Navigate to="/unauthorized-user" />;
  // }

  switch (roleListStatus) {
    case API_CALL_STATUS.FAILED: {
      return <Navigate to="/error" />;
    }
    case API_CALL_STATUS.SUCCESS: {
      return children;
    }
    default: {
      return <Loader loading />;
    }
  }
};

UserLoadWrapper.propTypes = {
  children: PropTypes.node.isRequired,
};
