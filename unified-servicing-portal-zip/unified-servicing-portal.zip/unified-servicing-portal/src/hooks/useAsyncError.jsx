import { useCallback, useState } from "react";

/**
 * This hook can be used to programmatically trigger an error boundary.
 * It takes advantage of a little known fact that the React renderer will throw
 * when a state setter function throws.
 *
 * This "trick" was recommended by Dan Abramov in this GitHub comment:
 * @see https://github.com/facebook/react/issues/14981#issuecomment-468460187
 *
 * Unfortunately, no explanation as to why this works was provided, but a little
 * research revealed some clues. Keep reading if you're interested.
 *
 * There's a function called dispatchSetState which is connected to the useState
 * hook (it's a little complicated how dispatchSetState gets invoked, but it's
 * not super relevant). Inside dispatchSetState, there is a call to
 * lastRenderedReducer(currentState, action).
 *
 * This is one place where the state setter would throw an error...
 * @see https://github.dev/facebook/react/blob/493f72b0a7111b601c16b8ad8bc2649d82c184a0/packages/react-reconciler/src/ReactFiberHooks.js#L2795
 *
 * ...because lastRenderedReducer is initialized on mount as a basicStateReducer...
 * @see https://github.dev/facebook/react/blob/493f72b0a7111b601c16b8ad8bc2649d82c184a0/packages/react-reconciler/src/ReactFiberHooks.js#L1732
 *
 * ...which calls action(state) when the action is a function. In your case, it's a function that throws an error.
 * @see https://github.dev/facebook/react/blob/493f72b0a7111b601c16b8ad8bc2649d82c184a0/packages/react-reconciler/src/ReactFiberHooks.js#L1162
 *
 * However, the error is ignored in dispatchSetState, but this comment tells us
 * that the renderer would take care of the error.
 * @see https://github.com/facebook/react/blob/493f72b0a7111b601c16b8ad8bc2649d82c184a0/packages/react-reconciler/src/ReactFiberHooks.js#L2812
 *
 * Since error boundaries are triggered by rendering errors, now it makes sense
 * that they would be triggered by errors in state setters.
 *
 * @returns {(error: Error) => void} Function used to trigger an error boundary.
 */
export const useAsyncError = () => {
  const [, setError] = useState();
  const triggerErrorBoundary = useCallback(
    /**
     * @param {Error} error
     * @throws {Error}
     */
    (error) => {
      setError(() => {
        throw error;
      });
    },
    [setError],
  );
  return triggerErrorBoundary;
};
