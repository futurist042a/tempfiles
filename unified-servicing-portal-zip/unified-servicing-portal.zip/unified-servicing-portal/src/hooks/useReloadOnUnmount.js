import { useEffect, useRef } from "react";

/**
 * Reloads the application when the component invoking
 * this hook is unmounted.
 */
export function useReloadOnUnmount() {
  const mounted = useRef(false);

  useEffect(() => {
    mounted.current = true;
    return () => {
      if (mounted.current) {
        window.location.reload();
      }
    };
  }, []);
}
