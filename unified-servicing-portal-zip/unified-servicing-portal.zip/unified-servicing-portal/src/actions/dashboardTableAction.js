import axios from "axios";
import {
  failedFetchingTableMetadata,
  failedFetchingTaskList,
  startFetchingTableMetadata,
  startFetchingTaskList,
  successFetchingTableMetadata,
  successFetchingTaskList,
} from "@/reducers/dashboardTableSlice";
import {
  failedFetchingHeader,
  startFetchingHeader,
  successFetchingHeader,
} from "@/reducers/eventDetailsSlice";
import { failedUserRoleList, startUserRoleList, successUserRoleList } from "@/reducers/userSlice";
import { router } from "@/router";
import { selectUserRole } from "@/selectors/userSelectors";
import {
  getDashboardTableData,
  getTableHeaderDetails,
  getTableMetadataByPageName,
  getUserAssignedRoles,
  getDashboardTaskData,
} from "@/services/exp-api-service";

export const getTaskList = (taskType) => {
  return async (dispatch, getState) => {
    const state = getState();
    const userRole = selectUserRole(state);
    dispatch(startFetchingTaskList());
    try {
      console.log("get task list")
      const res = await getDashboardTableData(taskType, userRole);
      // const tasks = (res.data.data.eventsFromDB || []).filter(
      //   /**
      //    * When a user clicks Initiate Onboarding and doesn't do anything,
      //    * a new onboarding is created in the database with an empty array of products.
      //    * Since products are the first required piece of data to continue with
      //    * an onboarding, when we get an empty array of products array it means
      //    * that the user started an onboarding and gave up. This is garbage data
      //    * and should not be showing on the dashboard.
      //    *
      //    * On the front end, this has another implication: on a new onboarding,
      //    * the metadata call comes back as a 204. This breaks the expectation for
      //    * the details page: what is the point of showing an empty details page?!
      //    *
      //    * We have asked the backend team to filter out this unwanted data,
      //    * but they have refused to do it, so we have to do it ourselves for now.
      //    */
      //   (task) => task.product.length > 0,
      // );
      const tasks = res.data.data.commonOnBoardingEvent;
      //console.log(tasks)
      dispatch(successFetchingTaskList(tasks));
    } catch (error) {
      // console.log("failed to fetch")
      // console.log(error)
      dispatch(failedFetchingTaskList());
    }
  };
};

export const getCommonObjects = () => {
  //TODO this logic to determing onboarding and servicing should be done in the back end
  const businessLines = ["CT", "CCB_LEASE", "CCB_LOAN"]; // Onboarding , Servicing
  return async (dispatch) => {
    dispatch(startFetchingTaskList());
    try {
      let tasks = [];
      const promises = [];

      for (const element of businessLines) {
        promises.push(getDashboardTableData(element));
      }

      const results = await(await Promise.all(promises)).map((c) => {
        return c.data.data.commonOnBoardingEvent;
      });

      tasks = results.reduce((acc, curVal) => acc.concat(curVal), []);
      dispatch(successFetchingTaskList(tasks));
    } catch (error) {
      dispatch(failedFetchingTaskList());
    }
  };
};

export const getTableMetaData = () => {
  return async (dispatch, getState) => {
    const state = getState();
    const userRole = selectUserRole(state);
    dispatch(startFetchingTableMetadata());
    try {
      /*
       * getTableMetaDataByPageName is a function that creates a header for the api call.
       *  this is where the api call is made.
       */
      const res = await getTableMetadataByPageName({ pageName: "dashboard", userRole });

      //Get mocked data
      //const res = await axios.get("/table-metadata.json");

      //console.log("calling");
      //if we get the data
      const metadata = res.data?.myQueueDataTab;
      //if (res.data?.onBoardings?.length) {
      if (metadata.length) {
        //dispatch(successFetchingTableMetadata(res.data.onBoardings));
        dispatch(successFetchingTableMetadata(metadata));
        //if we do not get the data
      } else {
        dispatch(failedFetchingTableMetadata());
        router.navigate("/error");
      }
      //if we error somewhere
    } catch (error) {
      //console.log("catch error");
      dispatch(failedFetchingTableMetadata());
    }
  };
};

export const getUserRoleList = (userId) => {
  return async (dispatch) => {
    dispatch(startUserRoleList());
    try {
      const res = await getUserAssignedRoles(userId);
      dispatch(successUserRoleList(res.data.userDetails));
    } catch (error) {
      dispatch(failedUserRoleList());
    }
  };
};

export const getHeaderDetails = (onboardingId, throwError) => {
  return async (dispatch) => {
    dispatch(startFetchingHeader());
    try {
      const res = await getTableHeaderDetails(onboardingId);
      dispatch(successFetchingHeader(res));
    } catch (error) {
      dispatch(failedFetchingHeader());
      throwError(new Error());
    }
  };
};
