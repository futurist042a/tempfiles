import { produce } from "immer";
import { INITIATE_ONBOARDING_FORM_NAME } from "@/constants/constant";
import {
  failedFetchingForm,
  failedFetchingGetTab,
  failedFetchingMetaData,
  failedInitiateOnboarding,
  failedPostDataPoint,
  failedPostingForm,
  failedPostMetaData,
  startFetchingForm,
  startFetchingGetTab,
  startFetchingMetaData,
  startInitiateOnboarding,
  startPostDataPoint,
  startPostingForm,
  startPostMetaData,
  successFetchingForm,
  successFetchingGetTab,
  successFetchingMetaData,
  successInitiateOnboarding,
  successPostDataPoint,
  successPostingForm,
  successPostMetaData,
} from "@/reducers/initiateOnboardingSlice";
import {
  generateCheckListAndOnboardingId,
  getAllTabsList,
  getCurrentTabFormData,
  getOpportunityMetadata,
  postCurrentTabFormChanges,
  postDataPointsData,
  postMetaDataChanges,
  processCurrentOnboarding,
} from "@/services/exp-api-service";
import { forEachField, forEachSection } from "@/utils/forms";

// initiateOnboarding API call - generates checklistId and OnBoardingId
export const initiateOnboardingAction = () => {
  return async (dispatch) => {
    dispatch(startInitiateOnboarding());
    try {
      const res = await generateCheckListAndOnboardingId();
      dispatch(successInitiateOnboarding(res));
      return res?.data?.checkList[0];
    } catch (error) {
      dispatch(failedInitiateOnboarding());
      throw error;
    }
  };
};

// Get ALL left hand Tabs API call
export const getAllTabs = (formName) => {
  return async (dispatch) => {
    dispatch(startFetchingGetTab());
    try {
      const res = await getAllTabsList(formName);
      dispatch(successFetchingGetTab(res));
    } catch (error) {
      dispatch(failedFetchingGetTab());
      throw error;
    }
  };
};

// Get Meta Data API Call - initial call will give 204
export const getMetaData = (onboardingId, checklistId, formName) => {
  return async (dispatch) => {
    dispatch(startFetchingMetaData());
    try {
      const res = await getOpportunityMetadata(onboardingId, checklistId, formName);
      dispatch(successFetchingMetaData(res));
      if (res.status === 204) {
        dispatch(getAllTabs(formName));
      }
    } catch (error) {
      dispatch(failedFetchingMetaData());
      throw error;
    }
  };
};

// Get form API using tabName
export const getForm = (onboardingId, checklistId, tabName, formName) => {
  return async (dispatch) => {
    dispatch(startFetchingForm());
    try {
      let res = await getCurrentTabFormData(onboardingId, checklistId, tabName, formName);
      const selectedProductsFromAPI =
        formName === INITIATE_ONBOARDING_FORM_NAME
          ? res.data.objValue.data.prepopulatedDataPoints?.["productDetails-productType"]?.value
          : res.data.objValue.data.prepopulatedDataPoints?.selectGroup?.value;
      if (selectedProductsFromAPI) {
        res = produce(res, (newRes) => {
          /* eslint-disable no-param-reassign */ // safe because of Immer
          forEachField(newRes.data, (field) => {
            if (Array.isArray(field.productTypeRequiredCheck)) {
              const requiredCheck = selectedProductsFromAPI.some((val) =>
                field.productTypeRequiredCheck.includes(val),
              );
              field.isRequired = requiredCheck;
            }
            if (Array.isArray(field.productTypeVisibilityCheck)) {
              const visibilityCheck = selectedProductsFromAPI.some((val) =>
                field.productTypeVisibilityCheck.includes(val),
              );
              field.isVisible = visibilityCheck;
            }
          });
          /* eslint-enable no-param-reassign */

          forEachSection(newRes.data, (section) => {
            if (Array.isArray(section.rowLists)) {
              // eslint-disable-next-line no-param-reassign
              section.hideSection = true;
              section.rowLists.forEach((row) => {
                if (Array.isArray(row.fieldLists)) {
                  row.fieldLists.forEach((val) => {
                    if (val.isVisible) {
                      // eslint-disable-next-line no-param-reassign
                      section.hideSection = false;
                    }
                  });
                }
              });
            }
          });
        });
      }

      if (tabName === "reviewandapprove") {
        const marketerComment = res.data.objValue.data.prepopulatedDataPoints?.comments;
        const marketerName =
          res.data.objValue.data.prepopulatedDataPoints?.["onboardingTeam-role1"]?.split("/")[0];
        if (marketerComment || marketerName) {
          res = produce(res, (newRes) => {
            /* eslint-disable no-param-reassign */ // safe because of Immer
            forEachField(newRes.data, (field) => {
              if (field.name === "commentsFromMarketer") {
                field.value = marketerComment;
              } else if (field.name === "nameOfMarketer") {
                field.value = `${marketerName} - Marketer`;
              }
            });
            /* eslint-enable no-param-reassign */
          });
        }
      }

      dispatch(successFetchingForm(res));
    } catch (error) {
      dispatch(failedFetchingForm());
      throw error;
    }
  };
};

// Post Form API Call
export const postForm = (formJSON, onboardingId, checklistId, tabName, formName) => {
  return async (dispatch) => {
    dispatch(startPostingForm());
    try {
      const res = await postCurrentTabFormChanges(
        formJSON,
        onboardingId,
        checklistId,
        tabName,
        formName,
      );
      dispatch(successPostingForm(res));
    } catch (error) {
      dispatch(failedPostingForm());
      throw error;
    }
  };
};

// Post metaData API call - free payload
export const postMetaData = (tabList, onboardingId, checklistId, formName) => {
  return async (dispatch, getState) => {
    // eslint-disable-next-line no-unsafe-optional-chaining
    const { given_name, family_name } = getState()?.oidc?.user?.profile;

    dispatch(startPostMetaData());
    try {
      const res = await postMetaDataChanges(
        tabList,
        onboardingId,
        checklistId,
        formName,
        given_name,
        family_name,
      );
      dispatch(successPostMetaData(res));
    } catch (error) {
      dispatch(failedPostMetaData());
      throw error;
    }
  };
};

// Post DataPoint API Call - audit trails, all datapoint values
export const postDataPoint = (dataPointRequestBody, onboardingId, checklistId) => {
  return async (dispatch) => {
    dispatch(startPostDataPoint());
    try {
      const res = await postDataPointsData(dataPointRequestBody, onboardingId, checklistId);
      dispatch(successPostDataPoint(res));
    } catch (error) {
      dispatch(failedPostDataPoint());
      throw error;
    }
  };
};

// On Click Save and Continue - series of calls
export const sectionContinue = (
  tabsUpdatedInfo,
  checklistId,
  onboardingId,
  formJSON,
  tabName,
  dataPointReq,
  isFinalSubmit,
  formName,
) => {
  return async (dispatch) => {
    Promise.all([
      dispatch(postForm(formJSON, onboardingId, checklistId, tabName, formName)),
      dispatch(postDataPoint(dataPointReq, onboardingId, checklistId)),
      dispatch(postMetaData(tabsUpdatedInfo, onboardingId, checklistId, formName)),
    ]);
  };
};

export const processOnboarding = (
  onboardingId,
  action,
  navigate,
  taskIdParam,
  clientLegalNameForMessage,
) => {
  return async (dispatch) => {
    dispatch(startPostingForm());
    const res = await processCurrentOnboarding(onboardingId, action, taskIdParam);
    if (res) {
      if (res.data === "Success") {
        dispatch(successPostingForm());
        const onboardingMessage = `Onboarding form has been successfully ${
          taskIdParam ? "approved" : "submitted"
        } for ${clientLegalNameForMessage}.`;
        navigate("/", { state: { showToast: true, message: onboardingMessage } });
      }
    }
  };
};
