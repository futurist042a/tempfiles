import { API_CALL_STATUS } from "@/constants/constant";
import {
  getCountriesFailed,
  getCountriesStarted,
  getCountriesSuccess,
  getStatesFailed,
  getStatesStarted,
  getStatesSuccess,
} from "@/reducers/dropdownsSlice";
import { getCountryList, getStateList } from "@/services/exp-api-service";

export function getCountries() {
  return async (dispatch, getState) => {
    const { status } = getState().dropdowns.countries;
    const alreadyFetched = status !== API_CALL_STATUS.PENDING;
    if (alreadyFetched) return;

    dispatch(getCountriesStarted());
    try {
      const response = await getCountryList();
      dispatch(
        getCountriesSuccess(
          response.data.map((country) => ({ ...country, content: country.value })),
        ),
      );
    } catch (error) {
      dispatch(getCountriesFailed());
      throw error;
    }
  };
}

export function getStates() {
  return async (dispatch, getState) => {
    const { status } = getState().dropdowns.states;
    const alreadyFetched = status !== API_CALL_STATUS.PENDING;
    if (alreadyFetched) return;

    dispatch(getStatesStarted());
    try {
      const response = await getStateList();
      dispatch(
        getStatesSuccess(response.data.map((state) => ({ ...state, content: state.value }))),
      );
    } catch (error) {
      dispatch(getStatesFailed());
      throw error;
    }
  };
}
