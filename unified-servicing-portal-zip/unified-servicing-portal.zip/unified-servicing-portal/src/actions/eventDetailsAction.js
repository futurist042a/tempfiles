import { API_TYPE_GRAPHQL } from "@/constants/constant";
import { EXP_API_GRAPHQL_URI, UAT_SEP_2023 } from "@/constants/env";
import { eventTasksQuery } from "@/queries/eventTasksQuery";
import {
  failedFetchingDetailTaskList,
  failedFetchingTasksTableMetadata,
  startFetchingDetailTaskList,
  startFetchingTasksTableMetadata,
  successFetchingDetailTaskList,
  successFetchingTasksTableMetadata,
  failedFetchingDetailHistoryList,
  failedFetchingHistoryTableMetadata,
  startFetchingDetailHistoryList,
  startFetchingHistoryTableMetadata,
  successFetchingDetailHistoryList,
  successFetchingHistoryTableMetadata,
} from "@/reducers/eventDetailsSlice";
import { selectUserRole } from "@/selectors/userSelectors";
import { callOnboardingApi } from "@/services/axios-service";
import { getTableMetadataByPageName, getHistoryTableData } from "@/services/exp-api-service";
import { getEnvValue } from "@/utils/environment";

export const getDetailTaskList = ({ onboardingId }) => {
  return async (dispatch) => {
    const uri = getEnvValue(EXP_API_GRAPHQL_URI);
    const query = eventTasksQuery({ onboardingId });
    dispatch(startFetchingDetailTaskList());
    try {
      const res = await callOnboardingApi({
        type: API_TYPE_GRAPHQL,
        body: { query },
        endpoint: uri,
      });
      let tasks = res.data.data.eventTasks || [];
      // Hide Initiate credit request task in UAT until Nov 2023 release
      if (getEnvValue(UAT_SEP_2023) === "true") {
        tasks = tasks.filter(({ taskName }) => taskName !== "Initiate credit request");
      }
      dispatch(successFetchingDetailTaskList(tasks));
    } catch (errors) {
      dispatch(failedFetchingDetailTaskList());
    }
  };
};

export const getTasksTableMetaData = () => {
  return async (dispatch, getState) => {
    const state = getState();
    const userRole = selectUserRole(state);
    dispatch(startFetchingTasksTableMetadata());
    try {
      const res = await getTableMetadataByPageName({ pageName: "Tasks", userRole });
      dispatch(successFetchingTasksTableMetadata(res.data.Tasks));
    } catch (error) {
      dispatch(failedFetchingTasksTableMetadata());
      throw error;
    }
  };
};

/// History Tab Actions
export const getHistoryTableMetaData = () => async (dispatch, getState) => {
  const state = getState();
  const userRole = selectUserRole(state);
  dispatch(startFetchingHistoryTableMetadata());
  try {
    const res = await getTableMetadataByPageName({ pageName: "History", userRole });
    dispatch(successFetchingHistoryTableMetadata(res.data.History));
  } catch (error) {
    dispatch(failedFetchingHistoryTableMetadata());
    throw error;
  }
};

export const getDetailHistoryList = ({ onboardingId }) => {
  return async (dispatch) => {
    dispatch(startFetchingDetailHistoryList());
    try {
      const res = await getHistoryTableData(onboardingId);
      dispatch(successFetchingDetailHistoryList(res));
    } catch (errors) {
      dispatch(failedFetchingDetailHistoryList());
    }
  };
};
