# unified-servicing-portal

## Setup

  1. Clone Repository
  2. open up the terminal within vsCode and run
    `npm i -f`
    If all of the packages install correctly move on to the next step. If not, you will need to get a username and password from [Jfrog Artifactory](https://artifactory.us.bank-dns.com/artifactory/webapp/#/home)and update the .npmrc file
  3. run
    `npm run dev`
    to start a local node server to run the application locally.
  4. You can accesses the page from [http://localhost:5031/usp/home](http://localhost:5031/usp/home)

<!-- - [Bootstrapping a new project](./docs/bootstrapping-a-new-project.md)
  1. [Request authentication URLs](./docs/bootstrapping-a-new-project.md#1-request-authentication-urls)
  2. [Enter credentials in .npmrc](./docs/initial-setup.md#2-enter-credentials-in-npmrc)
  3. [Change the HOME_PATH variable](./docs/bootstrapping-a-new-project.md#3-change-the-home_path-variable)
  4. [Find and replace "template"](./docs/bootstrapping-a-new-project.md#4-find-and-replace-template)
  5. [Choose a port number for development](./docs/bootstrapping-a-new-project.md#5-choose-a-port-number-for-development)
- [Tooling](./docs/tooling.md)
  - [Visual Studio Code Extensions](./docs/tooling.md#visual-studio-code-extensions)
  - [Browser Extensions](./docs/tooling.md#browser-extensions)
- [Maintenance](./docs/maintenance.md)
  - [Creating environment variables](./docs/maintenance.md#creating-environment-variables)
- [Development](./docs/development.md)
  - [Connecting to a new API endpoint](./docs/development.md#connecting-to-a-new-api-endpoint)
  - [Derived state using selectors](./docs/development.md#derived-state-using-selectors)
    - [Debugging selectors](./docs/development.md#debugging-selectors) -->
