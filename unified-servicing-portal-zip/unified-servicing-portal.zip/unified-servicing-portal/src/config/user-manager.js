import { createUserManager } from "redux-oidc";
import {
  AUTHORITY,
  AUTHORIZATION_ENDPOINT,
  CLIENT_ID,
  ISSUER,
  PROMPT_TYPE,
  RESPONSE_TYPE,
  SCOPE,
  TOKEN_ENDPOINT,
  USERINFO_ENDPOINT,
  HOME_PATH
} from "@/constants/env";
import { getEnvValue } from "@/utils/environment";

const userManagerConfig = {
  client_id: "onboardingplatform", //Now IBMBAW
  //client_id: "IBMBAW", //getEnvValue(CLIENT_ID),
  prompt: getEnvValue(PROMPT_TYPE),
  redirect_uri: `${window.location.origin}${process.env.env_path}/callback`,
  //redirect_uri: `${window.location.origin}/usp/home/callback`,
  response_type: "code",//getEnvValue(RESPONSE_TYPE),
  scope: getEnvValue(SCOPE),
  //authority: getEnvValue(AUTHORITY),
  authority:"https://it-federation.usbank.com",
  //silent_redirect_uri: `${window.location.origin}/usp/home/silent_renew`,
  silent_redirect_uri: `${window.location.origin}${process.env.env_path}/silent_renew`,
  automaticSilentRenew: true,
  filterProtocolClaims: true,
  loadUserInfo: true,
  extraQueryParams: { OAuthAuthn: "ADUS" },
  //client_secret: process.env.REACT_APP_CLIENT_SECRET,
  metadata: {
    //issuer: "https://it-federation.usbank.com",
    issuer: "https://it-federation.usbank.com/as",
    //manual endpoint
    //authorization_endpoint: "https://it-sso.us.bank-dns.com/as/authorization.oauth2",
    // token_endpoint: getEnvValue(TOKEN_ENDPOINT),
    // userinfo_endpoint: getEnvValue(USERINFO_ENDPOINT),
    authorization_endpoint: "https://it-federation.usbank.com/as/authorization.oauth2",
    token_endpoint: "https://it-federation.usbank.com/as/token.oauth2",
    userinfo_endpoint: "https://it-federation.usbank.com/idp/userinfo.openid",
  },
};

export const userManager = createUserManager(userManagerConfig);
