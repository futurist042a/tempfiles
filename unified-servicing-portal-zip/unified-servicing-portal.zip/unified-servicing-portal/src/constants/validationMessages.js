// error messages
export const pivotErrorMsg = "There was an error on our end.";
export const pivotErrorMsg1 = "Please try again later. If this problem persists,";
export const linkMsg = "log a Service Now incident.";
