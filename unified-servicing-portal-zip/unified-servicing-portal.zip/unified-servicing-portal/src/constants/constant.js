export const BUSINESS_LINE = "template";

export const API_TYPE_GRAPHQL = "GRAPHQL";

export const API_CALL_STATUS = {
  PENDING: "pending",
  STARTED: "started",
  SUCCESS: "success",
  FAILED: "failed",
};

// serviceNowURL
export const ServiceNowIncidentUrl =
  "https://itsmnow.service-now.com/usbportal?id=sc_cat_item&sys_id=8834b45d1b5689105d48646b234bcbd8&sysparm_category=fff93bbfdb369b408c910ef5b9961926";

/* cspell:ignore selectproduct cliententity */
export const INITIATE_ONBOARDING_REQUIRED_CARDS = [];
export const FORMS_REQUIRING_COUNTRIES = [];
export const FORMS_REQUIRING_STATES = [];
export const REVIEW_TAB_NAMES = ["reviewandsubmit", "reviewandapprove"];

export const INITIATE_ONBOARDING_FORM_NAME_FOR_API = "InitiateOnboardingTemplate";
export const INITIATE_ONBOARDING_FORM_NAME = "initiateOnboardingTemplate";

export const USER_ROLE = {
  // example:
  // CONTRACT_ANALYST: "MICL-CONTRACT-ANALYST",
  // MARKETER: "Marketer",
};

export const INITIATE_ONBOARDING = "initiate-onboarding";

export const FORM_HEADING = {
  initiateOnboardingTemplate: "Let's start the derivatives onboarding process",
};

export const FORM_INSTRUCTION = {
  initiateOnboardingTemplate:
    "Select or create your client, assign U.S. Bank roles, and answer the questions needed to drive our DocuSign packet and workflow.",
};
