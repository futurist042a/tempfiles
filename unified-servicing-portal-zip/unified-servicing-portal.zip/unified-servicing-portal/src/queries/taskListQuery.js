import { BUSINESS_LINE } from "@/constants/constant";

export const taskListQuery = (taskType, userRole) => {
  /**
   * GraphQL queries need a name so they can be intercepted by the mock server.
   * @see https://mswjs.io/docs/api/graphql/query#basic-query
   */
  return `
    query OnboardingTasks {
      eventsFromDB(onboardingType: "${BUSINESS_LINE}", taskType: "${taskType}", userRole:"${userRole}") {
        onboardingId
        checklistId
        createOpportunityId
        clientLegalName
        taxId
        product
        marketerName
        negotiator
        rm
        lastUpdate
        task
        taskId
        accountType
        greenLightStatus {
          current
          total
        }
        headersData {
          headerName
          headerValue
        }
      }
    }`;
};

