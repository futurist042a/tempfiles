import { BUSINESS_LINE } from "@/constants/constant";

/**
 * GraphQL queries need a name so they can be intercepted by the mock server.
 * @see https://mswjs.io/docs/api/graphql/query#basic-query
 */
export const eventTasksQuery = ({ onboardingId }) => `
  query EventTasks {
    eventTasks(onboardingType: "${BUSINESS_LINE}", onboardingId: "${onboardingId}") {
      assignedTo
      lastUpdated
      status
      taskName
      updatedBy
      checklistId
      onboardingId
      formName
    }
  }
`;
