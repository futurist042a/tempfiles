import { BUSINESS_LINE } from "@/constants/constant";

export const webKycQuery = (searchValue) => `
query {
  webKycParty(searchValue: "${searchValue}", searchType: "entityName", onboardingType: "${BUSINESS_LINE}") {
    entityName
    entitytin
    source
    customerType
  }
}`;
