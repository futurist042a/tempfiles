import { BUSINESS_LINE } from "@/constants/constant";

//Common Object
export function GraphQLTaskListQuery(businessLine) {
  return `
    query {
            commonOnBoardingEvent(onboardingType: "${businessLine}" ,onboardingId:"")
                   {
                        clientDetails{
                            onboardingId
                            legalName
                            EIN
                            LEI
                            LPID
                            additionalDetails{
                                countryOfFormation
                                countryOfPrimaryBusinessOperations
                                estimatedOrProjectedAnnualRevenue
                                hasAnyDBA
                                legalStructure
                                naicsCode
                                purposeOfAccount
                                offerCheckCashingServices
                            }
                        }
                        accountDetails{
                            accountNumber
                            accountName
                            accountType
                        }
                        onboardingTeam{
                            relationshipManager
                            role1
                        }
                        processDetails{
                            instanceId
                            mileStoneTracker{
                                mileStoneName
                                status
                            }
                            taskDetails{
                                taskId
                                taskName
                                taskURL
                                status
                                modifiedBy
                            }
                        }
                        productDetails{
                            productName
                            productType
                            productFamily
                        }
                    }
                }`;
  // export function GraphQLTaskListQuery(businessLine) {
  //   return `
  //     query {
  //             commonOnBoardingEvent(onboardingType: "${businessLine}", onboardingId:"", startDate:"2022-11-25", endDate:"2024-11-30",limit:"100",pageNum:"")
  //                    {
  //                         clientDetails{
  //                             onboardingId
  //                             legalName
  //                             EIN
  //                             LEI
  //                             LPID
  //                             additionalDetails{
  //                                 countryOfFormation
  //                                 countryOfPrimaryBusinessOperations
  //                                 estimatedOrProjectedAnnualRevenue
  //                                 hasAnyDBA
  //                                 legalStructure
  //                                 naicsCode
  //                                 purposeOfAccount
  //                                 offerCheckCashingServices
  //                             }
  //                         }
  //                         accountDetails{
  //                             accountNumber
  //                             accountName
  //                             accountType
  //                         }
  //                         onboardingTeam{
  //                             relationshipManager
  //                             role1
  //                         }
  //                         processDetails{
  //                             instanceId
  //                             mileStoneTracker{
  //                                 mileStoneName
  //                                 status
  //                             }
  //                             taskDetails{
  //                                 taskId
  //                                 taskName
  //                             }
  //                         }
  //                         productDetails{
  //                             productName
  //                             productType
  //                             productFamily
  //                         }
  //                     }
  //                 }`;
}
