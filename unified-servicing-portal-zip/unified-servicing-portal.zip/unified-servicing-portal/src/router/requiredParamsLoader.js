import { redirect } from "react-router";

/**
 * Used as the loader parameter of a route, redirects to the error page when
 * required parameters are missing.
 *
 * @example
 * {
 *   path: "initiate-onboarding",
 *   element: <OnboardingHome />,
 *   loader: requiredParamsLoader('onboardingId', 'checklistId'),
 * }
 *
 * @param  {...string} requiredParamNames
 * @returns {import('react-router').LoaderFunction}
 */
export function requiredParamsLoader(...requiredParamNames) {
  return ({ request: { url } }) => {
    const searchParams = new URL(url).searchParams;
    for (const paramName of requiredParamNames) {
      if (!searchParams.get(paramName)) {
        return redirect("/error");
      }
    }
    /**
     * Loaders and actions can return anything except `undefined` (`Response`
     * objects are preferred, but `null` is a valid return value if there is
     * no data to return).
     */
    return null;
  };
}
