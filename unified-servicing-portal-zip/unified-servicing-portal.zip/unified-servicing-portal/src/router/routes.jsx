import { Navigate, Outlet } from "react-router-dom";
import CallbackPage from "@/components/auth/CallbackPage";
import SilentRenew from "@/components/auth/SilentRenew";
import Dashboard from "@/components/dashboard/Dashboard";
import ErrorBoundary from "@/components/error/ErrorBoundary";
import ErrorPage from "@/components/error/ErrorPage";
import EventDetails from "@/components/event-details/EventDetails";
import OnboardingHome from "@/components/form-page/OnboardingHome";
import HomePage from "@/components/home/HomePage";
import InvalidSession from "@/components/invalid-session/InvalidSession";
import UnauthorizedUser from "@/components/unauthorized-user/UnauthorizedUser";
import { INITIATE_ONBOARDING } from "@/constants/constant";
import { requiredParamsLoader } from "./requiredParamsLoader";
import {HOME_PATH} from "@/constants/env.js"
import TemplateDashboard from "@/components/templateDashboard";

/** @type {import('react-router-dom').RouteObject[]} */
export const routes = [
  {
    //path: "HOME_PATH",
    path: "/",
    element: <HomePage />,
    ErrorBoundary,
    children: [
      {
        index: true,
        element: <Dashboard />,
      },
      // {
      //   path: INITIATE_ONBOARDING,
      //   element: <OnboardingHome />,
      //   loader: requiredParamsLoader("onboardingId", "checklistId"),
      // },
      // {
      //   path: "event-details",
      //   element: <EventDetails />,
      //   loader: requiredParamsLoader("onboardingId", "checklistId"),
      // },
      {
        path: "unauthorized-user",
        element: <UnauthorizedUser />,
      },
    ],
  },
  {
    path: "/callback",
    element: <CallbackPage />,
  },
  {
    path: "/silent_renew",
    element: <SilentRenew />,
  },
  {
    path: "/invalid-session",
    element: <InvalidSession />,
  },
  {
    path: "/error",
    element: <ErrorPage />,
  },
  {
    path: "/template",
    element: <TemplateDashboard />,
  },
  {
    path: "*",
    element: <Navigate to="/error" />,
   },
];
