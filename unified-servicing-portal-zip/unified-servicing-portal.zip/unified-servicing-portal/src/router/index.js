import { createBrowserRouter, createMemoryRouter } from "react-router-dom";
import { HOME_PATH } from "@/constants/env";
import { getEnvValue } from "@/utils/environment";
import { routes } from "./routes";

/**
 * @typedef {F extends (...args: infer A) => any ? A : never} ArgumentTypes
 * @template F
 */

/** @type {ArgumentTypes<typeof createBrowserRouter>[1]} */
const routerOptions = {
  basename: process.env.env_path, //getEnvValue(HOME_PATH),
};

export const router = (process.env.NODE_ENV === "test" ? createMemoryRouter : createBrowserRouter)(
  routes,
  routerOptions,
);
