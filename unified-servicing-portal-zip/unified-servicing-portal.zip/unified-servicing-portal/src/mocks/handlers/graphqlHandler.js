// eslint-disable-next-line import/no-extraneous-dependencies
import { graphql } from "msw";
import { EXP_API_HOST } from "@/constants/env";
import { getEnvValue } from "@/utils/environment";

const graphqlEndpoint = `${getEnvValue(EXP_API_HOST)}graphql`;
export const graphqlHandler = graphql.link(graphqlEndpoint);
