/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import { rest } from "msw";
import { TABLE_META_DATA, USER_ROLE_LIST } from "@/constants/env";
import { getEndpointUrl } from "@/utils/environment";
import { graphqlHandler } from "./graphqlHandler";

export const dashboardHandlers = [
  rest.get(getEndpointUrl(USER_ROLE_LIST), async (req, res, ctx) => {
    const response = require("../../stubs/user-details.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(TABLE_META_DATA), async (req, res, ctx) => {
    const pageName = req.url.searchParams.get("pageName");
    switch (pageName) {
      case "dashboard": {
        const response = require("../../stubs/table-metadata.json");
        return res(ctx.json(response));
      }
      case "Tasks": {
        const response = require("../../stubs/tasks-table-metadata.json");
        return res(ctx.json(response));
      }
      case "History": {
        const response = require("../../stubs/history-metadata.json");
        return res(ctx.json(response));
      }
      default: {
        /**
         * When pageName is not found, the server defaults to an empty array.
         */
        return res(
          ctx.json({
            [req.params.pageName]: [],
          }),
        );
      }
    }
  }),

  graphqlHandler.query("OnboardingTasks", (req, res, ctx) => {
    const response = require("../../stubs/onboarding-tasks.json");
    return res(ctx.data(response));
  }),
];
