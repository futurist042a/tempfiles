/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import { rest } from "msw";
import {
  COUNTRY_LIST_ENDPOINT,
  COMMON_ENDPOINT,
  INITIATE_ONBOARDING,
  INITIATE_ONBOARDING_TABS_METADATA,
  POST_DATA_POINT,
  STATE_LIST_ENDPOINT,
  SUBMIT_ONBOARDING,
  FETCH_USER_LIST_ENDPOINT,
} from "@/constants/env";
import { getEndpointUrl } from "@/utils/environment";

export const initiateOnboardingHandlers = [
  rest.get(getEndpointUrl(INITIATE_ONBOARDING_TABS_METADATA), async (req, res, ctx) => {
    const response = require("../../stubs/form-metadata.json");
    return res(ctx.json(response));
  }),

  rest.post(getEndpointUrl(INITIATE_ONBOARDING_TABS_METADATA), async (req, res, ctx) => {
    const response = require("../../stubs/form-metadata.json");
    return res(
      ctx.json({
        ...response,
        tabList: req.body.tabList,
      }),
    );
  }),

  rest.post(getEndpointUrl(INITIATE_ONBOARDING), async (req, res, ctx) => {
    const response = require("../../stubs/initiate-onboarding.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(COMMON_ENDPOINT), async (req, res, ctx) => {
    const response = require("../../stubs/onboarding-forms/all-tabs.json");
    return res(ctx.json(response));
  }),

  rest.post(getEndpointUrl(POST_DATA_POINT), async (req, res, ctx) => {
    return res(ctx.text("success"));
  }),

  rest.post(getEndpointUrl(SUBMIT_ONBOARDING), async (req, res, ctx) => {
    return res(ctx.data("Success"));
  }),

  rest.get(getEndpointUrl(COUNTRY_LIST_ENDPOINT), async (req, res, ctx) => {
    const response = require("../../stubs/country-list.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(STATE_LIST_ENDPOINT), async (req, res, ctx) => {
    const response = require("../../stubs/state-list.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(FETCH_USER_LIST_ENDPOINT), async (req, res, ctx) => {
    const response = require("../../stubs/user-list.json");
    return res(ctx.json(response));
  }),
];
