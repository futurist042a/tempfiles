/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import { dashboardHandlers } from "./dashboardHandlers";
import { eventDetailHandlers } from "./eventDetailHandlers";
import { formHandlers } from "./formHandlers";
import { initiateOnboardingHandlers } from "./initiateOnboardingHandlers";
import { openIdHandlers } from "./openIdHandlers";

/**
 * These handlers are used by the mock server to send hardcoded JSON to the
 * browser (or test suite) instead of calling the actual endpoints.
 */
export const handlers = [
  ...dashboardHandlers,
  ...eventDetailHandlers,
  ...formHandlers,
  ...initiateOnboardingHandlers,
  ...openIdHandlers,
];
