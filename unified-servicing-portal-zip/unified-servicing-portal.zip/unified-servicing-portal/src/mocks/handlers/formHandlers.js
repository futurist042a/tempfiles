/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import { rest } from "msw";
import { INITIATE_ONBOARDING_FORM_NAME } from "@/constants/constant";
import { COMMON_ENDPOINT } from "@/constants/env";
import { getEndpointUrl } from "@/utils/environment";

const commonEndpoint = getEndpointUrl(COMMON_ENDPOINT);

export const formHandlers = [
  rest.get(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/selectproduct`,
    async (req, res, ctx) => {
      const response = require("../../stubs/onboarding-forms/select-product.json");
      return res(ctx.json({ objValue: response }));
    },
  ),

  rest.post(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/selectproduct`,
    async (req, res, ctx) => {
      return res(ctx.text("success"));
    },
  ),

  rest.get(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/cliententity`,
    async (req, res, ctx) => {
      const response = require("../../stubs/onboarding-forms/client-entity.json");
      return res(ctx.json({ objValue: response }));
    },
  ),

  rest.post(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/cliententity`,
    async (req, res, ctx) => {
      return res(ctx.text("success"));
    },
  ),

  rest.get(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/derivativesquestionnaire`,
    async (req, res, ctx) => {
      const response = require("../../stubs/onboarding-forms/derivatives-questionnaire.json");
      return res(ctx.json({ objValue: response }));
    },
  ),

  rest.post(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/derivativesquestionnaire`,
    async (req, res, ctx) => {
      return res(ctx.text("success"));
    },
  ),

  rest.get(`${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/drf`, async (req, res, ctx) => {
    const response = require("../../stubs/onboarding-forms/drf-form.json");
    return res(ctx.json({ objValue: response }));
  }),

  rest.post(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/drf`,
    async (req, res, ctx) => {
      return res(ctx.text("success"));
    },
  ),

  rest.get(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/reviewandsubmit`,
    async (req, res, ctx) => {
      const response = require("../../stubs/onboarding-forms/review-and-submit.json");
      return res(ctx.json({ objValue: response }));
    },
  ),

  rest.post(
    `${commonEndpoint}/${INITIATE_ONBOARDING_FORM_NAME}/tabs/reviewandsubmit`,
    async (req, res, ctx) => {
      return res(ctx.text("success"));
    },
  ),
];
