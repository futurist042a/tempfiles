/* eslint-disable global-require */
// eslint-disable-next-line import/no-extraneous-dependencies
import { rest } from "msw";
import {
  FETCH_HISTORY_TABLE_ENDPOINT,
  HEADER_EVENT_DETAILS_ENDPOINT,
  TABLE_META_DATA,
} from "@/constants/env";
import { getEndpointUrl } from "@/utils/environment";
import { graphqlHandler } from "./graphqlHandler";

export const eventDetailHandlers = [
  rest.get(getEndpointUrl(HEADER_EVENT_DETAILS_ENDPOINT), (req, res, ctx) => {
    const response = require("../../stubs/details.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(FETCH_HISTORY_TABLE_ENDPOINT), (req, res, ctx) => {
    const response = require("../../stubs/audit-trail.json");
    return res(ctx.json(response));
  }),

  rest.get(getEndpointUrl(TABLE_META_DATA), (req, res, ctx) => {
    const response = require("../../stubs/audit-trail.json");
    return res(ctx.json(response));
  }),

  graphqlHandler.query("EventTasks", (req, res, ctx) => {
    const response = require("../../stubs/tasks-table-content-CA.json");
    return res(ctx.data(response));
  }),
];
