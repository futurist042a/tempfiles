/* eslint-disable global-require */
/* eslint-disable import/no-extraneous-dependencies */
import { rest } from "msw";
import { TOKEN_ENDPOINT, USERINFO_ENDPOINT } from "@/constants/env";
import { getEnvValue } from "@/utils/environment";

export const openIdHandlers = [
  rest.post(`${getEnvValue(TOKEN_ENDPOINT)}`, (req, res, ctx) => {
    const response = require("../../stubs/token-oauth2.json");
    return res(ctx.json(response));
  }),

  rest.get(`${getEnvValue(USERINFO_ENDPOINT)}`, (req, res, ctx) => {
    const response = require("../../stubs/userinfo-openid.json");
    return res(ctx.json(response));
  }),
];
