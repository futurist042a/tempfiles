import React from "react";
import { Provider } from "react-redux";
import { RouterProvider } from "react-router-dom";
import { OidcProvider } from "redux-oidc";
import { userManager } from "./config/user-manager";
import { router } from "./router";
import store from "./store/store";

function Entry() {
  console.log(process.env.env_path)
  return (
    <React.Suspense fallback="Loading">
      <Provider store={store}>
        <OidcProvider store={store} userManager={userManager}>
          <RouterProvider router={router} />
        </OidcProvider>
      </Provider>
    </React.Suspense>
  );
}

export default Entry;
