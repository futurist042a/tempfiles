export function formatDateLongNumeric(dateOrString) {
  return Intl.DateTimeFormat("en-US", { month: "2-digit", day: "2-digit", year: "numeric" }).format(
    typeof dateOrString === "string" ? new Date(dateOrString) : dateOrString,
  );
}

export function formatDateTimeNumeric(dateOrString) {
  return Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  }).format(typeof dateOrString === "string" ? new Date(dateOrString) : dateOrString);
}

export function formatDateTime(dateOrString) {
  return Intl.DateTimeFormat("en-US", {
    month: "2-digit",
    day: "2-digit",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  }).format(typeof dateOrString === "string" ? new Date(dateOrString) : dateOrString);
}
