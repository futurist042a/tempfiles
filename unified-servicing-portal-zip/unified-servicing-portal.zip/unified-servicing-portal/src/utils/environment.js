import { EXP_API_HOST, HOME_PATH } from "@/constants/env";
import localEnv from "../../public/env.json";

export const getEnvValue = (key) => {
  const isDevelopment = process.env.NODE_ENV === "development";
    //window.location.hostname === "localhost" && process.env.NODE_ENV === "development";
  const isTest = process.env.NODE_ENV === "test";
  if (isDevelopment || isTest) {
    return localEnv[key];
  }
  if (window.location.hostname.includes("usbank.com")) {
    return window[`REACT_APP_${key}_EXT`] || window[`REACT_APP_${key}`];
  }

  return window[`REACT_APP_${key}`];
};

export const getAppendedEnvVariable = (envKey, appendedUrl) => {
  return `${getEnvValue(envKey)}${appendedUrl}`;
};

export const getEndpointUrl = (urlKey) => {
  return `${getEnvValue(EXP_API_HOST)}${getEnvValue(urlKey)}`;
};

export function routePath(path = "") {
  return getAppendedEnvVariable(HOME_PATH, path);
}
