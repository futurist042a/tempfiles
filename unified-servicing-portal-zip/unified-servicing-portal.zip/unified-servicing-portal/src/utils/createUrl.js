/**
 * Concatenates a path with an object representing the search params to be added.
 *
 * @param {string} path The content before the question mark in the URL.
 * @param {Record<string, string | number>} [params] An object with search params added to it.
 * @returns {string} A string made of the path plus search params
 */
export function createUrl(path, params) {
  if (!params || Object.keys(params).length === 0) return path;
  const searchParams = new URLSearchParams(params);
  return `${path}?${searchParams.toString()}`;
}
