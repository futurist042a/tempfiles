import { isEmpty } from "lodash";

//The fields coming form the api are not formatted correctly so we need to
export function tableMetaDataToColumnData(metaData) {
  let columnData = [];
  const ignoreCols = ["Custom Subrow"];
  if (!isEmpty(metaData)) {
    columnData = metaData
      .map((col) => {
        return { ...col, accessor: col.fieldFor, type: "string", header: col.headerName };
      })
      .filter((col) => {
        //console.log(`colHeader: ${col.header}`)
        return !ignoreCols.includes(col.headerName);
      });
  }
  return columnData;
}
