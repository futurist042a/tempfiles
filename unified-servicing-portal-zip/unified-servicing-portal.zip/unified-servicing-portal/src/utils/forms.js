import {
  INITIATE_ONBOARDING_FORM_NAME,
  INITIATE_ONBOARDING_REQUIRED_CARDS,
} from "@/constants/constant";

export const formChangeUpdatedTabList = (
  tabList,
  activeTabIndex,
  onTabChangeId,
  statusFlag,
  completedFlag,
  isTabClicked,
) => {
  const visibleTabs = tabList.filter((tab) => tab.isVisible);
  const activeTab = visibleTabs[activeTabIndex];
  const nextTabIndex = isTabClicked ? onTabChangeId : visibleTabs.indexOf(activeTab) + 1;

  return tabList.map((tab) => {
    const newTab = { ...tab, selectedTab: visibleTabs.indexOf(tab) === nextTabIndex };
    if (tab === activeTab) {
      newTab.status = statusFlag;
      newTab.completed = completedFlag;
    }
    return newTab;
  });
};

export const enablingTabs = (tabList, formName) => {
  if (formName === INITIATE_ONBOARDING_FORM_NAME) {
    const allRequiredTabsCompleted = INITIATE_ONBOARDING_REQUIRED_CARDS.every((requiredTabName) => {
      const requiredTab = tabList.find((tab) => tab.value === requiredTabName);
      return requiredTab.completed;
    });

    if (allRequiredTabsCompleted) {
      return tabList.map((tab) => ({ ...tab, isDisabled: !tab.isVisible }));
    }
  }

  return tabList;
};

export function forEachSection(form, callback) {
  ((form.objValue ?? form)?.data?.sectionList || []).forEach(callback);
}

export function forEachRow(form, callback) {
  forEachSection(form, (section) => {
    (section?.rowLists || []).forEach(callback);
  });
}

export function forEachField(form, callback) {
  forEachRow(form, (row) => {
    (row?.fieldLists || []).forEach(callback);
  });
}

export function forEachRowOfSection(section, callback) {
  (section?.rowLists || []).forEach(callback);
}
