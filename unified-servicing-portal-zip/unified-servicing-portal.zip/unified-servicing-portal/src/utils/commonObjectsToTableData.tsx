import { isEmpty } from "lodash";
import { GreenLightStatus } from "@/components/dashboard/GreenLightStatus";
//import { CUSTOM_SUB_ROW_HEADER } from "@/constants/env.js"; //? This does not work for typescript?

const CUSTOM_SUB_ROW_HEADER = "Custom Subrow"
/**The common objects are coming in as a large object,
 * other stitching layers use a GraphQL endpoint to get a 'flat' object.
 * Another approach would be to take the common object and recursively take out all the fields
 * and label them like how they are in the uo_data_point table
 * */
//TODO customSubrow should have the field that it wants to pull from
export function commonObjectsToTableData(metaData, commonObjects) {
  //If the array of headers or the list of common objects is empty, do nothing
  if (isEmpty(metaData) || isEmpty(commonObjects)) {
    return;
  }

  const subrowAccessor = metaData.find((headerData) => {
    return headerData.headerName === CUSTOM_SUB_ROW_HEADER;
  })?.fieldFor;
  //Loop through the data and each table header to create objects that are useable for the table
  const tableData = commonObjects.map((commonObj) => {
    const rowObj = {tasks: commonObj.processDetails.taskDetails};
    //? rowObj = {headerName:value ,headerName1: value1}
    //for each header(column), find data to fit into it
    metaData.forEach((headerData) => {
      const accessor = headerData.fieldFor ?? headerData.accessor;
      rowObj[headerData.headerName === CUSTOM_SUB_ROW_HEADER ? "customSubRow" : accessor] =
        getFieldFromCommonObject(headerData, commonObj, subrowAccessor);
    });

    return rowObj;
  });
  //console.log(tableData);
  return tableData;
}

//TODO I do not like this, this should be done by the back end
function getFieldFromCommonObject(headerData, commonObject, subrowAccessor) {
  //Check to see if  the header has everything we need
  const headerName = headerData.headerName;
  const headerAccessor = headerData.fieldFor ?? headerData.accessor;
  if (!headerName || !headerAccessor) return;

  let subRows: [{ headerName: string; headerValue: string }];
  //console.log((`custom Sub row: ${typeof CUSTOM_SUB_ROW_HEADER}`))
  //console.log((`headerName: ${headerName}`))
  if ((headerName === "Status" || headerName === CUSTOM_SUB_ROW_HEADER )&&commonObject&&subrowAccessor) {
    subRows = getValueByKey(subrowAccessor, commonObject).map(objToSubRowObject);
  }
  switch (headerName) {
    case "Status":
      if(!subRows)return;
      return (
        <GreenLightStatus
          current={
            subRows.filter((subRow) => {
              const lowerCase = subRow?.headerValue.toLowerCase();
              return ["completed", "Approved","completed on"].includes(lowerCase);
            }).length
          }
          total={subRows.length}
        />
      );
    case "Custom Subrow":
      return subRows;

    default:
      return getValueByKey(headerAccessor, commonObject);
  }
}

function getValueByKey(key: string, obj: any) {
  if (!key || !obj) return "";
  const keys = key.split("-"); //Split the key into parts
  let value = obj;
  for (const k of keys) {
    if (value && typeof value === "object" && k in value) {
      value = value[k]; //Access the nested property
    } else {
      return undefined; //Return undefined if the key is not found
    }
  }
  return value;
}

function objToSubRowObject(subRowObject): { headerName: string; headerValue: string } {
  //! This breaks if we dont pass an object with the correct structure of {header:"string", value:"string"}
  const keys = Object.keys(subRowObject);
  const header = subRowObject[keys[0]];
  const value = subRowObject[keys[1]];
  if (!header || !value) return;
  return { headerName: header, headerValue: value };
}
