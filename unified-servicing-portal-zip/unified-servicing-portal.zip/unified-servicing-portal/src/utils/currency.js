export function convertCurrencyToNumber(number) {
  return Number(number.replace("$", "").replace(",", ""));
}

export function convertNumberToCurrency(number) {
  return number.toLocaleString("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}
