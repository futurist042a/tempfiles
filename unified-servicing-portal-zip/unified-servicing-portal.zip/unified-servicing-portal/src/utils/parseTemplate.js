/**
 * Replaces substrings enclosed in curly braces with equivalent properties found in an object.
 *
 * @example
 * const template = "Hello, {firstName} {lastName}!";
 * const user = { firstName: "Mary", lastName: "Lou" };
 * parseTemplate(template, user); // "Hello, Mary Lou!"
 *
 * @param {string} template A string containing object properties enclosed in curly braces.
 * @param {*} obj An object with which to interpolate the template string.
 * @returns {string} The string interpolated with values from the object.
 */
export function parseTemplate(template, obj) {
  const matches = template.match(/{[\w$]+}/g);
  let result = template;
  if (Array.isArray(matches)) {
    const properties = matches.map((x) => x.replace(/{|}/g, ""));
    for (let i = 0; i < matches.length; i++) {
      if (obj[properties[i]]) {
        result = result.replace(matches[i], obj[properties[i]]);
      }
    }
  }
  return result;
}
