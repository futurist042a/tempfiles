import * as dashboardTableSelectors from "@/selectors/dashboardTableSelectors";
import * as dropdownsSelectors from "@/selectors/dropdownsSelectors";
import * as initiateOnboardingSelectors from "@/selectors/initiateOnboardingSelectors";
import * as userSelectors from "@/selectors/oidcSelectors";
import store from "@/store/store";

export const initSelectorDebugger = () => {
  const allSelectors = {
    ...dashboardTableSelectors,
    ...dropdownsSelectors,
    ...initiateOnboardingSelectors,
    ...userSelectors,
  };

  /**
   * Debug tool for logging the state of all current selectors.
   */
  window.debugSelectors = function debugSelectors() {
    const state = store.getState();
    return Object.entries(allSelectors).reduce((obj, [name, selector]) => {
      return { ...obj, [name]: selector(state) };
    }, {});
  };
};
