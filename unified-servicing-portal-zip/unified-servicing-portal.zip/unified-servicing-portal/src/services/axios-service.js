import axios from "axios";
import { v4 as uuidv4 } from "uuid";
import { API_TYPE_GRAPHQL } from "@/constants/constant";
import { FILE_OPERATIONS_API_BASE_URL, EXP_API_HOST } from "@/constants/env";
import { router } from "@/router";
import store from "@/store/store";
import { getEnvValue } from "@/utils/environment";

const instance = axios.create({
  baseURL: getEnvValue(EXP_API_HOST),
});

instance.interceptors.response.use(
  /**
   * GraphQL calls always return a 200, so Axios won't reject on a failed request.
   * This interceptor handles responses containing errors, rejecting the promise.
   */
  function handleGraphQLResponse(response) {
    // check if the request URL ends in "/graphql"
    const isGraphQL = /\/graphql$/.test(response.config.url);
    if (isGraphQL && response?.data.errors) {
      router.navigate("/error");
      return Promise.reject(response.data.errors);
    }
    return response;
  },
  function handleOtherErrors(error) {
    router.navigate("/error");
    return Promise.reject(error);
  },
);

const getDefaultHeaders = () => {
  const state = store.getState();
  //console.log(`Bearer ${state.oidc?.user?.access_token}`)
  return {
    "Content-Type": "application/json",
    /** @type {string} */
    "Correlation-ID": uuidv4(),
    Authorization: `Bearer ${state.oidc?.user?.access_token}`,
  };
};

/**
 * @param {{ uri: string, headers: Record<string, string>, options: import('axios').AxiosRequestConfig }} params
 */
async function get({ uri, headers, options }) {
  const state = store.getState();
  const config = {
    headers: Object.assign(getDefaultHeaders(), headers),
    ...options,
  };
  if (state.oidc?.user?.access_token) {
    return instance.get(uri, config);
  }
  throw new Error("No access token.");
}

async function post({ url, body, headers, onUploadProgress, cancelToken }) {
  const state = store.getState();

  let options = {
    headers: { ...getDefaultHeaders(), ...headers },
  };

  if (typeof cancelToken === "object") {
    options = {
      ...options,
      cancelToken: cancelToken.token,
    };
  }

  if (typeof onUploadProgress === "function") {
    options = {
      ...options,
      onUploadProgress,
    };
  }



  if (state.oidc?.user?.access_token) {
    console.log(state)
     console.log(url)
     console.log(body)
     console.log(options)
    return instance.post(url, body, options);
  }
  throw new Error("No access token.");
}

/**
 * @template T
 * @param {{
 *   url: string,
 *   type: string,
 *   endpoint: string,
 *   body: any,
 *   headers: Record<string, string>,
 *   method: "get" | "post",
 *   isDocument: boolean,
 *   onUploadProgress: any,
 *   cancelToken: any,
 *   options: import('axios').AxiosRequestConfig
 * }} params
 * @returns {import('axios').AxiosResponse<T>}
 */
export const callOnboardingApi = async ({
  url,
  type,
  endpoint,
  body,
  headers,
  method,
  isDocument,
  onUploadProgress = "",
  cancelToken = "",
  options,
}) => {

  let uri = "";

  let ret;

  if (type === API_TYPE_GRAPHQL) {
    uri = `${endpoint}`;
  }

  if (method === "get") {
    uri = isDocument
      ? getEnvValue(FILE_OPERATIONS_API_BASE_URL) + url
      : getEnvValue(EXP_API_HOST) + url;

    ret = await get({ uri, headers, options });
  } else {
    if (type !== API_TYPE_GRAPHQL) {
      uri = isDocument
        ? getEnvValue(FILE_OPERATIONS_API_BASE_URL) + url
        : getEnvValue(EXP_API_HOST) + url;
    }
    console.log(`url: ${uri}`)
    ret = await post({ url: uri, body, headers, post: "post", onUploadProgress, cancelToken });
  }

  return ret;
};
