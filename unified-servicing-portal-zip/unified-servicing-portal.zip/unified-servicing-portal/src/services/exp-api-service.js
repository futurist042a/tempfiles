import {
  API_TYPE_GRAPHQL,
  BUSINESS_LINE,
  INITIATE_ONBOARDING_FORM_NAME_FOR_API,
} from "@/constants/constant";
import {
  COUNTRY_LIST_ENDPOINT,
  COMMON_ENDPOINT,
  EXP_API_GRAPHQL_URI,
  HEADER_EVENT_DETAILS_ENDPOINT,
  INITIATE_ONBOARDING,
  POST_DATA_POINT,
  STATE_LIST_ENDPOINT,
  SUBMIT_ONBOARDING,
  TABLE_META_DATA,
  USER_ROLE_LIST,
  FETCH_HISTORY_TABLE_ENDPOINT,
  REST_COMMON_OBJECT,
} from "@/constants/env";
import { GraphQLTaskListQuery } from "@/queries/personalTrustTaskListQuery";
import { taskListQuery } from "@/queries/taskListQuery";
import { webKycQuery } from "@/queries/webKyc";
import { createUrl } from "@/utils/createUrl";
import { getAppendedEnvVariable, getEnvValue } from "@/utils/environment";
import { callOnboardingApi } from "./axios-service";

export async function getStateList() {
  return callOnboardingApi({
    url: getEnvValue(STATE_LIST_ENDPOINT),
    method: "get",
  });
}

export async function getCountryList() {
  return callOnboardingApi({
    url: getEnvValue(COUNTRY_LIST_ENDPOINT),
    method: "get",
  });
}

export const getTableMetadataByPageName = ({ pageName, userRole }) => {
  return callOnboardingApi({
    url: getEnvValue(TABLE_META_DATA),
    method: "get",
    options: {
      params: {
        //! This is grabbing from the refs table
        onboardingType: "unifiedServicingPortal", //"personalTrust",
        pageName: "DashBoard",
        userRole: " ",
        typename: "TableHeader",
      },
    },
  });
};

export async function generateCheckListAndOnboardingId() {
  const appendedUrl = `?businessLine=${BUSINESS_LINE}&formName=${INITIATE_ONBOARDING_FORM_NAME_FOR_API}`;
  const uri = getAppendedEnvVariable(INITIATE_ONBOARDING, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "post",
  });
}

export async function getAllTabsList(formName) {
  const url = createUrl(getAppendedEnvVariable(COMMON_ENDPOINT, `/${formName}/tabs`), {
    tabName: "All",
    businessLine: BUSINESS_LINE,
  });
  return callOnboardingApi({
    url,
    method: "get",
  });
}

export async function getOpportunityMetadata(onboardingId, checklistId, formName) {
  const url = createUrl(getAppendedEnvVariable(COMMON_ENDPOINT, `/${formName}/metadata`), {
    checklistId,
    businessLine: BUSINESS_LINE,
    fundId: "",
    advisorId: "",
    classId: "",
  });
  return callOnboardingApi({
    url,
    method: "get",
    headers: {
      "Onboarding-ID": onboardingId,
    },
  });
}

export async function getCurrentTabFormData(onboardingId, checklistId, tabName, formName) {
  const url = createUrl(getAppendedEnvVariable(COMMON_ENDPOINT, `/${formName}/tabs/${tabName}`), {
    checklistId,
    businessLine: BUSINESS_LINE,
    fundId: "",
    advisorId: "",
    classId: "",
  });

  return callOnboardingApi({
    url,
    method: "get",
    headers: {
      "Onboarding-ID": onboardingId,
      "Account-ID": "",
    },
  });
}

export async function postCurrentTabFormChanges(
  formJSON,
  onboardingId,
  checklistId,
  tabName,
  formName,
) {
  const url = createUrl(getAppendedEnvVariable(COMMON_ENDPOINT, `/${formName}/tabs/${tabName}`), {
    checklistId,
    businessLine: BUSINESS_LINE,
  });
  const res = await callOnboardingApi({
    url,
    method: "post",
    headers: {
      "Onboarding-ID": onboardingId,
    },
    body: formJSON,
  });
  return res;
}

export async function postMetaDataChanges(
  tabList,
  onboardingId,
  checklistId,
  formName,
  given_name,
  family_name,
) {
  const url = createUrl(getAppendedEnvVariable(COMMON_ENDPOINT, `/${formName}/metadata`), {
    checklistId,
  });
  return callOnboardingApi({
    url,
    method: "post",
    headers: {
      "Onboarding-ID": onboardingId,
      "Account-ID": onboardingId,
    },
    body: {
      tabList,
      formName,
      modifiedByUserName: `${given_name} ${family_name}`,
    },
  });
}

export async function postDataPointsData(dataPointRequestBody, onboardingId, checklistId) {
  const appendedUrl = `?fundId=&advisorId=&classId=&isSubmit=false&businessLine=${BUSINESS_LINE}&checklistId=${checklistId}`;
  const uri = getAppendedEnvVariable(POST_DATA_POINT, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "post",
    headers: {
      "Onboarding-ID": onboardingId,
    },
    body: dataPointRequestBody,
  });
}

export async function processCurrentOnboarding(onboardingId, action, taskIdParam) {
  const appendedUrl = taskIdParam
    ? `?formAction=approve&onboardingId=${onboardingId}&taskId=${taskIdParam}`
    : `?formAction=${action}&onboardingId=${onboardingId}&businessLine=${BUSINESS_LINE}`;
  const uri = getAppendedEnvVariable(SUBMIT_ONBOARDING, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "post",
  });
}

export async function getTableHeaderDetails(onboardingId) {
  const appendedUrl = `?onboardingId=${onboardingId}`;
  const uri = getAppendedEnvVariable(HEADER_EVENT_DETAILS_ENDPOINT, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "get",
  });
}

export async function getUserAssignedRoles(userId) {
  const appendedUrl = `?userId=${userId}`;
  const uri = getAppendedEnvVariable(USER_ROLE_LIST, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "get",
  });
}

//** This is using the gql query for Personal Trust */
export async function getDashboardTableData(businessLine) {
  const uri = getEnvValue(EXP_API_GRAPHQL_URI); //Url for grapQL
  //const query = taskListQuery(taskType, userRole);
  const query = GraphQLTaskListQuery(businessLine);
  return callOnboardingApi({
    type: API_TYPE_GRAPHQL,
    body: { query },
    endpoint: uri,
  });
}

//TODO finish this rest call for the api
export async function getDashboardTaskData(businessLine, taskType, userRole) {
  const url = getEnvValue(REST_COMMON_OBJECT); //Url for grapQL
  //const query = taskListQuery(taskType, userRole);
  //const query = personalTrustTaskListQuery();
  //console.log("callOnboardingAPI")
  return callOnboardingApi({
    method: "post",
    body: [
      // {
      //   key: "id",
      //   value: "36171",
      //   operation: "equal",
      // },
      {
        key: "businessLine",
        value: businessLine,
        operation: "equal",
      },
    ],
    url,
  });
}

export async function getHistoryTableData(onboardingId) {
  const appendedUrl = `?onboardingId=${onboardingId}&businessLine=${BUSINESS_LINE}`;
  const uri = getAppendedEnvVariable(FETCH_HISTORY_TABLE_ENDPOINT, appendedUrl);
  return callOnboardingApi({
    url: uri,
    method: "get",
  });
}

export async function getWebKycTableData(searchValue) {
  const uri = getEnvValue(EXP_API_GRAPHQL_URI);
  const query = webKycQuery(searchValue);

  try {
    const response = await callOnboardingApi({
      type: API_TYPE_GRAPHQL,
      body: { query },
      endpoint: uri,
    });
    return response.data.data.webKycParty;
  } catch (error) {
    return error;
  }
}
