import { createRoot } from "react-dom/client";
import FontFace from "./components/common/FontFace";
import { USER_ROLE } from "./constants/constant";
import Entry from "./Entry";
import { router } from "./router";
import "./styles.css";
import { initSelectorDebugger } from "./utils/initSelectorDebugger";

/**
 * Setting this to true will cause network requests to be intercepted by a
 * service worker. This is useful during development, in situations where the
 * backend has not completed implementing an endpoint, when an endpoint is
 * broken, when you have no network connectivity, etc.
 */
const ENABLE_MOCK_SERVER = false; // PLEASE SET TO false BEFORE COMMITTING!

/**
 * Setting this to true will log all route changes to the console.
 */
const ENABLE_ROUTE_DEBUGGER = true; // PLEASE SET TO false BEFORE COMMITTING!

if (process.env.NODE_ENV === "development") {
  window.ENABLE_MOCK_SERVER = ENABLE_MOCK_SERVER;
  /**
   * Store user role in the global scope for testing
   */
  window.MOCK_USER_ROLE = USER_ROLE.MARKETER;
  // window.MOCK_USER_ROLE = USER_ROLE.CONTRACT_ANALYST;

  /**
   * Initialize console tool for debugging selectors.
   */
  initSelectorDebugger();

  /**
   * @see https://mswjs.io/docs/getting-started/integrate/browser
   */
  if (ENABLE_MOCK_SERVER) {
    // eslint-disable-next-line global-require
    const { worker } = require("./mocks/browser");
    worker.start({
      onUnhandledRequest: "bypass",
    });
  }

  if (ENABLE_ROUTE_DEBUGGER) {
    // eslint-disable-next-line no-console
    router.subscribe((routerState) => console.log(routerState));
  }
}

function App() {
  return (
    <>
      <FontFace />
      <Entry />
    </>
  );
}

const root = createRoot(document.getElementById("root-layer"));

root.render(<App />);
