/** @type {import('jest').Config} */
module.exports = {
  moduleNameMapper: {
    "\\.s?css$": "identity-obj-proxy",
    canvas: "jest-canvas-mock",
    "file-loader": "identity-obj-proxy",
  },
  setupFiles: [
    /**
     * React Router uses the Fetch API, which is not available in Node 16,
     * so it needs to be polyfilled.
     * @see https://reactrouter.com/en/main/routers/picking-a-router#testing
     */
    "whatwg-fetch",
  ],
  setupFilesAfterEnv: ["@testing-library/jest-dom/extend-expect"],
  testEnvironment: "jsdom",
  verbose: true,
};
