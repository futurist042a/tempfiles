#!/bin/node
const fs = require("fs");
// Obtain the environment string passed to the node script
const environment = process.argv[2];
// read the content of the json file
// eslint-disable-next-line import/no-dynamic-require
const envFileContent = require(`../envs/${environment}.json`);

// copy the json inside the env.json file
if (environment === "local" && fs.existsSync("public")) {
  fs.writeFileSync("public/env.json", JSON.stringify(envFileContent, undefined, 2));
}
if (fs.existsSync("dist")) {
  fs.writeFileSync("dist/env.json", JSON.stringify(envFileContent, undefined, 2));
}
