#!/bin/bash

echo "App version: "$VERSION
echo "runtimeEnv:" $runtimeEnv
echo "API_KEY:" $API_KEY
echo "Config file to be used: /usr/share/nginx/html/template/home/envs/"$runtimeEnv".json"

tmp/generate_config_js.sh > /usr/share/nginx/html/template/home/app-config.js

nginx -g "daemon off;"
