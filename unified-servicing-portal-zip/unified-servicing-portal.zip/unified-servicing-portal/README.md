# template-stitching-layer

A starting point for new Corporate Unified Onboarding frontend projects.

## Documentation

- [User manual](./docs/user-manual.md)
- [Bootstrapping a new project](./docs/bootstrapping-a-new-project.md)
  1. [Request authentication URLs](./docs/bootstrapping-a-new-project.md#1-request-authentication-urls)
  2. [Enter credentials in .npmrc](./docs/initial-setup.md#2-enter-credentials-in-npmrc)
  3. [Change the HOME_PATH variable](./docs/bootstrapping-a-new-project.md#3-change-the-home_path-variable)
  4. [Find and replace "template"](./docs/bootstrapping-a-new-project.md#4-find-and-replace-template)
  5. [Choose a port number for development](./docs/bootstrapping-a-new-project.md#5-choose-a-port-number-for-development)
- [Tooling](./docs/tooling.md)
  - [Visual Studio Code Extensions](./docs/tooling.md#visual-studio-code-extensions)
  - [Browser Extensions](./docs/tooling.md#browser-extensions)
- [Maintenance](./docs/maintenance.md)
  - [Creating environment variables](./docs/maintenance.md#creating-environment-variables)
- [Development](./docs/development.md)
  - [Connecting to a new API endpoint](./docs/development.md#connecting-to-a-new-api-endpoint)
  - [Derived state using selectors](./docs/development.md#derived-state-using-selectors)
    - [Debugging selectors](./docs/development.md#debugging-selectors)
  - [Link to src README](https://gitlab.us.bank-dns.com/axsult1/unified-servicing-portal/-/blob/main/src/README.md)
- Setting up React and Java Project
  - [Prerequisites](./docs/HowTos/Prerequisites.md)
  - [Gitlab Code base](./docs/HowTos/codebase.md)
  - [Setup React Project in Visual Studio Code](./docs/setup-react-project.md)
    - Clone AppBuilder Project
    - Reload the Updated code from Branch
    - Build and Run the server
  - [Setup Domain API (Java Project) in IntelliJ IDE](./docs/setup-experience-api-project.md)
    - Clone Domain API Project
    - Configure the environment
    - Run the server
    - Package the Domain API as jar
    - Test the Service End Point
  - Building and Publish Library
    - [Build RenderUI Library](./docs/HowTos/createLibaries.md?ref_type=heads#user-content-renderui)
    - [Build USBPage Libary](./docs/HowTos/createLibaries.md?ref_type=heads#user-content-usbpage)
  - [Create AppBuilder Web Server Docker Image](./docs/HowTos/createAppBuilderImage.md)
- Rancher
  - [Rancher Login](docs/deploy-container-EKS.md)
  - [Creating Namespace](docs/deploy-container-EKS.md#create-namespace)
  - [Creating Secrets](docs/deploy-container-EKS.md#create-secrets)
- Unified Service Portal
  - [Creating Docker Image](docs/unified-service-portal-building-docker.md)
  - [Deploying Docker Image into EKS](docs/deploy-container-EKS.md#deploy-the-usp-exp-api-docker-image)
  - [Retrieve the Service Port](docs/deploy-container-EKS.md#user-content-retrieve-the-service-port-1)
- USP Experience API
  - [Creating Docker Image](docs/usp-exp-api-build-dockerfile.md)
  - [Deploying Docker Image into EKS](docs/deploy-container-EKS.md#deploy-the-unified-servicing-portal-docker-image)
  - [Retrieve the Service Port](docs/deploy-container-EKS.md#user-content-retrieve-the-service-port)
- [AppBuilder Component User Guide](docs/appBuilder.md)
  - Shield Component vs AppBuilder Type Alias mapping
  - Create Application
  - Create Screen JSON
  - Import Render UI Library
  - Java Script

### How Tos

- How to fix [UI Invalid HTTP Header](docs/HowTos/invalidHttpHeader.md#invalid-http-header)
- How to [create DNS Subdomain](docs/HowTos/createDNSSubdomain.md)
- How to [create Application Load Balancer](docs/HowTos/applicationLoadBalancer.md)
- How to [configure Application Load Balancer](docs/HowTos/applicationLoadBalancer.md#user-content-configure-alb)
- How to [create certificate](docs/HowTos/createCertificate.md)
- How to fix [Docker build issue](docs/HowTos/HowToFixNpmIssue.md)
- How to fix [Task URL SSO issue](docs/HowTos/HowToFixTaskURLSSO.md)
- How to [Upgrade Existing EKS Cluster](docs/HowTos/HowToUpgradeExistingEKSCluster.md)
- How to [Update the AWS Target Group for new EKS Cluster Node IP Address](docs/HowTos/HowToFixTaskURLSSO.md)

### What we have done

- We updated the localhost to /usp/home
- We asked the Ping fed team to add our url for authorization to Unified onboarding teams authorization list
- We are connecting to our own experience layer
  - As well as the UO teams endpoint to get common objects
- The Table has custom components to fit our needs
