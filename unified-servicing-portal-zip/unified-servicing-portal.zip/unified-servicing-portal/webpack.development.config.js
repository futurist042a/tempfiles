/* eslint-disable import/no-extraneous-dependencies */
const HtmlWebPackPlugin = require("html-webpack-plugin");
const { merge } = require("lodash");
const baseConfig = require("./webpack.base.config");
const path = require("path");

const PORT = process.env.PORT ?? 5031;

const config = merge(baseConfig, {
  mode: "development",
  devtool: "inline-source-map",
  devServer: {
    port: PORT,
    headers: {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "*",
      "Access-Control-Allow-Headers": "*",
    },
    historyApiFallback: true,
  },
  output: {
    path: path.resolve(__dirname, "./public"),
    publicPath: `http://localhost:${PORT}/`,
  },
  optimization: {
    minimize: false,
    runtimeChunk: "single",
  },
});

config.plugins.push(
  new HtmlWebPackPlugin({
    template: "./public/index.html",
    hash: true,
    title: "Development",
    favicon: "./src/favicon.ico",
    custom: "",
  }),
);

module.exports = config;
