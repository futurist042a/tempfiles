/* eslint-disable import/no-extraneous-dependencies */
const HtmlWebPackPlugin = require("html-webpack-plugin");
const { merge } = require("lodash");
const { HOME_PATH } = require("./public/env.json");
const baseConfig = require("./webpack.base.config");
const path = require("path");

const config = merge(baseConfig, {
  mode: "production",
  devtool: "source-map",
  output: {
    path: path.resolve(__dirname, "./dist"),
    publicPath: `${HOME_PATH}/`,
  },
  optimization: {
    minimize: true,
  },
});

config.plugins.push(
  new HtmlWebPackPlugin({
    template: "./public/index.html",
    hash: true,
    title: "Development",
    favicon: "./src/favicon.ico",
    custom: `<script type="text/javascript" src="${HOME_PATH}/app-config.js"></script>`,
  }),
);

module.exports = config;
