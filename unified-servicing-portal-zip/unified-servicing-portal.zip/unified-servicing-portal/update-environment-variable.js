/* eslint-disable import/no-extraneous-dependencies */
const yaml = require("js-yaml");
const fs = require("fs");
const path = require("path");
const readline = require("readline");

// #region script

const input = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

input.question("What is the name of the variable? ", (key) => {
  input.question("What is the value? ", (value) => {
    updateEnvJs({ key });
    updateGenerateConfigJs({ key });
    updateEnvJson({ key, value });
    updateKubernetesConfigs({ key, value });
    updateConfigMaps({ key, value });
    process.exit();
  });
});

// #endregion

// #region helpers

function updateGenerateConfigJs({ key }) {
  const filePath = path.resolve(
    "./k8s-pipeline-rancher/unified-servicing-portal/config/generate_config_js.sh",
  );
  const fileBuffer = fs.readFileSync(filePath);
  const fileString = fileBuffer.toString();
  const fileLines = fileString.split("\n").filter((line) => line !== "");
  const last = fileLines.pop();
  // eslint-disable-next-line prefer-const
  let [first, second, ...tail] = fileLines;

  const variableExists = tail.some((line) => line.startsWith(`window.REACT_APP_${key} =`));

  if (variableExists) {
    tail = tail.map((line) => {
      if (line.startsWith(`window.REACT_APP_${key} =`)) {
        return `window.REACT_APP_${key} = "$\{${key}}";`;
      }
      return line;
    });
  } else {
    tail.push(`window.REACT_APP_${key} = "$\{${key}}";`);
    tail.sort();
  }

  const finalLines = [first, second, ...tail, last];
  finalLines.push("");
  const newFileContent = finalLines.join("\n");
  fs.writeFileSync(filePath, newFileContent);
}

function updateEnvJs({ key }) {
  const filePath = path.resolve("./src/constants/env.js");
  const fileBuffer = fs.readFileSync(filePath);
  const fileString = fileBuffer.toString();
  let fileLines = fileString.split("\n").filter((line) => line !== "");

  const variableExists = fileLines.some((line) => line.startsWith(`export const ${key} =`));

  if (variableExists) {
    fileLines = fileLines.map((line) => {
      if (line.startsWith(`export const ${key} =`)) {
        return `export const ${key} = "${key}";`;
      }
      return line;
    });
  } else {
    fileLines.push(`export const ${key} = "${key}";`);
    fileLines.sort();
  }
  fileLines.push("");

  const newFileContent = fileLines.join("\n");
  fs.writeFileSync(filePath, newFileContent);
}

function updateEnvJson({ key, value }) {
  const filePath = path.resolve("./public/env.json");
  const fileBuffer = fs.readFileSync(filePath);
  const fileString = fileBuffer.toString();
  const envJson = JSON.parse(fileString);
  envJson[key] = value;
  const newFileContent = `${JSON.stringify(envJson, Object.keys(envJson).sort(), 2)}\n`;
  fs.writeFileSync(filePath, newFileContent);
}

function updateKubernetesConfigs({ key, value }) {
  const relativePaths = [
    "./k8s-configuration/unified-servicing-portal/us.bank-dns.com/dev/configmap.yaml",
    "./k8s-configuration/unified-servicing-portal/us.bank-dns.com/dr/configmap.yaml",
    "./k8s-configuration/unified-servicing-portal/us.bank-dns.com/it/configmap.yaml",
    "./k8s-configuration/unified-servicing-portal/us.bank-dns.com/prod/configmap.yaml",
    "./k8s-configuration/unified-servicing-portal/us.bank-dns.com/uat/configmap.yaml",
  ];
  for (const relativePath of relativePaths) {
    const filePath = path.resolve(relativePath);
    const fileBuffer = fs.readFileSync(filePath);
    const configObj = yaml.load(fileBuffer);
    configObj.data[key] = value;
    const newFileContent = yaml.dump(configObj, { sortKeys: true });
    fs.writeFileSync(filePath, newFileContent);
  }
}

function updateConfigMaps({ key, value }) {
  const relativePaths = [
    "./k8s-pipeline-rancher/dev-configmap.properties",
    "./k8s-pipeline-rancher/dr-configmap.properties",
    "./k8s-pipeline-rancher/it-configmap.properties",
    "./k8s-pipeline-rancher/prod-configmap.properties",
    "./k8s-pipeline-rancher/uat-configmap.properties",
  ];
  for (const relativePath of relativePaths) {
    const filePath = path.resolve(relativePath);
    const fileBuffer = fs.readFileSync(filePath);
    const fileString = fileBuffer.toString();
    let fileLines = fileString.split("\n").filter((line) => line !== "");

    const variableExists = fileLines.some((line) => line.startsWith(`${key}=`));

    if (variableExists) {
      fileLines = fileLines.map((line) => {
        if (line.startsWith(`${key}=`)) {
          return `${key}=${value}`;
        }
        return line;
      });
    } else {
      fileLines.push(`${key}=${value}`);
      fileLines.sort();
    }
    fileLines.push("");

    const newFileContent = fileLines.join("\n");
    fs.writeFileSync(filePath, newFileContent);
  }
}

// #endregion
