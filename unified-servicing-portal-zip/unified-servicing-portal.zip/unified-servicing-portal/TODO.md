# TODO

Maintenance tasks you could do when there is some downtime.

- [x] Move user data to its own reducer
- [x] Get rid of API_TYPE_HTTP (if it's not GraphQL, it's HTTP)
- [ ] abstract callOnboardingApi calls in [./src/actions/dashboardTableAction.js](./src/actions/dashboardTableAction.js) and [.src/actions/initiateOnboardingAction.js](.src/actions/initiateOnboardingAction.js) as functions in [./src/services/template-service.js](./src/services/template-service.js)
- [ ] move styles that are specific to DPG forms in [./src/scss/_shieldTable.scss](./src/scss/_shieldTable.scss) to styled-components
- [x] move files from src/actions/queries to src/queries
- [x] find all index.js files that re-export components as an object (like [./src/hoc/index.js](./src/hoc/index.js)), delete them, and fix the imports for those components. That pattern of re-exporting as an object is bad because it doesn't allow for tree-shaking dead exports.
- [ ] Update fonts to US Bank Circular (we shouldn't use Helvetica per the new brand guidelines)
- [ ] Remove `DPG` from all of our environment variables. There is no need to namespace them to this project.
- [x] Refactor checkIncompleteStatus into a selector, since its data comes from Redux
- [ ] Create a HOME_PATH variable with a value of `/template/home`, refactor all strings that start with `/template/home` to use a function in [./src/utils/commonMethods.jsx](./src/utils/commonMethods.jsx) called `routePath`, or use the `homeRoute` value.

  ```js
  export function routePath(path = "") {
    return getAppendedEnvVariable(HOME_PATH, path);
  }

  export const homeRoute = routePath();
  ```

- [x] Delete unused exports in [./src/utils/validationMessages.js](./src/utils/validationMessages.js)
- [ ] Upgrade to the latest version of React Router
- [ ] Migrate away from redux-oidc and into the more modern [react-oidc-context](https://github.com/authts/react-oidc-context) - but check for alternative solutions to [./src/utils/oidcMiddleware.js](./src/utils/oidcMiddleware.js) which is used in [./src/utils/store.js](./src/utils/store.js)
- [ ] Consider refactoring actions into [RTK Query](https://redux-toolkit.js.org/rtk-query/overview)
- [ ] Move all imports from `@usb-...` to `components/usb-...` instead for better encapsulation of JS and CSS
- [x] Create a `@` alias for the `src` folder, change all imports from `"../../../folder"` to `"@/folder"`. This will require a change in the Webpack and Babel configs
- [ ] Move the styles of [./src/common/HomeBackButton.jsx](./src/common/HomeBackButton.jsx) and [./src/common/Loader.jsx](./src/common/Loader.jsx) to their own styled-components
