/* eslint-disable import/no-extraneous-dependencies */
const sassImplementation = require("sass");
const { ModuleFederationPlugin } = require("webpack").container;
const Dotenv = require("dotenv-webpack");
const deps = require("./package.json").dependencies;
const path = require("path");

module.exports = {
  stats: {
    children: true,
  },
  entry: "./src/index.js",
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
    extensions: [".jsx", ".js", ".json", ".ts", ".tsx"],
    fallback: {
      buffer: false,
      canvas: false,
      fs: false,
      http: require.resolve("stream-http"),
      https: require.resolve("https-browserify"),
      url: false,
      zlib: false,
    },
  },
  output: {
    filename: "[name].[chunkhash:4].js",
  },
  module: {
    rules: [
      {
        test: /\.(sa|sc|c)ss$/,
        use: [
          { loader: "style-loader", options: { injectType: "styleTag" } },
          "css-loader",
          {
            loader: "sass-loader",
            options: {
              implementation: sassImplementation,
            },
          },
        ],
      },
      {
        test: /\.md$/i,
        use: "raw-loader",
      },
      {
        test: /\.(png|woff|woff2|eot|ttf|svg)$/,
        use: {
          loader: "url-loader",
        },
      },
      {
        test: /bootstrap\.jsx?$/,
        exclude: /node_modules/,
        loader: "bundle-loader",
        options: {
          lazy: true,
        },
      },
      {
        test: /\.js$/,
        exclude: /node_modules/,
        enforce: "pre",
        use: ["source-map-loader"],
      },
      {
        test: /\.m?js/,
        exclude: /node_modules/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false,
        },
      },
      { test: /\.txt$/, use: "raw-loader" },
      {
        test: /\.json$/,
        use: ["json-loader"],
        type: "javascript/auto",
      },
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        loader: "babel-loader",
      },
      {
        test: /\.ts$/,
        use: "ts-loader",
        exclude: /node_modules/,
      },
      {
        test: /\.tsx?$/,
        use: "ts-loader",
        exclude: /node_modules/,
      },
    ],
  },
  plugins: [
    new ModuleFederationPlugin({
      name: "unifiedServicingPortal",
      filename: "remoteEntry.js",
      exposes: {
        "./OnboardingHome": "./src/components/form-page/OnboardingHome.jsx",
      },
      shared: {
        react: {
          requiredVersion: deps.react,
          import: "react", // the "react" package will be used a provided and fallback module
          shareKey: "react", // under this name the shared module will be placed in the share scope
          shareScope: "default", // share scope with this name will be used
          singleton: true, // only a single version of the shared module is allowed
          eager: true,
        },
        "react-dom": {
          requiredVersion: deps["react-dom"],
          singleton: true, // only a single version of the shared module is allowed
          eager: true,
        },
        "styled-components": {
          requiredVersion: deps["styled-components"],
          singleton: true, // only a single version of the shared module is allowed
          eager: true,
        },
      },
    }),
    new Dotenv({
      systemvars: true,
    }),
  ],
};
